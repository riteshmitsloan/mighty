"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };

  // <define:__PUBLIC_CONFIG__>
  var init_define_PUBLIC_CONFIG = __esm({
    "<define:__PUBLIC_CONFIG__>"() {
    }
  });

  // src/content.ts
  init_define_PUBLIC_CONFIG();

  // src/profile.ts
  init_define_PUBLIC_CONFIG();

  // src/dom.ts
  init_define_PUBLIC_CONFIG();
  var excluded = "script,style,noscript,template,nav,footer,aside,.visually-hidden,.sr-only,.screen-reader-text";
  function rendered(element2) {
    if (!element2) return false;
    for (let p = element2; p; p = p.parentElement) {
      if (p.matches(excluded) || p.hasAttribute("hidden")) return false;
      const inline = (p.getAttribute("style") || "").replace(/\s/g, "").toLowerCase();
      if (/(?:^|;)(display:none|visibility:hidden|visibility:collapse)(?:;|$|!important)/.test(inline)) return false;
      const view = p.ownerDocument.defaultView;
      if (view && typeof view.getComputedStyle === "function") {
        const s = view.getComputedStyle(p);
        if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse") return false;
      }
    }
    return true;
  }
  function textOf(element2, max = 1e3) {
    if (!element2 || !rendered(element2)) return "";
    const walker = element2.ownerDocument.createTreeWalker(element2, 4);
    let text3 = "";
    let node;
    while ((node = walker.nextNode()) && text3.length < max * 2) {
      if (rendered(node.parentElement)) text3 += " " + (node.nodeValue || "");
    }
    return text3.replace(/\s+/g, " ").trim().slice(0, max);
  }
  function firstRendered(root, selectors) {
    return Array.from(root.querySelectorAll(selectors)).find(rendered) || null;
  }

  // src/experience-fields.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/current-experience.ts
  init_define_PUBLIC_CONFIG();
  var CURRENT_EXPERIENCE_LIMITS = Object.freeze({ field: 200, range: 80, entry: 8e3 });
  var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var date = "(?:(?:19|20)\\d{2}-\\d{2}-\\d{2}|(?:" + month + "\\s+)?(?:19|20)\\d{2})";
  var separator = "\\s*(?:[-\u2013\u2014]|to)\\s*";
  function currentExperienceDateRanges(text3) {
    return [...text3.matchAll(new RegExp("(?<![\\w-])" + date + separator + "(?:" + date + "|Present|Current)(?![\\w-])", "gi"))].map((match) => match[0].trim());
  }
  function validCurrentExperienceDate(range, observedAt) {
    if (typeof range !== "string" || range.length > CURRENT_EXPERIENCE_LIMITS.range || typeof observedAt !== "string") return false;
    const observed = Date.parse(observedAt);
    if (!Number.isFinite(observed)) return false;
    const match = range.match(new RegExp("^(" + date + ")" + separator + "(?:Present|Current)$", "i"));
    if (!match) return false;
    const start = match[1], exact = start.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let instant;
    if (exact) {
      instant = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const check = new Date(instant);
      if (check.getUTCFullYear() !== Number(exact[1]) || check.getUTCMonth() !== Number(exact[2]) - 1 || check.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const named = start.match(new RegExp("^(" + month + ")\\s+((?:19|20)\\d{2})$", "i"));
      instant = named ? Date.UTC(Number(named[2]), months.indexOf(named[1].slice(0, 3).toLowerCase()), 1) : Date.UTC(Number(start), 0, 1);
    }
    return Number.isFinite(instant) && instant <= observed;
  }
  var record = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  function validCurrentExperienceAnchor(anchor, anchors, profileUrl, profileReadAt) {
    const value = record(anchor);
    if (!value || value.kind !== "experience" || !["role", "company"].includes(String(value.field)) || typeof value.text !== "string" || !value.text.trim() || value.text.length > CURRENT_EXPERIENCE_LIMITS.field) return false;
    if (!profileReadAt || !Number.isFinite(Date.parse(profileReadAt)) || value.observedAt !== profileReadAt || value.sourceUrl !== profileUrl + "#experience") return false;
    if (value.appliesTo !== void 0 && value.appliesTo !== "contact" || value.polarity !== void 0 && value.polarity !== "positive") return false;
    const current = record(value.currentExperience);
    if (!current || Object.keys(current).some((key) => !["dateRange", "entryText", "group"].includes(key)) || typeof current.dateRange !== "string" || typeof current.entryText !== "string") return false;
    if (!current.entryText.trim() || current.entryText.length > CURRENT_EXPERIENCE_LIMITS.entry || !validCurrentExperienceDate(current.dateRange, profileReadAt) || !current.entryText.includes(current.dateRange)) return false;
    const ranges = [...new Set(currentExperienceDateRanges(current.entryText))];
    if (ranges.length !== 1 || ranges[0] !== current.dateRange) return false;
    const sameSource = (other) => other && other.sourceUrl === value.sourceUrl && other.observedAt === profileReadAt && other.field === void 0 && other.currentExperience === void 0;
    if (current.group !== void 0) {
      const group = record(current.group);
      if (!group || Object.keys(group).some((key) => !["company", "entryText"].includes(key)) || typeof group.company !== "string" || !group.company.trim() || group.company !== group.company.trim() || group.company.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(group.company).length || typeof group.entryText !== "string" || group.entryText.length > CURRENT_EXPERIENCE_LIMITS.entry || group.entryText === current.entryText || !group.entryText.includes(group.company) || !group.entryText.includes(current.entryText)) return false;
      if (value.field === "company" ? value.text !== group.company : !current.entryText.includes(value.text)) return false;
      if (!anchors.some((other) => {
        const raw = record(other);
        return sameSource(raw) && raw.kind === "experience" && raw.text === group.entryText;
      })) return false;
    } else if (!current.entryText.includes(value.text)) return false;
    return anchors.some((other) => {
      const raw = record(other);
      return sameSource(raw) && raw.kind === "experience" && raw.text === current.entryText;
    }) && anchors.some((other) => {
      const timing = record(other);
      return sameSource(timing) && timing.kind === "timing" && timing.text === current.dateRange;
    });
  }

  // src/urls.ts
  init_define_PUBLIC_CONFIG();
  function canonicalProfileURL(value, base = "https://www.linkedin.com") {
    try {
      const u = new URL(value, base);
      if (u.protocol !== "https:" || !["linkedin.com", "www.linkedin.com"].includes(u.hostname.toLowerCase()) || u.port || u.username || u.password) return null;
      const m = u.pathname.match(/^\/in\/([^/]+)\/?$/);
      if (!m) return null;
      const slug = decodeURIComponent(m[1]).normalize("NFC").toLowerCase();
      if (!/^[\p{L}\p{N}_-]{1,200}$/u.test(slug)) return null;
      return "https://www.linkedin.com/in/" + encodeURIComponent(slug) + "/";
    } catch {
      return null;
    }
  }
  function isSearchURL(value) {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && ["www.linkedin.com", "linkedin.com"].includes(u.hostname) && /^\/search\/results\/people\/?$/.test(u.pathname);
    } catch {
      return false;
    }
  }

  // src/experience-fields.ts
  var labelField = /* @__PURE__ */ new Map([["job title", "role"], ["role", "role"], ["position", "role"], ["company", "company"], ["employer", "company"]]);
  var visible = (root, selector) => Array.from(root.querySelectorAll(selector)).filter(rendered);
  var entitySelector = 'div[componentkey^="entity-collection-item-"]';
  var experiencePrefix = "Profile_Top_Level_ExperienceTopLevelSection";
  var duration = /^\d+\s+(?:yrs?|years?|mos?|months?|wks?|weeks?|days?)(?:\s+\d+\s+(?:yrs?|years?|mos?|months?|wks?|weeks?|days?)){0,2}$/i;
  function dateField(text3) {
    const ranges = currentExperienceDateRanges(text3);
    if (ranges.length !== 1 || !text3.startsWith(ranges[0])) return null;
    const suffix = text3.slice(ranges[0].length).trim();
    return !suffix || /^[·•]\s*/.test(suffix) && duration.test(suffix.replace(/^[·•]\s*/, "")) ? ranges[0] : null;
  }
  function sduiExperienceScope(section, profileUrl) {
    const canonical = canonicalProfileURL(profileUrl);
    if (!canonical || !section.matches("section") || !rendered(section)) return null;
    const slug = new URL(canonical).pathname.slice(4, -1), expected = /* @__PURE__ */ new Set([experiencePrefix + slug, experiencePrefix + decodeURIComponent(slug)]);
    const headings = visible(section, 'h2[componentkey="ProfileNullStateCardAnchor_Experience"]').filter((heading) => heading.closest("section") === section && /^experience$/i.test(textOf(heading, Infinity)));
    const markers = visible(section, 'div[componentkey^="' + experiencePrefix + '"]');
    if (headings.length !== 1 || markers.length !== 1 || !expected.has(markers[0].getAttribute("componentkey") || "") || markers[0].closest("section") !== section) return null;
    return section;
  }
  function sduiExperienceEntries(section, profileUrl) {
    const scope2 = sduiExperienceScope(section, profileUrl);
    if (!scope2) return [];
    return visible(scope2, entitySelector).filter((item) => item.closest("section") === section && !item.parentElement?.closest(entitySelector));
  }
  function companyURL(value) {
    try {
      const url = new URL(value, "https://www.linkedin.com");
      if (url.protocol !== "https:" || !["linkedin.com", "www.linkedin.com"].includes(url.hostname) || url.username || url.password || url.port || url.search || url.hash) return null;
      const match = url.pathname.match(/^\/company\/([\w-]{1,200})\/?$/);
      return match ? "https://www.linkedin.com/company/" + match[1] + "/" : null;
    } catch {
      return null;
    }
  }
  function unlinkedJobParagraphs(item) {
    if (item.querySelector("a")) return null;
    const figures = visible(item, "figure"), paragraphs = visible(item, "p");
    if (figures.length !== 1 || paragraphs.length < 3 || paragraphs.length > 4) return null;
    const figure = figures[0], logos = visible(figure, 'svg[role="img"][aria-label]');
    if (logos.length !== 1 || paragraphs.some((p) => visible(p, "p").length || figure.contains(p))) return null;
    const siblings = Array.from(figure.parentElement?.children || []).filter((node) => node.matches("div") && rendered(node) && paragraphs.every((p) => node.contains(p)));
    if (siblings.length !== 1) return null;
    const container = siblings[0], [role, employer, date3, location2] = paragraphs, titles = role.parentElement;
    if (!titles?.matches("div") || titles === container || titles !== employer.parentElement || titles.contains(date3) || !date3.parentElement?.matches("div") || !date3.parentElement.contains(titles) || location2 && location2.parentElement !== date3.parentElement) return null;
    return { paragraphs, logoLabel: (logos[0].getAttribute("aria-label") || "").replace(/\s+/g, " ").trim() };
  }
  function groupedCurrentFields(item, observedAt) {
    if (visible(item, entitySelector + ",[itemscope]").length) return [];
    const lists = visible(item, "ul"), groupText = textOf(item, Infinity);
    if (lists.length !== 1 || lists[0].parentElement !== item || groupText.length > CURRENT_EXPERIENCE_LIMITS.entry) return [];
    const list2 = lists[0], children = Array.from(list2.children).filter(rendered);
    if (children.length < 2 || children.some((child) => !child.matches("li") || visible(child, "li,ul,ol").length) || visible(item, "li").some((child) => child.parentElement !== list2)) return [];
    const headerLinks = visible(item, "a[href]").filter((link) => !list2.contains(link));
    const textHeaders = headerLinks.filter((link) => visible(link, "p").length);
    if (textHeaders.length !== 1) return [];
    const header = textHeaders[0], employerUrl = companyURL(header.getAttribute("href") || ""), headerParagraphs = visible(header, "p");
    if (!employerUrl || headerParagraphs.length !== 2 || headerParagraphs.some((p) => p.closest("a") !== header || visible(p, "p").length) || headerLinks.some((link) => companyURL(link.getAttribute("href") || "") !== employerUrl)) return [];
    const [company, tenure] = headerParagraphs.map((p) => textOf(p, Infinity));
    if (!company || company.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(company).length || !duration.test(tenure)) return [];
    const logoLabels = headerLinks.flatMap((link) => visible(link, 'figure svg[role="img"][aria-label],figure img[alt]')).map((logo) => (logo.getAttribute("aria-label") || logo.getAttribute("alt") || "").replace(/\s+/g, " ").trim()).filter(Boolean);
    if (logoLabels.some((label) => label !== company + " logo")) return [];
    const outsideParagraphs = visible(item, "p").filter((p) => !list2.contains(p));
    if (outsideParagraphs.some((p) => !header.contains(p))) return [];
    const candidates = [];
    for (const child of children) {
      const links = visible(child, "a[href]"), textLinks = links.filter((link2) => visible(link2, "p").length);
      if (textLinks.length !== 1 || links.some((link2) => companyURL(link2.getAttribute("href") || "") !== employerUrl)) return [];
      const link = textLinks[0], paragraphs = visible(link, "p");
      if (paragraphs.length < 2 || paragraphs.length > 3 || paragraphs.some((p) => p.closest("a") !== link || visible(p, "p").length)) return [];
      const [role2, date3] = paragraphs.map((p) => textOf(p, Infinity)), dateRange2 = dateField(date3), entryText2 = textOf(child, Infinity);
      if (!role2 || role2.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(role2).length || !dateRange2 || entryText2.length > CURRENT_EXPERIENCE_LIMITS.entry) return [];
      const ranges = [...new Set(currentExperienceDateRanges(entryText2))];
      if (ranges.length !== 1 || ranges[0] !== dateRange2) return [];
      if (/\b(?:Present|Current)$/i.test(dateRange2)) {
        if (!validCurrentExperienceDate(dateRange2, observedAt)) return [];
        candidates.push({ role: role2, dateRange: dateRange2, entryText: entryText2 });
      }
    }
    if (candidates.length !== 1) return [];
    const { role, dateRange, entryText } = candidates[0];
    return ["role", "company"].map((field) => ({
      field,
      text: field === "role" ? role : company,
      currentExperience: { dateRange, entryText, group: { company, entryText: groupText } }
    }));
  }
  function sduiCurrentFields(item, observedAt, profileUrl) {
    const section = item.closest("section");
    if (!section || !sduiExperienceEntries(section, profileUrl).includes(item)) return [];
    if (visible(item, "li").length) return groupedCurrentFields(item, observedAt);
    if (visible(item, entitySelector + ",[itemscope]").length) return [];
    const entryText = textOf(item, Infinity);
    if (!entryText || entryText.length > CURRENT_EXPERIENCE_LIMITS.entry) return [];
    const ranges = [...new Set(currentExperienceDateRanges(entryText))];
    if (ranges.length !== 1 || !validCurrentExperienceDate(ranges[0], observedAt)) return [];
    const dateRange = ranges[0], links = visible(item, "a[href]");
    const textLinks = links.filter((link) => visible(link, "p").length);
    let paragraphs, logoLabel = null;
    if (!item.querySelector("a")) {
      const unlinked = unlinkedJobParagraphs(item);
      if (!unlinked) return [];
      paragraphs = unlinked.paragraphs;
      logoLabel = unlinked.logoLabel;
    } else {
      if (textLinks.length !== 1) return [];
      const link = textLinks[0], employerUrl = companyURL(link.getAttribute("href") || "");
      if (!employerUrl || links.some((other) => /\/company\//.test(other.getAttribute("href") || "") && companyURL(other.getAttribute("href") || "") !== employerUrl)) return [];
      paragraphs = visible(link, "p");
      if (paragraphs.length < 3 || paragraphs.length > 4 || paragraphs.some((p) => p.closest("a") !== link || visible(p, "p").length)) return [];
    }
    const [role, employer, renderedDate] = paragraphs.map((p) => textOf(p, Infinity));
    if (dateField(renderedDate) !== dateRange) return [];
    const employerParts = employer.split(/\s+[·•]\s+/);
    if (employerParts.length > 2 || employerParts.length === 2 && !/^(?:Full-time|Part-time|Self-employed|Freelance|Contract|Internship|Apprenticeship|Seasonal|Co-op)$/i.test(employerParts[1])) return [];
    const company = employerParts[0];
    if (logoLabel !== null && logoLabel !== company + " logo") return [];
    if ([role, company].some((value) => !value.trim() || value.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(value).length)) return [];
    return ["role", "company"].map((field) => ({ field, text: field === "role" ? role : company, currentExperience: { dateRange, entryText } }));
  }
  function currentExperienceFields(item, observedAt, profileUrl) {
    if (profileUrl && item.matches(entitySelector) && rendered(item)) return sduiCurrentFields(item, observedAt, profileUrl);
    if (!item.matches("li") || !rendered(item) || visible(item, "li").length) return [];
    if (visible(item, "[itemscope]").some((node) => !node.matches('[itemprop~="worksFor"]'))) return [];
    const entryText = textOf(item, Infinity);
    if (!entryText || entryText.length > CURRENT_EXPERIENCE_LIMITS.entry) return [];
    const ranges = [...new Set(currentExperienceDateRanges(entryText))];
    if (ranges.length !== 1 || !validCurrentExperienceDate(ranges[0], observedAt)) return [];
    const dateRange = ranges[0];
    if (!visible(item, "*").some((node) => textOf(node, Infinity) === dateRange)) return [];
    if (visible(item, '[itemprop~="endDate"]').some((node) => !/^(?:present|current)$/i.test(textOf(node, Infinity)))) return [];
    const values = { role: /* @__PURE__ */ new Set(), company: /* @__PURE__ */ new Set() };
    let invalid = false;
    const add = (field, node) => {
      const value = textOf(node, Infinity);
      if (!value || value.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(value).length) invalid = true;
      else values[field].add(value);
    };
    for (const node of visible(item, '[itemprop~="jobTitle"]')) {
      if (node.closest('[itemprop~="worksFor"]')) invalid = true;
      else add("role", node);
    }
    for (const employer of visible(item, '[itemprop~="worksFor"]')) {
      const names = visible(employer, '[itemprop~="name"]');
      if (names.length === 1) add("company", names[0]);
      else if (!names.length && !employer.children.length) add("company", employer);
      else invalid = true;
    }
    for (const term of visible(item, "dl > dt")) {
      const label = textOf(term, Infinity).toLowerCase(), field = labelField.get(label);
      const definition = term.nextElementSibling;
      if (field) {
        if (term.closest('[itemprop~="worksFor"]') || !definition?.matches("dd") || !rendered(definition) || definition.nextElementSibling?.matches("dd")) invalid = true;
        else add(field, definition);
      }
      if (["end date", "ended"].includes(label) && definition?.matches("dd") && rendered(definition) && !/^(?:present|current)$/i.test(textOf(definition, Infinity))) invalid = true;
    }
    if (invalid || values.role.size > 1 || values.company.size > 1) return [];
    return ["role", "company"].flatMap((field) => [...values[field]].map((text3) => ({ field, text: text3, currentExperience: { dateRange, entryText } })));
  }

  // ../src/lib/profile-photo.ts
  init_define_PUBLIC_CONFIG();
  function canonicalProfilePhotoUrl(value) {
    if (typeof value !== "string" || value.length > 4e3 || /[\s\\\u0000-\u001f\u007f]/u.test(value)) return null;
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.username || url.password || url.port || url.hash || !["media.licdn.com", "media-exp1.licdn.com", "media-exp2.licdn.com"].includes(url.hostname)) return null;
      if (!/^\/dms\/image\/(?:v2\/)?[A-Za-z0-9_-]+\/profile-displayphoto-(?:shrink|scale|crop)_\d{1,4}_\d{1,4}\/[A-Za-z0-9_./-]+$/.test(url.pathname)) return null;
      const keys = [...url.searchParams.keys()];
      if (new Set(keys).size !== keys.length || keys.some((key) => !["e", "v", "t"].includes(key))) return null;
      if (url.searchParams.has("e") && !/^\d{1,20}$/.test(url.searchParams.get("e"))) return null;
      if (url.searchParams.has("v") && !/^[A-Za-z0-9_-]{1,32}$/.test(url.searchParams.get("v"))) return null;
      if (url.searchParams.has("t") && !/^[A-Za-z0-9_+\/=.-]{1,2000}$/.test(url.searchParams.get("t"))) return null;
      return url.href;
    } catch {
      return null;
    }
  }

  // src/profile.ts
  function blockedState(doc, url, status = 200) {
    let path = "";
    try {
      path = new URL(url).pathname.toLowerCase();
    } catch {
      return "unknown";
    }
    if (status === 401 || /\/(authwall|login|uas\/login|signup)(?:\/|$)/.test(path)) return "auth_required";
    if ([403, 429].includes(status) || /\/(checkpoint|challenge|security-verification)(?:\/|$)/.test(path)) return "blocked";
    if (status < 200 || status >= 300) return "unknown";
    const main = doc.querySelector("main") || doc.body;
    const headings = Array.from(main?.querySelectorAll('h1,h2,[role="alert"]') || []).filter(rendered).map((x) => textOf(x, 300)).join(" ").toLowerCase();
    if (/security verification|verify (?:that )?you(?:'re| are) human|unusual activity|automated (?:activity|requests)|temporarily restricted|search (?:is )?(?:blocked|restricted|unavailable)|commercial use limit|search limit/.test(headings)) return "blocked";
    if (firstRendered(doc, 'iframe[src*="recaptcha"],iframe[src*="captcha"],form[action*="checkpoint"]')) return "blocked";
    if (/^(?:sign in|join linkedin|log in)(?:\s|$)/.test(headings) || firstRendered(main, 'form[action*="login"],form[action*="uas/login"]')) return "auth_required";
    return null;
  }
  var sections = [
    ["about", /^about$/i, ["about"]],
    ["experience", /^experience$/i, ["experience"]],
    ["education", /^education$/i, ["education"]],
    ["skills", /^skills$/i, ["skills"]],
    ["languages", /^languages$/i, ["languages"]],
    ["certifications", /^(?:licenses? (?:&|and) certifications?|certifications?)$/i, ["licenses_and_certifications"]],
    ["activity", /^activity(?:\s|$)/i, ["content_collections", "recent-activity", "activity"]]
  ];
  var substantiveKinds = /* @__PURE__ */ new Set(["about", "experience", "education", "skills", "languages", "certifications", "activity"]);
  function hasSubstantiveProfile(profile) {
    return Boolean(profile?.anchors.some((anchor) => substantiveKinds.has(anchor.kind) && anchor.text.trim().length > 0));
  }
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var MONTH = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var DAY = 864e5;
  function recentRoleStart(dateRange, now) {
    if (!/\b(?:Present|Current)\b/i.test(dateRange)) return false;
    const exact = dateRange.match(/\b((?:19|20)\d{2})-(\d{2})-(\d{2})\s*(?:[-–—]|to)\s*(?:Present|Current)\b/i);
    let start;
    if (exact) {
      start = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const date3 = new Date(start);
      if (date3.getUTCMonth() !== Number(exact[2]) - 1 || date3.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const match = dateRange.match(new RegExp("\\b(" + MONTH + ")\\s+((?:19|20)\\d{2})\\s*(?:[-\u2013\u2014]|to)\\s*(?:Present|Current)\\b", "i"));
      if (!match) return false;
      start = Date.UTC(Number(match[2]), MONTHS.indexOf(match[1].slice(0, 3).toLowerCase()), 1);
    }
    const observed = Date.parse(now);
    return Number.isFinite(observed) && start <= observed && start >= observed - 90 * DAY;
  }
  function dateRanges(text3) {
    const expression = new RegExp("(?:" + MONTH + "\\s+)?(?:19|20)\\d{2}(?:-\\d{2}-\\d{2})?\\s*(?:[-\u2013\u2014]|to)\\s*(?:(?:" + MONTH + "\\s+)?(?:19|20)\\d{2}(?:-\\d{2}-\\d{2})?|Present|Current)", "gi");
    return [...text3.matchAll(expression)].map((match) => match[0].trim());
  }
  function recentActivityDate(item, now) {
    const element2 = firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],.update-components-actor__sub-description,.feed-shared-actor__sub-description');
    if (!element2) return null;
    const visible2 = textOf(element2, Infinity), iso = element2.getAttribute("datetime") || element2.getAttribute("data-posted-at") || "";
    const observed = Date.parse(now);
    if (!Number.isFinite(observed) || !visible2) return null;
    if (iso) {
      const date3 = Date.parse(iso);
      if (Number.isFinite(date3) && date3 <= observed && date3 >= observed - 90 * DAY) return visible2 || iso;
      return null;
    }
    const relative = visible2.match(/(?:^|\s)(\d+)\s*(months?|mo|weeks?|w|days?|d|hours?|h|minutes?|mins?|m|seconds?|secs?|s)(?:\b|$)/i);
    if (relative) {
      const value = Number(relative[1]), unit = relative[2].toLowerCase();
      const factor = unit.startsWith("mo") ? 31 : unit.startsWith("w") ? 7 : unit.startsWith("d") ? 1 : unit.startsWith("h") ? 1 / 24 : unit.startsWith("m") ? 1 / 1440 : 1 / 86400;
      if (value >= 0 && (value + 1) * factor <= 90) return relative[0].trim();
      return null;
    }
    if (/^(?:just now|today|yesterday)(?:\s|[•·]|$)/i.test(visible2)) return visible2;
    if (new RegExp("\\b" + MONTH + "\\s+\\d{1,2},?\\s+(?:19|20)\\d{2}\\b", "i").test(visible2) || /^\d{4}-\d{2}-\d{2}/.test(visible2)) {
      const date3 = Date.parse(visible2);
      if (Number.isFinite(date3) && date3 <= observed && date3 >= observed - 90 * DAY) return visible2;
    }
    return null;
  }
  function profileToolbarSummary(doc, name, profileUrl) {
    const summaries = Array.from(doc.querySelectorAll('[role="toolbar"] a[href]')).filter(rendered).filter((link) => canonicalProfileURL(link.getAttribute("href") || "", profileUrl) && Array.from(link.querySelectorAll("p")).some(rendered));
    if (summaries.length !== 1) return null;
    const summary = summaries[0], paragraphs = Array.from(summary.querySelectorAll("p")).filter(rendered);
    try {
      if (new URL(summary.getAttribute("href") || "", profileUrl).href !== profileUrl) return null;
    } catch {
      return null;
    }
    if (paragraphs.length < 1 || paragraphs.length > 2 || paragraphs.some((p) => p.closest("a") !== summary) || textOf(paragraphs[0], Infinity).normalize("NFKC") !== name.normalize("NFKC")) return null;
    return paragraphs;
  }
  function markerlessSubject(card, scope2, profileUrl) {
    const headings = Array.from(card.querySelectorAll("h2")).filter(rendered);
    if (headings.length !== 1) return null;
    const heading = headings[0], name = textOf(heading, Infinity), top = heading.closest("section");
    if (!name || name.length > 200 || !top || top === scope2 || !card.contains(top) || !rendered(top)) return null;
    const contacts = Array.from(card.querySelectorAll("a[href]")).filter(rendered).filter((link) => {
      if (/^contact info$/i.test(textOf(link, Infinity))) return true;
      try {
        return /\/overlay\/contact-info\/?$/.test(new URL(link.getAttribute("href") || "", profileUrl).pathname);
      } catch {
        return false;
      }
    });
    if (contacts.length !== 1 || contacts[0].closest("section") !== top || !/^contact info$/i.test(textOf(contacts[0], Infinity))) return null;
    try {
      if (new URL(contacts[0].getAttribute("href") || "", profileUrl).href !== profileUrl + "overlay/contact-info/") return null;
    } catch {
      return null;
    }
    if (!profileToolbarSummary(card.ownerDocument, name, profileUrl)) return null;
    return { heading, top, scope: scope2, card };
  }
  function sduiHeadline(top, name, profileUrl) {
    const paragraphs = profileToolbarSummary(top.ownerDocument, name, profileUrl);
    if (paragraphs?.length !== 2) return "";
    const headline = textOf(paragraphs[1], Infinity);
    if (!headline || headline === name) return "";
    const matches = Array.from(top.querySelectorAll("p")).filter((p) => rendered(p) && p.closest("section") === top && !p.closest("a") && textOf(p, Infinity) === headline);
    return matches.length === 1 ? headline : "";
  }
  function sduiSubject(main, profileUrl) {
    const primary = Array.from(main.querySelectorAll('section[aria-label="Primary content"]')).filter(rendered);
    if (primary.length !== 1) return null;
    const scope2 = primary[0];
    const cards = Array.from(scope2.querySelectorAll('div[id^="com.linkedin.sdui.profile.card.ref"][id$="Topcard"],div[componentkey^="com.linkedin.sdui.profile.card.ref"][componentkey$="Topcard"]')).filter(rendered);
    if (cards.length !== 1) return null;
    const card = cards[0], markers = Array.from(card.querySelectorAll('[componentkey^="ProfileVerificationTriggerRef-"]')).filter(rendered);
    if (!markers.length) return markerlessSubject(card, scope2, profileUrl);
    let slug, decoded;
    try {
      slug = new URL(profileUrl).pathname.slice(4, -1);
      decoded = decodeURIComponent(slug);
    } catch {
      return null;
    }
    const expected = /* @__PURE__ */ new Set(["ProfileVerificationTriggerRef-" + slug, "ProfileVerificationTriggerRef-" + decoded]);
    const keys = new Set(markers.map((marker) => marker.getAttribute("componentkey") || ""));
    if (keys.size !== 1 || !expected.has(markers[0].getAttribute("componentkey") || "")) return null;
    const headings = [...new Set(markers.flatMap((marker) => Array.from(marker.querySelectorAll("h2")).filter(rendered)))];
    if (headings.length !== 1) return null;
    const heading = headings[0], top = heading.closest("section");
    if (!top || top === scope2 || !card.contains(top) || !rendered(top)) return null;
    if (markers.some((marker) => !marker.contains(heading) || marker.closest("section") !== top)) return null;
    return { heading, top, scope: scope2, card };
  }
  function sduiSectionSubjectCurrent(section, profileUrl) {
    const selector = '[componentkey^="Profile_Top_Level_"],[componentkey^="ProfileVerificationTriggerRef-"]';
    const markers = [...section.matches(selector) ? [section] : [], ...section.querySelectorAll(selector)].filter(rendered);
    return markers.every((marker) => {
      const key = marker.getAttribute("componentkey") || "";
      const slug = key.startsWith("ProfileVerificationTriggerRef-") ? key.slice("ProfileVerificationTriggerRef-".length) : key.match(/^Profile_Top_Level_[A-Za-z][A-Za-z0-9_]*Section(.*)$/)?.[1];
      if (!slug) return false;
      try {
        return canonicalProfileURL("https://www.linkedin.com/in/" + encodeURIComponent(decodeURIComponent(slug)) + "/") === profileUrl;
      } catch {
        return false;
      }
    });
  }
  function profileTopCard(doc, url) {
    const profileUrl = canonicalProfileURL(url), main = doc.querySelector("main");
    if (!profileUrl || !main || blockedState(doc, url)) return null;
    const headings = Array.from(main.querySelectorAll("h1")).filter(rendered);
    if (headings.length) {
      if (headings.length !== 1 || !textOf(headings[0], Infinity)) return null;
      const top = headings[0].closest("section");
      return top && main.contains(top) && rendered(top) ? top : null;
    }
    const subject = sduiSubject(main, profileUrl);
    return subject && textOf(subject.heading, Infinity) ? subject.card : null;
  }
  function profilePhoto(top, name, profileUrl, sduiCard) {
    const normalized2 = (value) => value.normalize("NFKC").replace(/[’‘]/g, "'").replace(/\s+/g, " ").trim().toLocaleLowerCase("en-US");
    const subject = normalized2(name), labels2 = /* @__PURE__ */ new Set([subject, subject + "'s profile picture", subject + "'s profile photo", "profile picture of " + subject, "profile photo of " + subject]);
    const matches = /* @__PURE__ */ new Set();
    const scope2 = sduiCard || top;
    for (const element2 of scope2.querySelectorAll("img")) {
      if (!rendered(element2) || !sduiCard && element2.closest("section") !== top) continue;
      const img = element2;
      if (typeof img.naturalWidth === "number" && img.naturalWidth === 0) continue;
      const alt = normalized2(element2.getAttribute("alt") || "");
      const reference = element2.closest('a[componentkey="topcard-logo-image-referencekey"]');
      const photoContainer = element2.closest('[aria-label="Profile photo"][componentkey="topcard-logo-image-referencekey"]');
      const sduiPhoto = Boolean(reference && photoContainer && scope2.contains(reference) && scope2.contains(photoContainer) && reference.contains(photoContainer) && canonicalProfileURL(reference.getAttribute("href") || "", profileUrl) === profileUrl && element2.getAttribute("data-loaded") === "true");
      if (element2.closest("section") !== top && !sduiPhoto) continue;
      const explicit = sduiPhoto || element2.matches('.pv-top-card-profile-picture__image,.profile-photo-edit__preview,[data-field="profile-photo"]');
      if (!labels2.has(alt) && !(explicit && !alt)) continue;
      const link = element2.closest("a[href]")?.getAttribute("href");
      if (link) {
        try {
          const target = new URL(link, profileUrl);
          if (/\/in\//.test(target.pathname) && canonicalProfileURL(target.href) !== profileUrl && !target.href.startsWith(profileUrl)) continue;
        } catch {
          continue;
        }
      }
      const photo = canonicalProfilePhotoUrl(img.currentSrc || element2.getAttribute("src"));
      if (photo) matches.add(photo);
    }
    return matches.size === 1 ? [...matches][0] : null;
  }
  function readProfile(doc, url, now = (/* @__PURE__ */ new Date()).toISOString()) {
    const profileUrl = canonicalProfileURL(url), main = doc.querySelector("main");
    if (!profileUrl || !main || blockedState(doc, url)) return null;
    const classic = firstRendered(main, "h1"), subject = classic ? { heading: classic, top: classic.closest("section") || main, scope: main } : sduiSubject(main, profileUrl);
    if (!subject) return null;
    const { heading, top, scope: scope2 } = subject, name = textOf(heading, Infinity);
    if (!name) return null;
    const truncationReasons = [];
    if (name.length > 200) truncationReasons.push("name_limit");
    let subjectChanging = false;
    const anchors = [], seen = /* @__PURE__ */ new Set();
    const add = (kind, text3, fragment, typed) => {
      text3 = text3.replace(/\s+/g, " ").trim();
      const key = kind + "\0" + (typed?.field || "") + "\0" + text3 + "\0" + (typed?.currentExperience?.entryText || "");
      if (text3 && text3 !== name && !seen.has(key)) {
        seen.add(key);
        anchors.push({ kind, text: text3, sourceUrl: profileUrl + "#" + fragment, observedAt: now, ...typed });
      }
    };
    const explicitHeadline = textOf(firstRendered(top, '[data-field="headline"],.text-body-medium.break-words,.pv-text-details__left-panel .text-body-medium'), Infinity);
    add("headline", explicitHeadline || (!classic ? sduiHeadline(top, name, profileUrl) : ""), "profile");
    add("location", textOf(firstRendered(top, '[data-field="location"],.text-body-small.inline.t-black--light.break-words,.pv-text-details__left-panel .text-body-small'), Infinity), "profile");
    for (const [kind, label, ids] of sections) {
      let section = null;
      for (const id2 of ids) {
        const exact = scope2.querySelector('[id="' + id2 + '"]');
        if (exact) {
          section = exact.closest("section");
          if (section) break;
        }
      }
      if (!section) {
        const h = Array.from(scope2.querySelectorAll("h2,h3")).find((x) => rendered(x) && label.test(textOf(x, 100)));
        section = h?.closest("section") || null;
      }
      if (!section || !rendered(section) || !classic && section === scope2) continue;
      if (!classic && !sduiSectionSubjectCurrent(section, profileUrl)) {
        subjectChanging = true;
        continue;
      }
      const id = ids[0];
      if (kind === "activity") {
        const selector = 'article,[data-activity-item],[data-urn*="urn:li:activity:"],.feed-shared-update-v2';
        const semantic = Array.from(section.querySelectorAll(selector)).filter(rendered);
        const candidates = semantic.length ? semantic : Array.from(section.querySelectorAll("li")).filter(rendered);
        const items2 = candidates.filter((item) => !candidates.some((other) => other !== item && other.contains(item)));
        for (const item of items2) {
          const text3 = textOf(item, Infinity);
          if (!text3) continue;
          const hasPost = Boolean(firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],a[href*="/feed/update/"],a[href*="/posts/"],.update-components-actor__sub-description,.feed-shared-actor__sub-description')) || item.matches('article,[data-activity-item],[data-urn*="urn:li:activity:"],.feed-shared-update-v2');
          if (!hasPost) continue;
          add("activity", text3, id);
          const stamp = firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],.update-components-actor__sub-description,.feed-shared-actor__sub-description'), stampText = textOf(stamp, Infinity);
          if (stampText) {
            const exact = stamp?.getAttribute("datetime") || stamp?.getAttribute("data-posted-at");
            add("timing", "Rendered activity timestamp: " + stampText + (exact ? " (" + exact + ")" : ""), id);
          }
          const date3 = recentActivityDate(item, now);
          if (date3) add("timing", "Recent rendered activity: " + date3, id);
        }
        continue;
      }
      const sduiItems = kind === "experience" ? sduiExperienceEntries(section, profileUrl) : [];
      const items = sduiItems.length ? sduiItems : Array.from(section.querySelectorAll("li")).filter((x) => rendered(x) && !x.parentElement?.closest("li"));
      for (const item of items.length ? items : [section]) {
        const text3 = textOf(item, Infinity);
        if (!text3 || label.test(text3)) continue;
        const bodyOnly = text3.replace(/^(?:about|experience|education|skills|languages|licenses? (?:&|and) certifications?|certifications?)\s*/i, "").replace(/(?:show all(?: \d+)?[^.]*|see more|show more|add (?:experience|education|skills))$/i, "").trim();
        if (!bodyOnly) continue;
        add(kind, text3, id);
        if (kind === "experience" || kind === "education") for (const date3 of dateRanges(text3)) {
          add("timing", date3, id);
          if (kind === "experience" && recentRoleStart(date3, now)) add("timing", "Recent role start indicated by \u201C" + date3 + "\u201D. The rendered start date or month falls within the last 90 days.", id);
        }
        if (kind === "experience") for (const field of currentExperienceFields(item, now, profileUrl)) {
          if (field.currentExperience.group) add("experience", field.currentExperience.entryText, id);
          add("experience", field.text, id, field);
        }
      }
    }
    const missingSections = ["experience", "education", "location", "skills", "languages", "certifications", "activity"].filter((kind) => !anchors.some((anchor) => anchor.kind === kind));
    const photoUrl = profilePhoto(top, name, profileUrl, "card" in subject ? subject.card : void 0);
    const profile = { profileUrl, name, ...photoUrl ? { photoUrl } : {}, anchors, profileReadAt: null, truncated: truncationReasons.length > 0, truncationReasons, missingSections };
    profile.profileReadAt = !subjectChanging && !truncationReasons.length && hasSubstantiveProfile(profile) ? now : null;
    if (new TextEncoder().encode(JSON.stringify(profile)).byteLength > 49152) {
      profile.truncationReasons.push("snapshot_size_limit");
      profile.truncated = true;
      profile.profileReadAt = null;
    }
    return profile;
  }
  function readSearchResults(doc, url) {
    if (!isSearchURL(url) || blockedState(doc, url)) return [];
    const main = doc.querySelector("main");
    if (!main) return [];
    const results = [], seen = /* @__PURE__ */ new Set();
    for (const a of main.querySelectorAll("a[href]")) {
      if (!rendered(a)) continue;
      const profileUrl = canonicalProfileURL(a.getAttribute("href") || "", url);
      if (!profileUrl || seen.has(profileUrl)) continue;
      const card = a.closest("li,article,[data-search-result],.reusable-search__result-container") || a.parentElement;
      const rawName = textOf(firstRendered(card || a, '[data-field="name"],.entity-result__title-text,h3') || a, 201), name = rawName.slice(0, 200);
      if (!name || /^(?:view|visit) profile$/i.test(name)) continue;
      seen.add(profileUrl);
      const rawSubtitle = textOf(firstRendered(card || a, '[data-field="headline"],.entity-result__primary-subtitle'), 901);
      results.push({ profileUrl, name, subtitle: rawSubtitle.slice(0, 900), profileReadAt: null, truncated: rawName.length > 200 || rawSubtitle.length > 900 });
    }
    return results;
  }
  function classifySearchPage(doc, url, status = 200) {
    const blocked = blockedState(doc, url, status);
    if (blocked) return { state: blocked, results: [], message: blocked === "auth_required" ? "Sign in to LinkedIn in this tab, then reopen the extension." : blocked === "blocked" ? "LinkedIn is blocking this search. Complete any verification yourself before trying again." : "The search page could not be read yet." };
    const results = readSearchResults(doc, url);
    if (results.length) return { state: "ready", results, message: "Select up to five people. Search snippets do not count as reading a profile." };
    const main = doc.querySelector("main");
    const headings = Array.from(main?.querySelectorAll('h1,h2,h3,[role="status"],.search-reusables__no-results') || []).filter(rendered).map((x) => textOf(x, 400)).join(" ");
    if (/no (?:matching )?results(?: found)?|could(?:n['’]t| not) find (?:any )?results|no people found/i.test(headings)) return { state: "empty", results: [], message: "LinkedIn explicitly reports no results for this search." };
    return { state: "unknown", results: [], message: "No readable search results yet. The page may still be loading or its layout may have changed." };
  }
  function snapshot(doc, url) {
    if (isSearchURL(url)) return { kind: "search", pageUrl: url, ...classifySearchPage(doc, url) };
    if (canonicalProfileURL(url)) {
      const blocked = blockedState(doc, url), profile = blocked ? null : readProfile(doc, url);
      return { kind: "profile", state: blocked || (profile?.profileReadAt ? "ready" : "unknown"), profile, message: blocked ? "This profile is not available to read in the current LinkedIn session." : profile?.profileReadAt ? "Context read from this rendered profile." : "Open the profile and let its sections load. There is not enough context yet." };
    }
    return { kind: "unsupported", state: "unknown", message: "Open a LinkedIn profile or a people search in this tab." };
  }

  // src/profile-panel.ts
  init_define_PUBLIC_CONFIG();

  // src/compact-profile.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/profile-activity.ts
  init_define_PUBLIC_CONFIG();
  var DAY2 = 864e5;
  var recentPrefix = "Recent rendered activity: ";
  var timestampPrefix = "Rendered activity timestamp: ";
  var fragments = /* @__PURE__ */ new Set(["#content_collections", "#recent-activity", "#activity"]);
  var record2 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  var unknown = () => Object.freeze({
    state: "unknown",
    label: "Activity not available",
    detail: "No verified activity sample is available. This does not mean the person is inactive.",
    visibleItemCount: null,
    observedAt: null,
    recentAtRead: false,
    timestamps: Object.freeze([]),
    topics: Object.freeze([])
  });
  function profileURL(value) {
    if (typeof value !== "string") return null;
    try {
      const url = new URL(value);
      if (url.protocol !== "https:" || url.hostname !== "www.linkedin.com" || url.username || url.password || url.port || url.search || url.hash || !/^\/in\/[^/?#]+\/$/.test(url.pathname) || url.href !== value) return null;
      decodeURIComponent(url.pathname);
      return value;
    } catch {
      return null;
    }
  }
  function absoluteDate(text3) {
    if (!/^\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2}))?$/.test(text3) && !/^(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\s+\d{1,2},?\s+\d{4}$/i.test(text3)) return null;
    const value = Date.parse(text3);
    if (!Number.isFinite(value)) return null;
    const date3 = text3.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (date3) {
      const day = new Date(Date.UTC(+date3[1], +date3[2] - 1, +date3[3]));
      if (day.getUTCFullYear() !== +date3[1] || day.getUTCMonth() !== +date3[2] - 1 || day.getUTCDate() !== +date3[3]) return null;
    }
    const named = text3.match(/^([A-Za-z]+)\s+(\d{1,2}),?\s+(\d{4})$/);
    if (named) {
      const month2 = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].indexOf(named[1].slice(0, 3).toLowerCase());
      const day = new Date(Date.UTC(+named[3], month2, +named[2]));
      if (day.getUTCFullYear() !== +named[3] || day.getUTCMonth() !== month2 || day.getUTCDate() !== +named[2]) return null;
    }
    return value;
  }
  function relativeUpperDays(text3) {
    text3 = text3.replace(/\s*(?:[•·]\s*)?edited$/i, "").trim();
    if (/^just now$/i.test(text3)) return 1 / 1440;
    if (/^today$/i.test(text3)) return 1;
    if (/^yesterday$/i.test(text3)) return 2;
    const match = text3.match(/^(\d+)\s*(years?|yrs?|y|months?|mo|weeks?|w|days?|d|hours?|h|minutes?|mins?|m|seconds?|secs?|s)(?:\s*(?:[•·]\s*)?edited)?$/i);
    if (!match) return null;
    const number = Number(match[1]), unit = match[2].toLowerCase();
    const factor = unit.startsWith("y") ? 366 : unit.startsWith("mo") ? 31 : unit.startsWith("w") ? 7 : unit.startsWith("d") ? 1 : unit.startsWith("h") ? 1 / 24 : unit.startsWith("m") ? 1 / 1440 : 1 / 86400;
    return Number.isSafeInteger(number) ? (number + 1) * factor : null;
  }
  function timestampInfo(text3, observed) {
    const exact = text3.match(/^(.*?) \(([^()]+)\)$/);
    if (exact) {
      const time2 = absoluteDate(exact[2]);
      if (time2 === null || time2 > observed) return null;
      return { recent: time2 >= observed - 90 * DAY2 };
    }
    const relative = relativeUpperDays(text3);
    if (relative !== null) return { recent: relative <= 90 };
    const time = absoluteDate(text3);
    return time === null || time > observed ? null : { recent: time >= observed - 90 * DAY2 };
  }
  function summarizeProfileActivity(input) {
    const profile = record2(input), url = profileURL(profile?.profileUrl), at = profile?.profileReadAt;
    if (!profile || !url || typeof at !== "string" || absoluteDate(at) === null || profile.truncated !== false || profile.source !== void 0 && profile.source !== "rendered_profile" || !Array.isArray(profile.anchors)) return unknown();
    const observed = Date.parse(at);
    const anchors = profile.anchors.map(record2).filter((anchor) => Boolean(anchor && anchor.observedAt === at && anchor.field === void 0 && anchor.currentExperience === void 0 && typeof anchor.sourceUrl === "string" && anchor.sourceUrl.startsWith(url) && fragments.has(anchor.sourceUrl.slice(url.length)) && typeof anchor.text === "string" && anchor.text.trim()));
    const items = anchors.filter((anchor) => anchor.kind === "activity");
    if (!items.length) return unknown();
    const itemSources = new Set(items.map((anchor) => anchor.sourceUrl));
    const timing = anchors.filter((anchor) => anchor.kind === "timing" && itemSources.has(anchor.sourceUrl));
    const timestamps = [], seenTimes = /* @__PURE__ */ new Set();
    for (const anchor of timing) {
      const sourceText = anchor.text;
      if (!sourceText.startsWith(timestampPrefix)) continue;
      const text3 = sourceText.slice(timestampPrefix.length);
      if (!timestampInfo(text3, observed)) continue;
      const key = anchor.sourceUrl + "\0" + text3;
      if (seenTimes.has(key)) continue;
      seenTimes.add(key);
      timestamps.push(Object.freeze({ text: text3, sourceText, sourceUrl: anchor.sourceUrl, observedAt: at, association: "activity_section" }));
    }
    const recentAtRead = timing.some((anchor) => {
      const sourceText = anchor.text;
      if (!sourceText.startsWith(recentPrefix)) return false;
      const literal = sourceText.slice(recentPrefix.length);
      return timestamps.some((stamp) => stamp.sourceUrl === anchor.sourceUrl && (stamp.text.replace(/\s*(?:[•·]\s*)?edited$/i, "").trim() === literal || stamp.text.startsWith(literal + " (")) && timestampInfo(stamp.text, observed)?.recent === true);
    });
    const topics = [], seenTopics = /* @__PURE__ */ new Set();
    for (const item of items) for (const match of item.text.matchAll(/(?<![\p{L}\p{N}_])#[\p{L}][\p{L}\p{N}_]{1,63}(?![\p{L}\p{N}_])/gu)) {
      const text3 = match[0], key = text3.toLocaleLowerCase("en-US");
      if (seenTopics.has(key)) continue;
      seenTopics.add(key);
      topics.push(Object.freeze({ text: text3, sourceUrl: item.sourceUrl, observedAt: at }));
    }
    const visibleItemCount = new Set(items.map((item) => item.sourceUrl + "\0" + item.text)).size;
    return Object.freeze({
      state: "observed",
      label: recentAtRead ? "Recent activity observed" : "Activity observed",
      detail: `${visibleItemCount} distinct activity ${visibleItemCount === 1 ? "item was" : "items were"} visible at the ${new Date(observed).toISOString().slice(0, 10)} profile read. This sample does not establish posting frequency or predict replies.`,
      visibleItemCount,
      observedAt: at,
      recentAtRead,
      timestamps: Object.freeze(timestamps),
      topics: Object.freeze(topics)
    });
  }

  // src/goal-assessment.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/assessment.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/company-evidence.ts
  init_define_PUBLIC_CONFIG();
  function companyKey(company) {
    return company.normalize("NFKC").replace(/&amp;/gi, "&").replace(/&#0*38;/g, "&").replace(/&quot;/gi, '"').trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
  }
  function companyOverlapFor(index, company) {
    return Object.hasOwn(index, companyKey(company)) ? index[companyKey(company)] : null;
  }

  // ../src/lib/evidence.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/knowledge.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/text.ts
  init_define_PUBLIC_CONFIG();
  function cleanText(value) {
    return value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g, "");
  }
  function stableStringify(value) {
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(",")}}`;
    return JSON.stringify(value) ?? "null";
  }
  function deepFreeze(value) {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
      Object.freeze(value);
      Object.values(value).forEach(deepFreeze);
    }
    return value;
  }

  // ../src/lib/resume.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/evidence.ts
  var text = (value) => typeof value === "string" ? cleanText(value).trim() : "";
  function evidenceKey(value) {
    const input = stableStringify(value);
    let a = 2166136261, b = 2654435769;
    for (let i = 0; i < input.length; i++) {
      a = Math.imul(a ^ input.charCodeAt(i), 16777619);
      b = Math.imul(b ^ input.charCodeAt(i), 2246822507);
    }
    return `${(a >>> 0).toString(16).padStart(8, "0")}${(b >>> 0).toString(16).padStart(8, "0")}`;
  }
  function candidateKey(input) {
    if (text(input.key || input.id)) return text(input.key || input.id);
    const raw = text(input.profile_url || input.url);
    if (raw) {
      try {
        const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
        if (url.protocol === "https:" || url.protocol === "http:") {
          const host = url.hostname.toLowerCase().replace(/^www\./, "");
          return `url:${host}${url.pathname.replace(/\/+$/, "")}`;
        }
      } catch {
      }
    }
    if (text(input.email)) return `email:${text(input.email).toLowerCase()}`;
    return `record:${evidenceKey([
      input.name || input.person || `${input.firstName || ""} ${input.lastName || ""}`,
      input.company || "",
      input.position || input.role || "",
      input.sourceLabel || ""
    ])}`;
  }
  function claim(input, discriminator = "") {
    return deepFreeze({ ...structuredClone(input), id: `claim:${evidenceKey([input, discriminator])}` });
  }
  function buildCandidateEvidence(input) {
    const key = candidateKey(input);
    const sourceKind = input.sourceKind ?? (input.firstName !== void 0 ? "archive" : "record");
    const sourceLabel = input.sourceLabel ?? (sourceKind === "archive" ? "Connection archive" : "Saved contact record");
    const sourceRef = text(input.profile_url || input.url) || `candidate:${key}`;
    const claims = [];
    const headlineClaimIds = /* @__PURE__ */ new Set();
    const add = (field, value, details = {}, discriminator = "") => {
      if (!text(value)) return;
      const item = claim({
        subject: "candidate",
        subjectKey: key,
        field,
        text: text(value),
        sourceKind,
        sourceLabel,
        sourceRef,
        ...input.observedAt ? { observedAt: input.observedAt } : {},
        confidence: sourceKind === "manual" ? "user_confirmed" : "observed",
        appliesTo: "contact",
        ...details
      }, discriminator);
      claims.push(item);
      return item;
    };
    const name = text(input.name || input.person || `${input.firstName || ""} ${input.lastName || ""}`);
    add("name", name);
    add("company", input.company);
    add("role", input.position || input.role);
    add("email", input.email);
    add("url", input.profile_url || input.url);
    for (const field of ["location", "industry", "stage", "check_size"]) add(field, input[field]);
    for (const [index, anchor] of (input.anchors ?? []).entries()) {
      const field = anchor.field ?? {
        headline: "context",
        experience: "context",
        about: "context",
        education: "education",
        skills: "skill",
        skill: "skill",
        location: "location",
        industry: "industry"
      }[anchor.kind] ?? "context";
      const added = add(field, anchor.text, {
        sourceKind: "profile",
        sourceLabel: `Rendered profile \xB7 ${anchor.kind}`,
        sourceRef: anchor.sourceUrl || sourceRef,
        ...anchor.observedAt ? { observedAt: anchor.observedAt } : {},
        appliesTo: anchor.appliesTo ?? "contact",
        ...anchor.polarity ? { polarity: anchor.polarity } : {}
      }, index);
      if (anchor.kind === "headline" && added) headlineClaimIds.add(added.id);
    }
    const manual = typeof input.manualContext === "string" ? [input.manualContext] : input.manualContext ?? [];
    manual.forEach((value, index) => add("context", value, { sourceKind: "manual", sourceLabel: "User-provided context", confidence: "user_confirmed" }, index));
    for (const item of input.claims ?? []) {
      if (item.subject !== "candidate" || item.subjectKey && item.subjectKey !== key || !text(item.text)) continue;
      claims.push(deepFreeze(structuredClone({ ...item, subjectKey: key })));
    }
    const unique = distinctEvidenceClaims(claims);
    const substantive = unique.some((item) => item.sourceKind === "profile" && !headlineClaimIds.has(item.id) && !["name", "url", "email", "role"].includes(item.field));
    return deepFreeze({
      key,
      name,
      company: text(input.company),
      claims: unique,
      profileReadAt: input.profileReadAt ?? null,
      completeProfile: Boolean(input.completeProfile && input.profileReadAt && substantive),
      companyOverlap: input.companyOverlap ? structuredClone(input.companyOverlap) : null
    });
  }
  function distinctEvidenceClaims(claims) {
    const result = /* @__PURE__ */ new Map();
    for (const item of claims) {
      const previous = result.get(item.id);
      if (previous && stableStringify(previous) !== stableStringify(item)) throw new TypeError("An evidence identifier refers to different claims.");
      if (!previous) result.set(item.id, item);
    }
    return [...result.values()];
  }
  function sortedEvidence(claims) {
    return [...claims].sort((a, b) => a.id.localeCompare(b.id) || stableStringify(a).localeCompare(stableStringify(b)));
  }

  // ../src/lib/assessment.ts
  function roleAbbreviations(value) {
    return value.replace(/\b(?:S\.V\.P\.?|E\.V\.P\.?|V\.P\.?|C\.A\.I\.O\.?)(?=$|[\s,;:!?/()&-])/gi, (title) => title.replace(/\./g, ""));
  }
  function phraseTokens(value) {
    return roleAbbreviations(value.normalize("NFKC")).toLocaleLowerCase("en-US").replace(/&amp;/g, "&").replace(/&/g, " and ").match(/[\p{L}\p{N}]+/gu) ?? [];
  }
  var normalized = (value) => phraseTokens(value).join(" ");
  var ALIASES = [
    ["ceo", "chief executive officer"],
    ["cfo", "chief financial officer"],
    ["coo", "chief operating officer"],
    ["cto", "chief technology officer"],
    ["cmo", "chief marketing officer"],
    ["chro", "chief human resources officer"],
    ["caio", "chief ai officer", "chief artificial intelligence officer"],
    ["vp", "vice president"],
    ["svp", "senior vice president"],
    ["evp", "executive vice president"],
    ["fmcg", "fast moving consumer goods"],
    ["cpg", "consumer packaged goods"],
    ["uk", "united kingdom"],
    ["usa", "united states", "united states of america"],
    ["nyc", "new york city"],
    ["saas", "software as a service"],
    ["pre seed", "preseed"]
  ];
  var alternativeCache = /* @__PURE__ */ new Map();
  function alternatives(term) {
    const cached = alternativeCache.get(term);
    if (cached) return cached;
    const normalizedTerm = normalized(term);
    const alias = ALIASES.find((group) => group.includes(normalizedTerm));
    const result = [.../* @__PURE__ */ new Set([normalizedTerm, ...alias ?? []])].filter(Boolean);
    if (alternativeCache.size >= 256) alternativeCache.clear();
    alternativeCache.set(term, result);
    return result;
  }
  var tokenCache = /* @__PURE__ */ new Map();
  function cachedTokens(value) {
    const cached = tokenCache.get(value);
    if (cached) return cached;
    const tokens = phraseTokens(value);
    if (tokenCache.size >= 512) tokenCache.clear();
    tokenCache.set(value, tokens);
    return tokens;
  }
  function findPhrase(value, term) {
    const tokens = cachedTokens(value), wanted = cachedTokens(term);
    if (!wanted.length) return [];
    const result = [];
    for (let i = 0; i <= tokens.length - wanted.length; i++) {
      if (!wanted.every((token, j) => token === tokens[i + j])) continue;
      if (wanted.join(" ") === "seed" && tokens[i - 1] === "pre" || wanted.join(" ") === "president" && tokens[i - 1] === "vice") continue;
      const before = tokens.slice(Math.max(0, i - 5), i);
      const negative = before.some((token, j) => ["not", "no", "never", "without"].includes(token) && before[j + 1] !== "only");
      result.push({ negative });
    }
    return result;
  }
  var sourceIsFactual = (claim2) => !["knowledge", "writing", "web"].includes(claim2.sourceKind) && !claim2.derivedFrom?.length;
  var headlineOrigin = (claim2) => claim2.sourceKind === "profile" && claim2.sourceLabel === "Rendered profile \xB7 headline";
  var executiveTerms = ["ceo", "cfo", "coo", "cto", "cmo", "chro", "caio", "vp", "svp", "evp", "president", "founder", "managing director", "general manager"];
  var investorTerms = ["investor", "angel investor", "venture capitalist", "vc", "venture partner", "investment partner"];
  var recruiterTerms = ["recruiter", "recruiting", "executive search", "talent acquisition", "headhunter"];
  var unsafeRoleContext = /\b(?:aspir(?:ing|ational|e)|seeking|seek|looking|exploring|former|formerly|previous|previously|retired|ex|wannabe|want|wants|become|becoming|not|never|without|no|assistant|assistants|advisors?|advisers?|coaching|coach|helping|supporting|reporting|reports|candidate|candidates|student|students|intern|internship)\b|\b(?:open to|in search|chief of staff|office of|working with)\b/;
  var uncurrentRole = (value) => /\b(?:aspir(?:ing|ational|e)|seeking|looking|exploring|former|formerly|previous|previously|retired|ex|wannabe|become|becoming)\b|\b(?:open to|in search)\b/.test(cachedTokens(value).join(" "));
  function titleSegments(value) {
    return roleAbbreviations(value).split(/[|•·;,\n]|\s[&/–—]\s|\s+and\s+/i).map((part) => cachedTokens(part).join(" ")).filter(Boolean);
  }
  function titleStarts(segment, term) {
    return alternatives(term).some((alias) => segment === alias || segment.startsWith(alias + " "));
  }
  function investorAuxiliary(value) {
    return /\binvestor (?:relations|services|communications|network|community|education|support|in people)\b|\b(?:vc|venture capitalist|venture partner|investment partner) (?:analyst|associate|intern|assistant|operations|services|research|relations|community|network)\b/.test(cachedTokens(value).join(" "));
  }
  function explicitInvestorRole(value) {
    const whole = cachedTokens(value).join(" ");
    return !unsafeRoleContext.test(whole) && !investorAuxiliary(value) && titleSegments(value).some((segment) => investorTerms.some((term) => titleStarts(segment, term)));
  }
  function explicitSeniorRole(value, provisional = false) {
    return !unsafeRoleContext.test(cachedTokens(value).join(" ")) && titleSegments(value).some((segment) => /^(?:(?:senior|executive|global|regional|group|managing) )?director(?: |$)/.test(segment) || !provisional && /\bdirector\b/.test(segment) || /^(?:(?:senior|global|regional) )?(?:engineering|research|finance|marketing|sales|product|operations|technology|people|hr|design|creative|strategy) director(?: |$)/.test(segment) || /^head of [a-z]/.test(segment) || /^chief (?:[a-z]+ ){1,5}officer(?: |$)/.test(segment));
  }
  function eligibleHeadline(claim2) {
    if (!headlineOrigin(claim2) || claim2.field !== "context" || claim2.appliesTo !== "contact" || claim2.polarity === "negative" || !sourceIsFactual(claim2) || !claim2.observedAt || !Number.isFinite(Date.parse(claim2.observedAt)) || unsafeRoleContext.test(cachedTokens(claim2.text).join(" "))) return false;
    try {
      const url = new URL(claim2.sourceRef ?? "");
      return url.protocol === "https:" && !url.username && !url.password && !url.port && ["www.linkedin.com", "linkedin.com"].includes(url.hostname) && /^\/in\/[^/?#]+\/?$/.test(url.pathname);
    } catch {
      return false;
    }
  }
  function headlineTitle(claim2, terms) {
    return titleSegments(claim2.text).some((segment) => terms.some((term) => titleStarts(segment, term)) && !/\b(?:search|jobs?|roles?|opportunities|tips|advice|solutions|tools?|relations|network|community)\b/.test(segment));
  }
  function hiringHeadline(claim2) {
    return titleSegments(claim2.text).some((segment) => /^(?:(?:we are|we re|i am|i m|currently|actively) )?hiring(?: |$)/.test(segment) && !/\bhiring (?:managers?|process|advice|tips|news|solutions|strategy|trends|expert|tools?|consultant|services)\b/.test(segment));
  }
  var executiveAliases = new Set(executiveTerms.flatMap(alternatives));
  var isExecutiveTerm = (term) => executiveAliases.has(alternatives(term)[0]);
  function auxiliaryExecutiveRole(value, term) {
    if (!isExecutiveTerm(term)) return false;
    const whole = cachedTokens(value).join(" ");
    return /(?:^| )(?:assistants?|advisors?|advisers?|chief of staff|office|reporting|reports)(?: directly)?(?: (?:to|of|for))? (?:the )?(?:(?:senior|executive) )?(?:ceo|cfo|coo|cto|cmo|chro|caio|vp|svp|evp|vice president|chief|president|founder|managing director|general manager)(?: |$)/.test(whole) || alternatives(term).some((alias) => ["assistant", "advisor", "adviser", "coach", "recruiter", "recruitment", "search", "office"].some((suffix) => ` ${whole} `.includes(` ${alias} ${suffix} `) || ` ${whole} `.includes(` ${alias} s ${suffix} `)));
  }
  function auxiliaryRole(value, term) {
    if (auxiliaryExecutiveRole(value, term)) return true;
    const context = cachedTokens(value).join(" "), wanted = normalized(term);
    if (investorTerms.includes(wanted)) return investorAuxiliary(value) || /\b(?:assistant|advisors?|advisers?|chief of staff)\b/.test(context);
    return /^(?:director|head of)(?: |$)/.test(wanted) && /\b(?:assistant|advisors?|advisers?|chief of staff)\b/.test(context);
  }
  function evaluateCriterion(criterion, claims) {
    const supported = /* @__PURE__ */ new Set(), contradicted = /* @__PURE__ */ new Set(), matched = /* @__PURE__ */ new Set();
    const usable = claims.filter((item) => item.subject === "candidate" && sourceIsFactual(item) && !headlineOrigin(item) && !(item.field === "role" && uncurrentRole(item.text)) && item.appliesTo === criterion.appliesTo && (item.field === criterion.field || criterion.field === "custom" && ["context", "custom", "skill", "education"].includes(item.field)));
    const terms = criterion.terms.filter((term) => normalized(term));
    for (const item of usable) {
      let hadPositive = false;
      for (const term of terms) {
        if (criterion.field === "role" && auxiliaryRole(item.text, term)) continue;
        for (const alias of alternatives(term)) {
          for (const clause of roleAbbreviations(item.text).split(/[.!?;\n]/u)) {
            const occurrences = findPhrase(clause, alias);
            if (!occurrences.length) continue;
            matched.add(term);
            for (const occurrence of occurrences) {
              if (item.polarity === "negative" || occurrence.negative) contradicted.add(item.id);
              else {
                supported.add(item.id);
                hadPositive = true;
              }
            }
          }
        }
      }
      if (!hadPositive && item.exclusive && item.polarity !== "negative" && terms.length) contradicted.add(item.id);
    }
    const status = supported.size && contradicted.size ? "conflicting" : supported.size ? "supported" : contradicted.size ? "contradicted" : "unknown";
    const scope2 = criterion.appliesTo === "opportunity" ? "opportunity" : "contact";
    const reason = status === "supported" ? `${criterion.label}: explicit ${scope2} evidence mentions ${[...matched].join(", ")}.` : status === "contradicted" ? `${criterion.label}: explicit ${scope2} evidence contradicts this criterion.` : status === "conflicting" ? `${criterion.label}: the cited ${scope2} evidence conflicts; review the sources.` : `${criterion.label}: ${scope2} ${criterion.field.replace("_", " ")} is not established by the available evidence.`;
    return {
      criterionId: criterion.id,
      field: criterion.field,
      label: criterion.label,
      appliesTo: criterion.appliesTo,
      importance: criterion.importance,
      origin: criterion.origin,
      status,
      claimIds: [.../* @__PURE__ */ new Set([...supported, ...contradicted])],
      supportingClaimIds: [...supported],
      contradictingClaimIds: [...contradicted],
      matchedTerms: [...matched],
      reason
    };
  }
  function validOverlap(candidate, options) {
    const value = options.companyIndex ? companyOverlapFor(options.companyIndex, candidate.company) : candidate.companyOverlap;
    return value && candidate.company && companyKey(value.company) === companyKey(candidate.company) && Number.isSafeInteger(value.count) && value.count >= 2 && value.statement === `You already know ${value.count} people at ${value.company}` ? value : null;
  }
  function candidateEvidence(candidate) {
    return "completeProfile" in candidate && "claims" in candidate && "key" in candidate && Array.isArray(candidate.claims) && typeof candidate.name === "string" && typeof candidate.company === "string" && "profileReadAt" in candidate ? candidate : buildCandidateEvidence(candidate);
  }
  function usableSharedTopic(claim2) {
    const tokens = cachedTokens(claim2.text), value = tokens.join(" ");
    if (!/[\p{L}]/u.test(value) || /^(?:none|unknown|unspecified|undisclosed|unavailable|n a|na|nil|null|tbd|not applicable|not provided|not available)(?: listed| provided| recorded| available)?$/.test(value)) return false;
    if (tokens.some((token, index) => ["not", "no", "never", "without"].includes(token) && tokens[index + 1] !== "only")) return false;
    if (claim2.field === "education" && /(?:date|year|month|start|end)/i.test(claim2.sourceLabel.split("\xB7").at(-1) ?? "")) return false;
    const dateTokens = /^(?:\d{1,4}|jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?|spring|summer|fall|autumn|winter|to|through|until|since|present|current|now)$/;
    return !(tokens.some((token) => /^\d{1,4}$/.test(token)) && tokens.every((token) => dateTokens.test(token)));
  }
  function prepare(goal, selfEvidence) {
    const sharedFacts = /* @__PURE__ */ new Map();
    for (const item of selfEvidence) {
      if (item.subject !== "self" || !["education", "skill", "role"].includes(item.field) || item.appliesTo !== "contact" || item.polarity === "negative" || !sourceIsFactual(item) || headlineOrigin(item) || item.text.length > 200 || !usableSharedTopic(item)) continue;
      if (item.field === "role" && unsafeRoleContext.test(cachedTokens(item.text).join(" "))) continue;
      const values = sharedFacts.get(item.field) ?? /* @__PURE__ */ new Map();
      values.set(normalized(item.text), item);
      sharedFacts.set(item.field, values);
    }
    return {
      goalKey: evidenceKey(goal),
      selfKey: evidenceKey(sortedEvidence(selfEvidence)),
      sharedFacts,
      selfCompanies: new Map(selfEvidence.filter((item) => item.subject === "self" && item.field === "company" && item.appliesTo === "contact" && sourceIsFactual(item) && !headlineOrigin(item) && item.polarity !== "negative").map((item) => [companyKey(item.text), item]))
    };
  }
  function sharedTopics(claims, prepared, shared) {
    const result = shared && usableSharedTopic(shared.contact) && usableSharedTopic(shared.own) ? [{ kind: "employer", text: `Employer in common: \u201C${shared.contact.text}\u201D.`, claimIds: [shared.contact.id, shared.own.id] }] : [];
    for (const field of ["education", "skill", "role"]) {
      const own2 = prepared.sharedFacts.get(field);
      if (!own2?.size) continue;
      for (const candidate of claims) {
        if (candidate.field !== field || candidate.appliesTo !== "contact" || candidate.polarity === "negative" || !sourceIsFactual(candidate) || headlineOrigin(candidate) || !usableSharedTopic(candidate)) continue;
        const value = normalized(candidate.text);
        let match = own2.get(value);
        if (!match && field === "role") match = alternatives(candidate.text).map((alias) => own2.get(alias)).find(Boolean);
        if (!match && field !== "role" && candidate.sourceKind === "profile") match = [...own2.values()].find((item) => findPhrase(candidate.text, item.text).some((found) => !found.negative));
        if (!match) continue;
        const kind = field === "role" ? "work" : field;
        const topic = field === "role" ? `Work in common: \u201C${match.text}\u201D.` : field === "skill" ? `Shared skill: \u201C${match.text}\u201D.` : `Shared education: \u201C${match.text}\u201D.`;
        result.push({ kind, text: topic, claimIds: [match.id, candidate.id] });
        break;
      }
    }
    return result;
  }
  function assess(goal, candidate, options, prepared, snapshot2 = true) {
    const candidateClaims = candidate.claims.filter((item) => item.subject === "candidate" && (!item.subjectKey || item.subjectKey === candidate.key));
    const criteria = goal.criteria.map((criterion) => evaluateCriterion(criterion, candidateClaims));
    const roles = candidateClaims.filter((item) => item.field === "role" && item.appliesTo === "contact" && sourceIsFactual(item) && !headlineOrigin(item) && !uncurrentRole(item.text) && item.polarity !== "negative");
    const headlines = candidateClaims.filter(eligibleHeadline);
    const companyClaims = candidateClaims.filter((item) => item.field === "company" && item.appliesTo === "contact" && sourceIsFactual(item) && !headlineOrigin(item) && item.polarity !== "negative");
    const sharedContact = companyClaims.find((item) => prepared.selfCompanies.has(companyKey(item.text)));
    const shared = sharedContact ? { contact: sharedContact, own: prepared.selfCompanies.get(companyKey(sharedContact.text)) } : void 0;
    const routes = [];
    const provisionalRoute = (kind, label2, matching, caveat) => {
      if (!matching.length || routes.some((route) => route.kind === kind)) return;
      routes.push({ kind, label: label2, provisional: true, reason: `${caveat} Headline: \u201C${matching[0].text}\u201D.`, claimIds: matching.map((item) => item.id) });
    };
    if (goal.kind === "career") {
      const executives = roles.filter((item) => executiveTerms.some((term) => !auxiliaryExecutiveRole(item.text, term) && alternatives(term).some((alias) => findPhrase(item.text, alias).some((match) => !match.negative))));
      if (executives.length) routes.push({
        kind: "executive_hiring",
        label: "Executive contact route",
        reason: "A recorded executive role offers a possible career contact route; hiring authority and openings remain unconfirmed.",
        claimIds: executives.map((item) => item.id)
      });
      const seniors = roles.filter((item) => !executives.includes(item) && explicitSeniorRole(item.text));
      if (seniors.length) routes.push({
        kind: "senior_contact",
        label: "Senior contact route",
        reason: "A recorded senior role offers a possible career conversation or introduction route; their access and willingness to help are unconfirmed.",
        claimIds: seniors.map((item) => item.id)
      });
      const recruiters = roles.filter((item) => recruiterTerms.some((term) => findPhrase(item.text, term).some((match) => !match.negative)));
      if (recruiters.length) routes.push({
        kind: "recruiter",
        label: "Recruiter route",
        reason: "A recorded recruiting role offers a possible career contact route; current mandates are unknown.",
        claimIds: recruiters.map((item) => item.id)
      });
      const roleCriteria = goal.criteria.filter((item) => item.field === "role");
      const opportunityRoles = roleCriteria.filter((item) => item.appliesTo === "opportunity");
      const targetRoles = (opportunityRoles.length ? opportunityRoles : roleCriteria).flatMap((item) => item.terms);
      const peers = roles.filter((item) => targetRoles.some((term) => !auxiliaryRole(item.text, term) && alternatives(term).some((alias) => findPhrase(item.text, alias).some((match) => !match.negative))));
      if (peers.length) routes.push({ kind: "peer", label: "Peer route", reason: "Their recorded role overlaps the target role; this is peer context, not evidence of a vacancy.", claimIds: peers.map((item) => item.id) });
      if (shared) routes.push({ kind: "introducer", label: "Shared-employer route", reason: `Both records name ${shared.contact.text}; an introduction may be worth discussing, but target access is unknown.`, claimIds: [shared.contact.id, shared.own.id] });
      const titledHeadlines = headlines.filter((item) => headlineTitle(item, [...executiveTerms, ...recruiterTerms]) || explicitSeniorRole(item.text, true) || titleSegments(item.text).some((segment) => /^(?:(?:senior|principal|staff|lead) )?(?:software engineer|data scientist|product manager|engineer|scientist|designer|architect|professor|hiring manager)(?: |$)/.test(segment)));
      provisionalRoute("peer", "Self-described peer route", titledHeadlines.filter((item) => headlineTitle(item, targetRoles)), "A self-described role may be useful peer context; the current role and openings are unconfirmed.");
      provisionalRoute("recruiter", "Self-described recruiter route", headlines.filter((item) => headlineTitle(item, recruiterTerms)), "A self-described recruiting role may offer a career contact; current mandates are unconfirmed.");
      provisionalRoute("executive_hiring", "Self-described executive route", headlines.filter((item) => headlineTitle(item, executiveTerms)), "A self-described executive role may offer a career contact; hiring authority and introductions are unconfirmed.");
      provisionalRoute("senior_contact", "Self-described senior route", headlines.filter((item) => explicitSeniorRole(item.text, true) && !headlineTitle(item, executiveTerms)), "A self-described senior role may offer a career conversation; access and willingness to introduce are unconfirmed.");
      provisionalRoute("hiring_signal", "Self-described hiring signal", headlines.filter(hiringHeadline), "The headline signals hiring interest; a current vacancy and its fit are unconfirmed.");
    }
    if (goal.kind === "fundraising") {
      const investors = roles.filter((item) => explicitInvestorRole(item.text));
      if (investors.length) routes.push({
        kind: "investor",
        label: "Investor contact route",
        reason: "A recorded investor role offers a possible fundraising contact; current investment mandate, stage, check size and willingness are unconfirmed.",
        claimIds: investors.map((item) => item.id)
      });
      provisionalRoute("investor", "Self-described investor route", headlines.filter((item) => explicitInvestorRole(item.text)), "A self-described investor role may offer a funding conversation; mandate, stage and check size are unconfirmed.");
    }
    const routePriority = { peer: 0, investor: 0, hiring_signal: 1, recruiter: 2, executive_hiring: 3, senior_contact: 4, introducer: 5 };
    routes.sort((a, b) => routePriority[a.kind] - routePriority[b.kind]);
    const supported = criteria.filter((item) => item.status === "supported"), conflicting = criteria.filter((item) => item.status === "conflicting");
    const contradicted = criteria.filter((item) => item.status === "contradicted");
    const requiredContradiction = contradicted.some((item) => item.importance === "required" && item.origin === "user");
    const status = conflicting.length ? "conflicting" : requiredContradiction ? "contradicted" : supported.length ? "supported" : routes.length ? "possible_route" : "unknown";
    const label = { conflicting: "Conflicting evidence", contradicted: "Evidence contradicts criteria", supported: "Evidence supports some criteria", possible_route: "Possible contact route", unknown: "More evidence needed" }[status];
    const details = [...conflicting, ...supported, ...contradicted].map((item) => ({ text: item.reason, claimIds: item.claimIds }));
    details.push(...routes.map((route) => ({ text: route.reason, claimIds: route.claimIds })));
    if (shared && !routes.some((route) => route.kind === "introducer")) details.push({ text: `Employer in common: \u201C${shared.contact.text}\u201D.`, claimIds: [shared.contact.id, shared.own.id] });
    const overlap = validOverlap(candidate, options);
    if (overlap) details.push({ text: `${overlap.statement}.`, claimIds: companyClaims.filter((item) => companyKey(item.text) === companyKey(overlap.company)).map((item) => item.id) });
    const unknowns = criteria.filter((item) => item.status === "unknown").map((item) => item.reason);
    if (routes.length) unknowns.push("Contact relevance does not establish an available opportunity or willingness to help.");
    if (routes.some((route) => route.provisional)) unknowns.push("Headline signals are self-descriptions only; they do not confirm current roles or satisfy goal criteria.");
    if (!candidate.completeProfile) unknowns.push("A complete profile has not been established; these records may be partial or outdated.");
    if (!criteria.length) unknowns.push("Confirm at least one goal criterion to assess evidence against it.");
    const rank = supported.reduce((sum, item) => sum + (item.origin === "suggested" ? 2 : item.importance === "required" ? 10 : 6), 0) + routes.reduce((sum, route) => sum + (route.provisional ? 1 : { peer: 8, investor: 4, hiring_signal: 1, executive_hiring: 3, senior_contact: 3, recruiter: 4, introducer: 2 }[route.kind]), 0) + (shared ? 1 : 0) - contradicted.length * 8 - conflicting.length * 4;
    const result = {
      goalId: goal.id,
      goalVersion: goal.version,
      candidateKey: candidate.key,
      label,
      status,
      reasons: details.map((item) => item.text),
      reasonDetails: details,
      unknowns,
      criteria,
      contactRoutes: routes,
      sharedContext: sharedTopics(candidateClaims, prepared, shared),
      evidenceCoverage: {
        total: criteria.length,
        supported: supported.length,
        contradicted: contradicted.length,
        conflicting: conflicting.length,
        unknown: criteria.filter((item) => item.status === "unknown").length,
        observedClaims: candidateClaims.filter(sourceIsFactual).length,
        completeProfile: candidate.completeProfile
      },
      rank,
      isMatch: Boolean(supported.length || routes.length) && (!requiredContradiction || Boolean(options.includeContradicted)),
      sharedEmployer: shared?.contact.text ?? null,
      companyOverlap: overlap ? structuredClone(overlap) : null,
      evidenceKey: snapshot2 ? evidenceKey([prepared.goalKey, sortedEvidence(candidateClaims), prepared.selfKey, candidate.completeProfile, overlap]) : ""
    };
    return snapshot2 ? deepFreeze(result) : result;
  }
  function assessCandidate(goal, candidate, selfEvidence = [], options = {}) {
    try {
      return assess(goal, candidateEvidence(candidate), options, prepare(goal, selfEvidence));
    } finally {
      tokenCache.clear();
      alternativeCache.clear();
    }
  }

  // src/goal-context.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/goals.ts
  init_define_PUBLIC_CONFIG();
  var kinds = ["career", "fundraising", "advisory", "partnership", "other"];
  var statuses = ["active", "paused", "completed"];
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var controls = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
  function object(value, label) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`);
    return value;
  }
  function text2(value, label, max) {
    if (typeof value !== "string" || !value.trim() || value.length > max || controls.test(value)) throw new TypeError(`${label} must contain readable text under ${max + 1} characters.`);
    return value;
  }
  function choice(value, allowed, label) {
    if (!allowed.includes(value)) throw new TypeError(`${label} is not recognized.`);
    return value;
  }
  function date2(value, label) {
    if (typeof value !== "string" || !/^\d{4}-\d\d-\d\dT/.test(value) || !Number.isFinite(Date.parse(value))) throw new TypeError(`${label} is invalid.`);
    return new Date(value).toISOString();
  }
  function list(value, label, max) {
    if (!Array.isArray(value) || value.length > max) throw new TypeError(`${label} must be an array with at most ${max} entries.`);
    return value;
  }
  function normalizeGoalCriterion(value) {
    const row = object(value, "Goal criterion");
    const id = text2(row.id, "Criterion identifier", 100);
    if (!/^[\w-]+$/.test(id)) throw new TypeError("Criterion identifier must contain letters, digits, underscores, or hyphens.");
    const terms = list(row.terms, "Criterion terms", 20).map((term) => text2(term, "Criterion term", 200).trim());
    return { id, field: choice(row.field, ["role", "industry", "location", "stage", "check_size", "custom"], "Criterion field"), label: text2(row.label, "Criterion label", 200), terms: [...new Set(terms)], importance: choice(row.importance, ["required", "preferred"], "Criterion importance"), appliesTo: choice(row.appliesTo, ["opportunity", "contact"], "Criterion subject"), origin: choice(row.origin, ["user", "suggested"], "Criterion origin") };
  }
  function normalizeGoal(value) {
    const row = object(value, "Goal");
    if (typeof row.id !== "string" || !UUID.test(row.id)) throw new TypeError("Goal identifier must be a UUID.");
    if (!Number.isSafeInteger(row.version) || Number(row.version) < 1 || Number(row.version) > 2147483647) throw new TypeError("Goal version must be a positive integer.");
    const criteria = list(row.criteria, "Goal criteria", 30).map(normalizeGoalCriterion);
    if (new Set(criteria.map((c) => c.id)).size !== criteria.length) throw new TypeError("Criterion identifiers must be distinct.");
    const goal = { id: row.id.toLowerCase(), kind: choice(row.kind, kinds, "Goal kind"), title: text2(row.title, "Goal title", 200), outcome: text2(row.outcome, "Goal outcome", 16e3), criteria, openQuestions: list(row.openQuestions, "Open questions", 30).map((q) => text2(q, "Open question", 1e3)), version: Number(row.version), status: choice(row.status, statuses, "Goal status"), createdAt: date2(row.createdAt, "Goal creation date"), updatedAt: date2(row.updatedAt, "Goal update date") };
    if (Date.parse(goal.updatedAt) < Date.parse(goal.createdAt)) throw new TypeError("Goal update cannot precede its creation.");
    if (new TextEncoder().encode(JSON.stringify(goal)).byteLength > 65536) throw new TypeError("The goal is too large to save.");
    return goal;
  }
  function normalizeGoalWorkspace(value) {
    const row = object(value, "Goal workspace");
    const goals = list(row.goals, "Goals", 100).map(normalizeGoal);
    if (new Set(goals.map((g) => g.id)).size !== goals.length) throw new TypeError("Goal identifiers must be distinct.");
    if (row.activeGoalId !== null && (typeof row.activeGoalId !== "string" || !goals.some((g) => g.id === row.activeGoalId && g.status === "active"))) throw new TypeError("Choose an active goal from this workspace.");
    return { goals, activeGoalId: row.activeGoalId };
  }

  // src/account-errors.ts
  init_define_PUBLIC_CONFIG();
  var messages = {
    not_configured: "This extension build is not connected to Mighty. Download a new copy from the app.",
    verification_unavailable: "Mighty could not reach account verification. Check your connection and reconnect.",
    verification_rejected: "Your app session could not be verified. Sign in to Mighty again, then reconnect.",
    verification_failed: "Account verification is temporarily unavailable. Try connecting again.",
    verification_unreadable: "Account verification returned an unreadable response. Try connecting again.",
    verification_invalid: "Account verification returned an invalid account. Reconnect from Mighty.",
    session_invalid: "The app session has an unsupported format. Sign in to Mighty again, then reconnect.",
    session_mismatch: "The app session does not match the verified account. Reconnect from Mighty.",
    session_project_mismatch: "The app and extension use different account services. Download the current extension from Mighty.",
    session_expired: "Your app session expired. Sign in to Mighty again, then reconnect.",
    session_lifetime: "The app session lasts longer than the extension allows. Update Mighty and reconnect.",
    goals_unavailable: "Account goals could not be refreshed. Check your connection and retry goals.",
    goals_session_rejected: "Account goals could not be loaded because the session expired. Sign in to Mighty again, then reconnect.",
    goals_forbidden: "Account goals could not be loaded because access was refused. Update Mighty and reconnect.",
    goals_failed: "Account goals could not be loaded. Retry goals in a moment.",
    goals_unreadable: "Account goals returned an unreadable response. Reconnect from Mighty.",
    goals_invalid: "Account goals are incompatible or incomplete. Update Mighty and reconnect; no previous goals are being used.",
    goals_incomplete: "Account goals could not be loaded completely. Retry goals; no previous goals are being used.",
    goals_cache_invalid: "Saved account goals could not be verified. Reconnect from Mighty.",
    connection_superseded: "A newer account connection replaced this request. Return to Mighty and try again.",
    connection_failed: "The account connection could not be completed. Reconnect from Mighty."
  };
  var AccountConnectionError = class extends Error {
    constructor(code) {
      super(messages[code]);
      this.code = code;
      this.name = "AccountConnectionError";
    }
    code;
  };

  // src/goal-context.ts
  var goalKeys = ["id", "kind", "title", "outcome", "criteria", "openQuestions", "version", "status", "createdAt", "updatedAt"];
  var criterionKeys = ["id", "field", "label", "terms", "importance", "appliesTo", "origin"];
  function exactKeys(value, allowed) {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !allowed.includes(key))) {
      throw Error("Account goals use an unsupported format. Update Mighty and reconnect.");
    }
  }
  function strictGoal(document2) {
    exactKeys(document2, goalKeys);
    const row = document2;
    if (Array.isArray(row.criteria)) row.criteria.forEach((item) => exactKeys(item, criterionKeys));
    return normalizeGoal(document2);
  }
  function contextKey(userId, goals) {
    return evidenceKey(["extension-account-goals-v1", userId, goals]);
  }
  function accountGoalContext(userId, rows, loadedAt = (/* @__PURE__ */ new Date()).toISOString()) {
    try {
      if (!Array.isArray(rows) || rows.length > 100 || !Number.isFinite(Date.parse(loadedAt))) throw Error();
      const goals = rows.map((value) => {
        if (!value || typeof value !== "object" || Array.isArray(value)) throw Error();
        const row = value;
        const goal = strictGoal(row.document);
        if (row.user_id !== userId || row.id !== goal.id || row.version !== goal.version) throw Error();
        return goal;
      });
      const checked = normalizeGoalWorkspace({ goals, activeGoalId: null }).goals;
      return deepFreeze({ schemaVersion: 1, userId, goals: checked, loadedAt, key: contextKey(userId, checked) });
    } catch {
      throw new AccountConnectionError("goals_invalid");
    }
  }
  function validateGoalContext(value, userId) {
    try {
      if (!value || typeof value !== "object") throw Error();
      const context = value;
      if (context.schemaVersion !== 1 || context.userId !== userId || !Array.isArray(context.goals)) throw Error();
      const checked = accountGoalContext(userId, context.goals.map((goal) => ({ id: goal.id, user_id: userId, version: goal.version, document: goal })), context.loadedAt);
      if (context.key !== checked.key) throw Error();
      return checked;
    } catch {
      throw new AccountConnectionError("goals_cache_invalid");
    }
  }

  // src/scoring.ts
  init_define_PUBLIC_CONFIG();
  var stop = new Set("a an and are as at be build building by connect connections find for from grow help i in interested is it looking me meet my network networking of on or people professional professionals relationships seeking that the their them to want with work working would your".split(" "));
  function canRequestBrief(profile) {
    return Boolean(profile?.profileReadAt && !profile.truncated && hasSubstantiveProfile(profile));
  }

  // ../src/lib/extension-self-context.ts
  init_define_PUBLIC_CONFIG();
  var SELF_CONTEXT_LIMITS = Object.freeze({ maxClaims: 40, maxText: 200, maxBytes: 2e4, lifetimeMs: 15 * 60 * 1e3 });
  var budgets = { company: 16, skill: 12, education: 8, role: 4 };
  var labels = { archive: "Your LinkedIn archive", profile: "Your profile", resume: "Your r\xE9sum\xE9", manual: "Your confirmed profile" };
  var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  var plain = (value) => Boolean(value && typeof value === "object" && !Array.isArray(value));
  var words = (value) => value.normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, " ").trim();
  var fieldKey = (value) => value.field + ":" + words(value.text);
  var safeText = (value) => typeof value === "string" && value.length > 0 && value.length <= SELF_CONTEXT_LIMITS.maxText && value === value.trim() && !/[\r\n\u0000-\u001f\u007f]|https?:\/\/|[\w.+-]+@[\w.-]+\.[a-z]{2,}/i.test(value) && /[\p{L}]/u.test(value);
  var own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
  function validateExtensionSelfContext(value, userId, now = Date.now()) {
    try {
      if (!plain(value) || Object.keys(value).some((key2) => !["schemaVersion", "userId", "capturedAt", "claims", "omittedCount", "key"].includes(key2)) || value.schemaVersion !== 1 || value.userId !== userId || !uuid.test(userId) || !Number.isSafeInteger(value.capturedAt) || Number(value.capturedAt) > now + 5e3 || Number(value.capturedAt) < now - SELF_CONTEXT_LIMITS.lifetimeMs || !Array.isArray(value.claims) || value.claims.length > SELF_CONTEXT_LIMITS.maxClaims || !Number.isSafeInteger(value.omittedCount) || Number(value.omittedCount) < 0 || Number(value.omittedCount) > 1e5 || new TextEncoder().encode(JSON.stringify(value)).length > SELF_CONTEXT_LIMITS.maxBytes) return null;
      const counts = {}, ids = /* @__PURE__ */ new Set(), facts = /* @__PURE__ */ new Set();
      for (const item of value.claims) {
        if (!plain(item) || Object.keys(item).some((key3) => !["id", "subject", "field", "text", "sourceKind", "sourceLabel", "observedAt", "confidence", "appliesTo", "polarity"].includes(key3)) || typeof item.id !== "string" || !/^[a-zA-Z0-9:_-]{1,100}$/.test(item.id) || ids.has(item.id) || item.subject !== "self" || item.appliesTo !== "contact" || item.polarity !== "positive" || typeof item.field !== "string" || !own(budgets, item.field) || !safeText(item.text) || typeof item.sourceKind !== "string" || !own(labels, item.sourceKind) || item.sourceLabel !== labels[item.sourceKind] || item.confidence !== (item.sourceKind === "manual" ? "user_confirmed" : "observed") || item.observedAt !== void 0 && (typeof item.observedAt !== "string" || item.observedAt.length > 30 || !Number.isFinite(Date.parse(item.observedAt)))) return null;
        const key2 = fieldKey(item);
        if (facts.has(key2) || (counts[item.field] = (counts[item.field] || 0) + 1) > budgets[item.field]) return null;
        ids.add(item.id);
        facts.add(key2);
      }
      const { key, ...body } = value;
      if (key !== evidenceKey(body)) return null;
      return deepFreeze(structuredClone(value));
    } catch {
      return null;
    }
  }

  // src/goal-assessment.ts
  function hasGoalCriteria(goal) {
    return goal.criteria.some((criterion) => criterion.terms.some((term) => /[\p{L}\p{N}]/u.test(term)));
  }
  function unreadReason(snapshot2) {
    if (snapshot2?.kind === "search") return "Open the person\u2019s profile. A search result does not contain enough profile evidence.";
    if (!snapshot2 || snapshot2.kind !== "profile") return "Open a LinkedIn profile to read its visible sections.";
    if (snapshot2.state === "auth_required") return "Sign in to LinkedIn in this tab so the profile can be read.";
    if (snapshot2.state === "blocked") return "LinkedIn is limiting this profile read. Complete any verification in this tab.";
    if (snapshot2.profile?.truncated) return "The rendered profile exceeds the save limit. A shortened read is not used to judge fit.";
    if (snapshot2.profile) return "The name is available, but a complete section read is not. Scroll to About or Experience and let the visible sections load.";
    return "The profile identity could not be verified in this layout. Let the page finish loading, then try again.";
  }
  function renderedCandidate(profile) {
    return buildCandidateEvidence({
      name: profile.name,
      url: profile.profileUrl,
      sourceKind: "profile",
      sourceLabel: "Rendered LinkedIn profile",
      profileReadAt: profile.profileReadAt,
      completeProfile: canRequestBrief(profile),
      observedAt: profile.profileReadAt ?? void 0,
      anchors: profile.anchors.map((anchor) => ({
        ...anchor,
        // Preserve raw text but refuse unsupported typed metadata before the shared engine sees it.
        field: anchor.field === void 0 ? void 0 : validCurrentExperienceAnchor(anchor, profile.anchors, profile.profileUrl, profile.profileReadAt) ? anchor.field : "context",
        appliesTo: "contact"
      }))
    });
  }
  function assessProfileGoals(userId, context, snapshot2, selfContext) {
    const trusted = validateGoalContext(context, userId);
    if (!snapshot2 || snapshot2.kind !== "profile" || snapshot2.state !== "ready" || !canRequestBrief(snapshot2.profile)) {
      return { state: "unread", message: unreadReason(snapshot2) };
    }
    if (!trusted.goals.length) return { state: "no_goals", message: "No goals are saved to this account. In Mighty, use Save goal to account to include a device draft here." };
    const goals = trusted.goals.filter((goal) => goal.status === "active");
    if (!goals.length) return { state: "no_active_goals", message: "This account has no active saved goals. Activate and save a goal in Mighty." };
    const candidate = renderedCandidate(snapshot2.profile);
    const self = validateExtensionSelfContext(selfContext, userId);
    return { state: "ready", candidate, contextKey: trusted.key + (self ? ":" + self.key : ""), assessments: goals.map((goal) => ({ goal, assessment: assessCandidate(goal, candidate, self?.claims ?? []) })) };
  }

  // src/compact-profile.ts
  function element(doc, tag, text3 = "", className = "") {
    const node = doc.createElement(tag);
    node.textContent = text3;
    node.className = className;
    return node;
  }
  function contactReason(assessment) {
    const route = assessment.contactRoutes[0];
    if (!route) return void 0;
    const source = route.provisional ? "Their headline describes" : "Their profile shows";
    switch (route.kind) {
      case "investor":
        return `${source} an investor role. Explore whether your venture fits their investment focus.`;
      case "hiring_signal":
        return "Their headline mentions hiring. Ask whether they know of opportunities aligned with your goal.";
      case "recruiter":
        return `${source} a recruiting role. They may know relevant openings or people to approach.`;
      case "executive_hiring":
      case "senior_contact":
        return `${source} a senior leadership role. They may offer a useful introduction or perspective on hiring.`;
      case "peer":
        return `${source} experience in your target role. They may offer advice or introduce you to relevant people.`;
      case "introducer":
        return "You have an employer in common. That gives you a starting point for a conversation or introduction.";
    }
  }
  function missingGoalDetails() {
    return { label: "Add goal details", tone: "unknown", reason: "Tell Mighty who you want to meet, then save your goal. Your profile preferences will help narrow the fit." };
  }
  function compactFit(assessment, goal) {
    if (goal ? !hasGoalCriteria(goal) : !assessment.criteria.length) {
      const route = assessment.contactRoutes[0];
      return route ? { label: "Possible fit", tone: "possible", reason: contactReason(assessment) || route.reason } : missingGoalDetails();
    }
    const reason = assessment.reasons[0] || "This profile does not yet establish relevance to this goal.";
    if (assessment.status === "conflicting") return { label: "Not enough information", tone: "unknown", reason: "The available facts conflict. Review this person in Mighty." };
    if (assessment.status === "contradicted") return { label: "Low fit", tone: "low", reason: assessment.criteria.find((row) => row.status === "contradicted" && row.importance === "required" && row.origin === "user")?.reason || reason };
    if (assessment.status === "unknown") {
      const focus = goal?.kind === "career" ? "a relevant hiring, leadership or peer connection" : goal?.kind === "fundraising" ? "an investor connection" : "a clear connection";
      return {
        label: "No clear connection yet",
        tone: "unknown",
        reason: `Mighty hasn't found ${focus} to this goal in the available profile. Save if you know more about them.`
      };
    }
    const defined = goal ? new Set(goal.criteria.filter((row) => row.terms.some((term) => /[\p{L}\p{N}]/u.test(term))).map((row) => row.id)) : null;
    const criteria = assessment.criteria.filter((row) => !defined || defined.has(row.criterionId));
    const contact = criteria.filter((row) => row.appliesTo === "contact");
    const userContact = contact.filter((row) => row.origin === "user");
    const strong = userContact.some((row) => row.field === "role" && row.status === "supported" && row.supportingClaimIds.length > 0) && userContact.every((row) => row.status === "supported") && contact.filter((row) => row.importance === "required").every((row) => row.status === "supported") && !criteria.some((row) => row.status === "contradicted" || row.status === "conflicting");
    const explanation = contactReason(assessment) || reason;
    const opportunityUnknown = criteria.some((row) => row.appliesTo === "opportunity" && row.status === "unknown");
    const caveat = strong && opportunityUnknown && goal?.kind === "career" ? " A matching opening is not confirmed." : "";
    return { label: strong ? "Strong potential" : "Possible fit", tone: strong ? "strong" : "possible", reason: explanation + caveat };
  }
  function concise(value) {
    const clean = value.replace(/\s+/g, " ").trim();
    return clean.length <= 230 ? clean : clean.slice(0, 220).replace(/\s+\S*$/, "") + "\u2026";
  }
  function profileIdentity(doc, profile) {
    const row = element(doc, "div", "", "profile-identity");
    const initials = profile.name.split(/\s+/).slice(0, 2).map((part) => part[0]).join("").toUpperCase();
    const avatar = element(doc, "span", initials, "profile-avatar");
    avatar.setAttribute("aria-hidden", "true");
    const photo = canonicalProfilePhotoUrl(profile.photoUrl);
    if (photo) {
      const image = doc.createElement("img");
      image.src = photo;
      image.alt = "";
      image.referrerPolicy = "no-referrer";
      image.addEventListener("error", () => avatar.replaceChildren(doc.createTextNode(initials)), { once: true });
      avatar.replaceChildren(image);
    }
    row.append(avatar, element(doc, "h1", profile.name));
    return row;
  }
  function compactProfile(doc, options) {
    const section = element(doc, "section", "", "compact-profile");
    const profile = options.page?.kind === "profile" ? options.page.profile : null;
    if (profile) section.append(profileIdentity(doc, profile));
    if (!options.connected) {
      section.append(element(doc, "p", "Connect Mighty to use your saved goals.", "hint"));
      return section;
    }
    if (!options.userId || !options.goalContext) {
      section.append(element(doc, "p", "Your saved goals are unavailable. Try again.", "hint"));
      return section;
    }
    try {
      const result = assessProfileGoals(options.userId, options.goalContext, options.page, options.selfContext);
      const goals = options.goalContext.goals.filter((goal) => goal.status === "active");
      if (!goals.length) {
        section.append(element(doc, "p", options.goalContext.goals.length ? "Activate a saved goal in Mighty." : "Save a goal to your account in Mighty.", "hint"));
        return section;
      }
      const fits = new Map(result.state === "ready" ? result.assessments.map((row) => [row.goal.id, compactFit(row.assessment, row.goal)]) : []);
      const priority = (goal) => fits.get(goal.id)?.tone === "strong" ? 2 : fits.get(goal.id)?.tone === "possible" ? 1 : 0;
      const selected = goals.find((goal) => goal.id === options.selectedGoalId) ?? goals.reduce((best, goal) => priority(goal) > priority(best) ? goal : best, goals[0]);
      const pills = element(doc, "div", "", "goal-pills");
      pills.setAttribute("role", "group");
      pills.setAttribute("aria-label", "Choose a goal");
      for (const goal of goals) {
        const button = element(doc, "button", goal.title, "goal-pill");
        button.type = "button";
        button.title = goal.title;
        button.setAttribute("aria-label", goal.title);
        button.setAttribute("aria-pressed", String(goal.id === selected.id));
        button.addEventListener("click", () => options.onSelect(goal.id));
        pills.append(button);
      }
      section.append(pills);
      const assessment = result.state === "ready" ? result.assessments.find((row) => row.goal.id === selected.id)?.assessment : null;
      const fit = fits.get(selected.id) ?? (!hasGoalCriteria(selected) ? missingGoalDetails() : { label: "Not enough information", tone: "unknown", reason: result.state === "unread" ? result.message : "The saved goal could not be assessed. Try loading it again." });
      const card = element(doc, "div", "", "goal-fit");
      card.dataset.goalId = selected.id;
      card.dataset.goalVersion = String(selected.version);
      const label = element(doc, "p", fit.label, "fit-label");
      label.dataset.fit = fit.tone;
      card.append(label, element(doc, "p", concise(fit.reason), "reason"));
      section.append(card);
      const topic = assessment?.sharedContext?.[0];
      if (topic) {
        const common = element(doc, "div", "", "shared-topic");
        common.append(element(doc, "span", "Talk about", "topic-label"), element(doc, "p", concise(topic.text)));
        section.append(common);
      }
      const activity = summarizeProfileActivity(profile);
      if (activity.state === "observed") {
        const signal = element(doc, "span", activity.label, "activity-signal");
        signal.title = activity.detail;
        section.append(signal);
      }
    } catch {
      section.append(element(doc, "p", "Saved goals could not be verified. Reconnect from Mighty.", "hint"));
    }
    return section;
  }
  var COMPACT_PROFILE_CSS = `
.compact-profile{color:#1D1B26}.profile-identity{display:flex;align-items:center;gap:13px;margin:5px 0 18px}
.profile-identity h1{font-size:21px;line-height:1.25;font-weight:750;letter-spacing:-.5px;margin:0;overflow-wrap:anywhere}
.profile-avatar{width:53px;height:53px;flex:none;display:grid;place-items:center;border-radius:50%;overflow:hidden;background:#EFEDFD;color:#4A3FD1;font-size:18px;font-weight:650}
.profile-avatar img{width:100%;height:100%;object-fit:cover}.goal-pills{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;max-height:152px;overflow:auto}
.goal-pill{width:100%;min-width:0;min-height:43px;border:1px solid #E5DFEA;border-radius:24px;padding:10px 9px;background:white;color:#6C6575;font-size:12px;font-weight:650;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.goal-pill[aria-pressed=true]{background:#EFEDFD;border-color:#CCC3F8;color:#4A3FD1;box-shadow:0 0 0 2px #4A3FD10A}
.compact-profile .goal-fit{padding:0;margin:23px 0 0;border:0;border-radius:0;background:none}
.compact-profile .fit-label{display:block;margin:0;padding:0;background:none;color:#4A3FD1;font-size:23px;line-height:1.25;font-weight:750;letter-spacing:-.5px}
.compact-profile .fit-label[data-fit=unknown]{background:none;color:#6C6575;font-weight:550}.compact-profile .fit-label[data-fit=low]{background:none;color:#836341}
.compact-profile .reason{font-size:14px;line-height:1.65;color:#403B49;margin:10px 0 0}.compact-profile .hint{font-size:13px;line-height:1.6;color:#6C6575;margin:12px 0 0}
.shared-topic{border-left:2px solid #E87A56;padding:0 0 0 11px;margin-top:17px;font-size:12px;line-height:1.5;color:#403B49}.topic-label{display:block;color:#8A563F;font-size:10px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;margin-bottom:3px}.shared-topic p{margin:0}.activity-signal{display:inline-flex;margin-top:15px;gap:6px;align-items:center;font-size:10px;color:#5B6860}.activity-signal:before{content:'';width:5px;height:5px;border-radius:50%;background:#6C927A}
`;

  // src/app-link.ts
  init_define_PUBLIC_CONFIG();
  function mightyAppLink(appBase, extensionId, connected) {
    const url = new URL(appBase);
    if (url.username || url.password || url.search || url.hash || url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
      throw Error("The Mighty app address is invalid.");
    }
    if (!url.pathname.endsWith("/")) url.pathname += "/";
    if (!connected) {
      if (!/^[a-p]{32}$/.test(extensionId)) throw Error("The extension identifier is invalid.");
      url.searchParams.set("mighty_extension", extensionId);
      url.hash = "connect-extension";
    }
    return url.href;
  }

  // src/panel-font.ts
  init_define_PUBLIC_CONFIG();
  var PANEL_FONT_FAMILY = "Mighty Panel Schibsted";
  function loadPanelFont(doc, url, Font = globalThis.FontFace) {
    try {
      if (!Font || !doc.fonts?.add) return;
      if ([...doc.fonts].some((face2) => face2.family === PANEL_FONT_FAMILY)) return;
      const face = new Font(PANEL_FONT_FAMILY, `url("${url}") format("woff2")`, { weight: "100 900", display: "swap" });
      doc.fonts.add(face);
      void face.load().catch(() => {
      });
    } catch {
    }
  }

  // src/profile-panel.ts
  function panelResourceURL(runtime, path) {
    try {
      const id = runtime.id;
      if (!id) return null;
      const url = runtime.getURL(path);
      return typeof url === "string" && url.startsWith("chrome-extension://" + id + "/") ? url : null;
    } catch {
      return null;
    }
  }
  function panelRuntimeAvailable(runtime) {
    return panelResourceURL(runtime, "") !== null;
  }
  function runtimeInvalidation(error) {
    return Boolean(error && typeof error === "object" && "message" in error && /extension context invalidated/i.test(String(error.message)));
  }
  function supportedPanelURL(url) {
    return Boolean(canonicalProfileURL(url));
  }
  function relevantPageMutation(records, host) {
    return records.some((record3) => {
      if (record3.target === host || host.contains(record3.target)) return false;
      if (record3.type !== "childList") return true;
      return [...record3.addedNodes, ...record3.removedNodes].some((node) => node !== host && !host.contains(node));
    });
  }
  function contentKey(page) {
    return JSON.stringify(page, (key, value) => ["observedAt", "profileReadAt"].includes(key) ? void 0 : value);
  }
  function profileSaveable(profile) {
    return Boolean(profile && !profile.truncationReasons.includes("snapshot_size_limit") && (profile.profileReadAt || profile.truncated && profile.anchors.length));
  }
  function createProfilePanel(options) {
    const { document: doc, runtime } = options;
    const fontURL = panelResourceURL(runtime, "assets/mighty-ui.woff2");
    const host = doc.createElement("aside");
    host.id = "mighty-profile-panel";
    const shadow = host.attachShadow({ mode: "closed" });
    if (fontURL) loadPanelFont(doc, fontURL);
    const style = doc.createElement("style");
    style.textContent = panelStyles() + COMPACT_PROFILE_CSS;
    const surface = element(doc, "section", "", "surface");
    surface.setAttribute("aria-label", "Mighty networking assistant");
    shadow.append(style, surface);
    if (fontURL) doc.documentElement.append(host);
    let disposed = false, page = null, pageKey = "", route = "", selectedGoalId = null;
    let account = { connected: false, userId: null, goalContext: null, appOrigin: "" };
    let checking = true, accountGeneration = 0, accountEpoch = 0, saving = false, notice = "", connectionDiagnostic = "";
    let minimized = false, skippedRoute = "";
    let port, reconnect, reconnectAttempts = 0;
    const operations = /* @__PURE__ */ new Map(), savedKeys = /* @__PURE__ */ new Set();
    function dispose2() {
      if (disposed) return;
      disposed = true;
      accountGeneration++;
      accountEpoch++;
      clearTimeout(reconnect);
      const previous = port;
      port = void 0;
      try {
        previous?.disconnect();
      } catch {
      }
      host.remove();
    }
    function invalidateRuntime() {
      if (disposed) return;
      dispose2();
      options.onRuntimeInvalidated?.();
    }
    function runtimeReady2() {
      if (disposed) return false;
      if (panelRuntimeAvailable(runtime)) return true;
      invalidateRuntime();
      return false;
    }
    function failedRuntime(error) {
      if (runtimeInvalidation(error) || !panelRuntimeAvailable(runtime)) {
        invalidateRuntime();
        return true;
      }
      return false;
    }
    const el = (tag, text3 = "", cls = "") => element(doc, tag, text3, cls);
    const pageSaved = () => page?.kind === "profile" && savedKeys.has(account.userId + "|" + page.profile?.profileUrl + "|" + pageKey);
    function brand() {
      const box = el("span", "", "brand");
      const mark = el("span", "", "brand-mark");
      mark.setAttribute("aria-hidden", "true");
      mark.append(el("span"), el("span"));
      box.append(mark, el("strong", "Mighty"));
      return box;
    }
    function appLink(text3, connect2 = !account.connected) {
      if (!account.appOrigin) return null;
      try {
        const link = el("a", text3, "app-link");
        link.href = mightyAppLink(account.appOrigin, runtime.id, !connect2);
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        return link;
      } catch {
        return null;
      }
    }
    function render() {
      if (!runtimeReady2()) return;
      host.hidden = !supportedPanelURL(options.url());
      if (host.hidden) return;
      const active = shadow.activeElement;
      const focusKey = active?.dataset.focus;
      surface.replaceChildren();
      if (minimized || skippedRoute === route) {
        surface.className = "surface collapsed";
        const reopen = el("button", "", "reopen");
        reopen.type = "button";
        reopen.setAttribute("aria-label", "Open Mighty panel");
        reopen.append(brand(), el("span", "Open", "reopen-label"));
        reopen.addEventListener("click", open);
        surface.append(reopen);
        return;
      }
      surface.className = "surface";
      const header = el("header");
      const minimize = el("button", "\u2212", "minimize");
      minimize.type = "button";
      minimize.dataset.focus = "minimize";
      minimize.title = "Minimize Mighty";
      minimize.setAttribute("aria-label", "Minimize Mighty");
      minimize.addEventListener("click", () => {
        minimized = true;
        render();
        surface.querySelector(".reopen")?.focus();
      });
      header.append(brand(), minimize);
      surface.append(header);
      const status = el("div", "", "account");
      status.append(el("span", checking ? "Checking account\u2026" : account.connected ? "Account connected" : "Account not connected", "account-state" + (account.connected ? " connected" : "")));
      const link = appLink(account.connected ? "Open Mighty" : "Connect to Mighty");
      if (link) status.append(link);
      surface.append(status);
      const main = el("div", "", "content");
      main.setAttribute("aria-busy", String(!page));
      main.append(compactProfile(doc, {
        page,
        connected: account.connected,
        userId: account.userId,
        goalContext: account.goalContext,
        selfContext: account.selfContext,
        selectedGoalId,
        onSelect: (id) => {
          selectedGoalId = id;
          render();
          surface.querySelector('.goal-pill[aria-pressed="true"]')?.focus();
        }
      }));
      if (!page) main.append(el("p", "Reading this profile\u2026", "hint"));
      if (page && page.state === "blocked") main.append(el("p", "LinkedIn is limiting this page. Check for a verification request.", "hint"));
      if (page && page.state === "auth_required") main.append(el("p", "Sign in to LinkedIn to read this profile.", "hint"));
      if (account.connected && !account.goalContext && !checking) {
        const retry = el("button", "Try again", "retry");
        retry.type = "button";
        retry.dataset.focus = "retry";
        retry.addEventListener("click", () => void refreshAccount(true));
        main.append(retry);
      }
      for (const text3 of new Set([notice, connectionDiagnostic || account.message].filter(Boolean))) {
        const message = el("p", text3, "notice");
        message.setAttribute("role", "status");
        main.append(message);
      }
      if (pageSaved()) {
        const view = appLink("View in Mighty", false);
        if (view) main.append(view);
      }
      surface.append(main);
      const footer = el("footer");
      const skip = el("button", "Skip", "skip");
      skip.type = "button";
      skip.dataset.focus = "skip";
      skip.addEventListener("click", () => {
        skippedRoute = route;
        render();
        surface.querySelector(".reopen")?.focus();
      });
      const save = el("button", saving ? "Saving\u2026" : pageSaved() ? "Saved to Mighty" : "Save to Mighty", "save");
      save.type = "button";
      save.dataset.focus = "save";
      save.disabled = saving || checking || !account.connected || !account.userId || !page || page.kind !== "profile" || !profileSaveable(page.profile) || Boolean(pageSaved());
      save.addEventListener("click", () => void saveSelected());
      footer.append(skip, save);
      surface.append(footer);
      if (focusKey) surface.querySelector(`[data-focus="${focusKey}"]`)?.focus();
    }
    async function send(message) {
      try {
        if (!runtimeReady2()) throw Error("Extension context invalidated.");
        const reply = await runtime.sendMessage(message);
        if (!reply?.ok) throw Error(reply?.message || "Mighty could not complete this request. Try again.");
        return reply;
      } catch (error) {
        failedRuntime(error);
        throw error;
      }
    }
    async function refreshAccount(refreshGoals = false) {
      if (!runtimeReady2()) return;
      const ticket = ++accountGeneration;
      checking = true;
      render();
      try {
        const result = await send({ type: "mighty:status", refreshGoals });
        if (disposed || ticket !== accountGeneration) return;
        connectionDiagnostic = "";
        if (account.userId !== result.userId) {
          accountEpoch++;
          selectedGoalId = null;
          operations.clear();
          savedKeys.clear();
        }
        account = { connected: result.connected === true, userId: result.userId || null, goalContext: result.connected ? result.goalContext || null : null, selfContext: result.connected ? result.selfContext || null : null, appOrigin: result.appOrigin, message: result.message };
      } catch (error) {
        if (disposed || ticket !== accountGeneration) return;
        accountEpoch++;
        account = { ...account, connected: false, userId: null, goalContext: null, selfContext: null, message: error instanceof Error ? error.message : "Reconnect from Mighty." };
        selectedGoalId = null;
      } finally {
        if (!disposed && ticket === accountGeneration) {
          checking = false;
          render();
        }
      }
    }
    function open() {
      if (!runtimeReady2()) return;
      minimized = false;
      skippedRoute = "";
      render();
      surface.querySelector(".minimize")?.focus();
    }
    async function saveSelected() {
      if (!runtimeReady2()) return;
      if (saving || checking || !account.connected || !account.userId || page?.kind !== "profile") return;
      if (!profileSaveable(page.profile) || pageSaved()) return;
      const source = "rendered_profile";
      const profiles = page.profile ? [page.profile] : [];
      if (!profiles.length) return;
      const owner = account.userId, epoch = accountEpoch, savedRoute = route, snapshotKey = pageKey;
      saving = true;
      notice = "";
      render();
      const results = await Promise.allSettled(profiles.map(async (item) => {
        const key = owner + "|" + item.profileUrl + "|" + source + "|" + contentKey({ kind: "profile", state: "ready", profile: item, message: "" });
        let request = operations.get(key);
        if (!request) {
          request = { operationId: crypto.randomUUID(), userId: owner, source, profile: structuredClone(item) };
          operations.set(key, request);
        }
        await send({ type: "mighty:save", save: request });
        operations.delete(key);
        return item.profileUrl;
      }));
      saving = false;
      if (disposed || epoch !== accountEpoch || savedRoute !== route) {
        if (!disposed) render();
        return;
      }
      const count = results.filter((row) => row.status === "fulfilled").length;
      for (const row of results) if (row.status === "fulfilled") {
        savedKeys.add(owner + "|" + row.value + "|" + snapshotKey);
      }
      const failure = results.find((row) => row.status === "rejected");
      notice = failure?.status === "rejected" ? (count ? `${count} saved. ` : "") + (failure.reason instanceof Error ? failure.reason.message : "That save did not finish. Try again.") : count === 1 ? "Saved to Relationships." : `${count} people saved to Relationships.`;
      render();
    }
    function readPage() {
      if (!runtimeReady2()) return;
      const current = options.url();
      if (!supportedPanelURL(current)) {
        host.hidden = true;
        page = null;
        pageKey = "";
        accountGeneration++;
        const previous = port;
        port = void 0;
        try {
          previous?.disconnect();
        } catch {
        }
        return;
      }
      const nextRoute = canonicalProfileURL(current) || current;
      const changed2 = route !== nextRoute;
      if (changed2) {
        route = nextRoute;
        page = null;
        pageKey = "";
        notice = "";
        selectedGoalId = null;
      }
      try {
        const next = (options.read || snapshot)(doc, current);
        const key = contentKey(next);
        if (key !== pageKey) {
          page = next;
          pageKey = key;
          render();
          void runtime.sendMessage({ type: "mighty:page_changed" }).catch((error) => {
            failedRuntime(error);
          });
        } else if (host.hidden) render();
      } catch (error) {
        if (failedRuntime(error)) return;
        page = null;
        pageKey = "";
        notice = "This profile could not be read. Refresh LinkedIn and try again.";
        render();
      }
      if (changed2) {
        connect();
        void refreshAccount(true);
      }
    }
    function connect() {
      if (!runtimeReady2() || port || !supportedPanelURL(options.url())) return;
      try {
        const current = runtime.connect({ name: "mighty:panel" });
        port = current;
        current.onMessage.addListener((message) => {
          if (port !== current || !runtimeReady2()) return;
          if (message?.type === "mighty:ready" && message.protocol === 1) {
            reconnectAttempts = 0;
            return;
          }
          if (message?.type === "mighty:panel_rejected") {
            if (typeof message.message === "string") connectionDiagnostic = message.message.slice(0, 300);
            else connectionDiagnostic = "Mighty could not verify this page. Refresh LinkedIn and try again.";
            render();
            return;
          }
          if (message?.type !== "mighty:account_changed") return;
          accountGeneration++;
          accountEpoch++;
          account = { ...account, connected: false, goalContext: null, selfContext: null };
          selectedGoalId = null;
          render();
          void refreshAccount();
        });
        current.onDisconnect.addListener(() => {
          try {
            void runtime.lastError;
          } catch {
          }
          if (disposed || port !== current) return;
          port = void 0;
          if (!runtimeReady2() || !supportedPanelURL(options.url())) return;
          accountGeneration++;
          accountEpoch++;
          account = { ...account, connected: false, userId: null, goalContext: null, selfContext: null };
          render();
          clearTimeout(reconnect);
          if (++reconnectAttempts > 8) {
            connectionDiagnostic ||= account.message || "Mighty could not reconnect. Refresh this page to try again.";
            render();
            return;
          }
          reconnect = setTimeout(() => {
            connect();
            void refreshAccount(true);
          }, Math.min(1e3, reconnectAttempts * 100));
        });
      } catch (error) {
        if (failedRuntime(error)) return;
        account = { ...account, connected: false, goalContext: null, selfContext: null };
        connectionDiagnostic = "Mighty was reloaded. Refresh this page to reconnect.";
        render();
      }
    }
    if (fontURL) readPage();
    else invalidateRuntime();
    return { host, shadow, readPage, refreshAccount, open, dispose: dispose2 };
  }
  function panelStyles() {
    return `
:host{all:initial;position:fixed;z-index:2147483646;top:82px;right:22px;bottom:auto;width:min(370px,calc(100vw - 24px));font:14px/1.5 '${PANEL_FONT_FAMILY}',Arial,Helvetica,sans-serif;color:#1D1B26;color-scheme:light}:host([hidden]){display:none!important}
*{box-sizing:border-box}button,input{font:inherit}button,a,input{-webkit-tap-highlight-color:transparent}:focus-visible{outline:2px solid #4A3FD1;outline-offset:3px}button{cursor:pointer}button:disabled{opacity:.42;cursor:not-allowed}a{color:#4A3FD1;text-decoration:none}a:hover{text-decoration:underline}p{margin:0;overflow-wrap:anywhere}h1{font-size:21px;line-height:1.3;margin:0 0 12px}
.surface{font:14px/1.5 '${PANEL_FONT_FAMILY}',Arial,Helvetica,sans-serif;background:#FBFAF8;border:1px solid #DED8E9;border-radius:22px;box-shadow:0 12px 38px #30204B24;overflow:hidden;max-height:min(650px,calc(100vh - 104px));display:flex;flex-direction:column}.surface *{font-family:inherit}
header{padding:18px 20px 12px;display:flex;align-items:center;justify-content:space-between;flex:none}.brand{display:flex;align-items:center;gap:10px}.brand strong{font-size:19px;font-weight:800;letter-spacing:-.3px}.brand-mark{position:relative;width:31px;height:22px;display:block;isolation:isolate}.brand-mark>span{position:absolute;width:22px;height:22px;border-radius:50%;background:#4A3FD1;left:0;top:0}.brand-mark>span+span{left:9px;background:#E87A56;mix-blend-mode:multiply}
.minimize{border:0;background:transparent;font-size:22px;color:#6C6575;width:36px;height:36px;border-radius:50%;padding:0}.minimize:hover{background:#EFEDFD}.account{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 20px 16px;font-size:11px;flex:none}.account-state{color:#6C6575;display:flex;align-items:center;gap:6px}.account-state:before{content:'';width:6px;height:6px;border-radius:50%;background:#AAA4B1}.account-state.connected:before{background:#4A3FD1}.app-link{font-size:12px;font-weight:650}.content{padding:0 20px 20px;overflow:auto;min-height:0;scrollbar-width:thin}.hint,.notice{font-size:12px;line-height:1.6;color:#6C6575;margin-top:12px}.notice{margin-top:15px}.retry{border:0;background:transparent;color:#4A3FD1;padding:8px 0;font-weight:650}.content>.app-link{display:inline-block;margin-top:10px}
footer{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:18px 20px;border-top:1px solid #E8E2EB;background:white;flex:none}footer button{border:1px solid #DDD6E3;border-radius:28px;min-height:49px;font-size:13px;font-weight:650;background:white;color:#423B50;padding:10px 8px}.save{background:#4A3FD1;border-color:#4A3FD1;color:white}footer button:hover:not(:disabled){filter:brightness(.97)}.collapsed{border-radius:28px;width:180px;margin-left:auto}.reopen{display:flex;align-items:center;justify-content:space-between;width:100%;gap:15px;border:0;background:#FBFAF8;padding:13px 17px}.reopen-label{color:#6C6575;font-size:11px}.reopen .brand strong{font-size:15px}.reopen .brand-mark{transform:scale(.8);margin-right:-4px}
.search-results{margin-top:13px}.result{display:flex;gap:10px;padding:12px 0;border-bottom:1px solid #E8E2EB}.result input{width:17px;height:17px;accent-color:#4A3FD1;flex:none;margin:2px 0}.result a{font-size:13px;font-weight:650}.result p{font-size:12px;line-height:1.5;color:#6C6575;margin-top:4px}
@media(max-width:600px){:host{top:72px;right:12px}.surface{max-height:calc(100vh - 84px)}}@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
`;
  }

  // src/panel-eligibility.ts
  init_define_PUBLIC_CONFIG();
  function profilePanelEligibility(doc, value) {
    const profileUrl = canonicalProfileURL(value);
    if (!profileUrl) return "unsupported";
    const top = profileTopCard(doc, value);
    if (!top) return "unknown";
    if (!top.matches('div[id^="com.linkedin.sdui.profile.card.ref"][id$="Topcard"],div[componentkey^="com.linkedin.sdui.profile.card.ref"][componentkey$="Topcard"]')) return "unknown";
    let other = false;
    for (const control of top.querySelectorAll('button,a,[role="button"]')) {
      if (!rendered(control)) continue;
      const labels2 = [control.getAttribute("aria-label") || "", textOf(control, 300)].map((label) => label.replace(/\s+/g, " ").trim().toLowerCase());
      let ownEdit = false;
      const href = control.getAttribute("href");
      if (href) {
        try {
          const url = new URL(href, profileUrl);
          ownEdit = url.href.startsWith(profileUrl + "edit/");
          if (url.protocol === "https:" && ["www.linkedin.com", "linkedin.com"].includes(url.hostname) && url.pathname === "/messaging/compose/" && url.searchParams.get("screenContext") === "NON_SELF_PROFILE_VIEW") other = true;
        } catch {
        }
      }
      if (ownEdit || labels2.some((label) => /^(?:edit(?: intro(?:duction)?| profile(?: photo)?| your profile)?|add profile section|add section|enhance profile)$/.test(label))) return "self";
      if (labels2.some((label) => /^(?:connect|message|follow)(?:\s|$)/.test(label) || /^invite .+ to connect$/.test(label))) other = true;
    }
    return other ? "other" : "unknown";
  }

  // src/content.ts
  var scope = globalThis;
  var availableRuntime;
  try {
    availableRuntime = chrome.runtime;
  } catch {
  }
  var validRuntime = availableRuntime && panelRuntimeAvailable(availableRuntime);
  if (validRuntime) {
    const previousHost = document.getElementById("mighty-profile-panel");
    try {
      scope.__mightyResearch?.dispose();
    } catch {
    }
    previousHost?.remove();
  }
  var supportedReadURL = () => Boolean(canonicalProfileURL(location.href) || isSearchURL(location.href));
  if (availableRuntime && validRuntime && supportedReadURL()) {
    let runtimeReady2 = function() {
      if (disposed) return false;
      if (panelRuntimeAvailable(runtime)) return true;
      dispose2();
      return false;
    }, read2 = function() {
      clearTimeout(timer);
      clearTimeout(maximum);
      timer = maximum = void 0;
      if (!runtimeReady2()) return;
      if (!supportedReadURL()) {
        dispose2();
        return;
      }
      lastUrl = location.href;
      if (profilePanelEligibility(document, location.href) === "other") {
        if (!panel) {
          const created = createProfilePanel({ document, runtime, url: () => location.href, onRuntimeInvalidated: dispose2 });
          if (disposed) created.dispose();
          else panel = created;
        } else panel.readPage();
      } else {
        panel?.dispose();
        panel = null;
        try {
          void runtime.sendMessage({ type: "mighty:page_changed" }).catch((error) => {
            if (runtimeInvalidation(error) || !panelRuntimeAvailable(runtime)) dispose2();
          });
        } catch (error) {
          if (runtimeInvalidation(error) || !panelRuntimeAvailable(runtime)) dispose2();
        }
      }
    }, changed2 = function(records) {
      if (!runtimeReady2() || records && panel && !relevantPageMutation(records, panel.host)) return;
      if (location.href !== lastUrl) {
        panel?.dispose();
        panel = null;
      }
      clearTimeout(timer);
      timer = setTimeout(read2, 180);
      if (!maximum) maximum = setTimeout(read2, 900);
    }, dispose2 = function() {
      if (disposed) return;
      disposed = true;
      observer.disconnect();
      clearTimeout(timer);
      clearTimeout(maximum);
      clearInterval(routes);
      try {
        runtime.onMessage.removeListener(listener);
      } catch {
      }
      removeEventListener("popstate", routeChanged);
      removeEventListener("focus", focus);
      panel?.dispose();
      panel = null;
      if (scope.__mightyResearch === mount) delete scope.__mightyResearch;
    };
    runtimeReady = runtimeReady2, read = read2, changed = changed2, dispose = dispose2;
    const runtime = availableRuntime;
    let panel = null;
    let disposed = false, lastUrl = location.href;
    let timer, maximum;
    const listener = (message, sender, respond) => {
      if (!runtimeReady2()) return;
      try {
        if (sender.id !== runtime.id || !message || typeof message !== "object" || !("type" in message) || message.type !== "mighty:read") return;
        respond(snapshot(document, location.href));
      } catch (error) {
        if (runtimeInvalidation(error) || !panelRuntimeAvailable(runtime)) dispose2();
        else throw error;
      }
    };
    const observer = new MutationObserver(changed2);
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["componentkey", "id", "href", "src", "alt", "class", "style", "hidden", "aria-hidden", "aria-label"] });
    const routeChanged = () => {
      if (runtimeReady2() && location.href !== lastUrl) {
        panel?.dispose();
        panel = null;
        read2();
      }
    };
    const focus = () => {
      if (disposed) return;
      read2();
      if (!disposed && panel) void panel.refreshAccount(true);
    };
    addEventListener("popstate", routeChanged);
    addEventListener("focus", focus);
    const routes = setInterval(routeChanged, 500);
    const mount = { dispose: dispose2 };
    scope.__mightyResearch = mount;
    try {
      runtime.onMessage.addListener(listener);
      read2();
    } catch (error) {
      dispose2();
      if (!runtimeInvalidation(error) && panelRuntimeAvailable(runtime)) throw error;
    }
  }
  var runtimeReady;
  var read;
  var changed;
  var dispose;
})();
