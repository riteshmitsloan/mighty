"use strict";
(() => {
  // src/dom.ts
  var excluded = "script,style,noscript,template,nav,footer,aside,.visually-hidden,.sr-only,.screen-reader-text";
  function rendered(element) {
    if (!element) return false;
    for (let p = element; p; p = p.parentElement) {
      if (p.matches(excluded) || p.hasAttribute("hidden")) return false;
      const inline = (p.getAttribute("style") || "").replace(/\s/g, "").toLowerCase();
      if (/(?:^|;)(display:none|visibility:hidden|visibility:collapse)(?:;|$|!important)/.test(inline)) return false;
      const view = p.ownerDocument.defaultView;
      if (view && typeof view.getComputedStyle === "function") {
        const s = view.getComputedStyle(p);
        if (s.display === "none" || s.visibility === "hidden" || s.visibility === "collapse") return false;
      }
    }
    return true;
  }
  function textOf(element, max = 1e3) {
    if (!element || !rendered(element)) return "";
    const walker = element.ownerDocument.createTreeWalker(element, 4);
    let text = "";
    let node;
    while ((node = walker.nextNode()) && text.length < max * 2) {
      if (rendered(node.parentElement)) text += " " + (node.nodeValue || "");
    }
    return text.replace(/\s+/g, " ").trim().slice(0, max);
  }
  function firstRendered(root, selectors) {
    return Array.from(root.querySelectorAll(selectors)).find(rendered) || null;
  }

  // ../src/lib/current-experience.ts
  var CURRENT_EXPERIENCE_LIMITS = Object.freeze({ field: 200, range: 80, entry: 8e3 });
  var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var date = "(?:(?:19|20)\\d{2}-\\d{2}-\\d{2}|(?:" + month + "\\s+)?(?:19|20)\\d{2})";
  var separator = "\\s*(?:[-\u2013\u2014]|to)\\s*";
  function currentExperienceDateRanges(text) {
    return [...text.matchAll(new RegExp("(?<![\\w-])" + date + separator + "(?:" + date + "|Present|Current)(?![\\w-])", "gi"))].map((match) => match[0].trim());
  }
  function validCurrentExperienceDate(range, observedAt) {
    if (typeof range !== "string" || range.length > CURRENT_EXPERIENCE_LIMITS.range || typeof observedAt !== "string") return false;
    const observed = Date.parse(observedAt);
    if (!Number.isFinite(observed)) return false;
    const match = range.match(new RegExp("^(" + date + ")" + separator + "(?:Present|Current)$", "i"));
    if (!match) return false;
    const start = match[1], exact = start.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let instant;
    if (exact) {
      instant = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const check = new Date(instant);
      if (check.getUTCFullYear() !== Number(exact[1]) || check.getUTCMonth() !== Number(exact[2]) - 1 || check.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const named = start.match(new RegExp("^(" + month + ")\\s+((?:19|20)\\d{2})$", "i"));
      instant = named ? Date.UTC(Number(named[2]), months.indexOf(named[1].slice(0, 3).toLowerCase()), 1) : Date.UTC(Number(start), 0, 1);
    }
    return Number.isFinite(instant) && instant <= observed;
  }

  // src/experience-fields.ts
  var labelField = /* @__PURE__ */ new Map([["job title", "role"], ["role", "role"], ["position", "role"], ["company", "company"], ["employer", "company"]]);
  var visible = (root, selector) => Array.from(root.querySelectorAll(selector)).filter(rendered);
  function currentExperienceFields(item, observedAt) {
    if (!item.matches("li") || !rendered(item) || visible(item, "li").length) return [];
    if (visible(item, "[itemscope]").some((node) => !node.matches('[itemprop~="worksFor"]'))) return [];
    const entryText = textOf(item, Infinity);
    if (!entryText || entryText.length > CURRENT_EXPERIENCE_LIMITS.entry) return [];
    const ranges = [...new Set(currentExperienceDateRanges(entryText))];
    if (ranges.length !== 1 || !validCurrentExperienceDate(ranges[0], observedAt)) return [];
    const dateRange = ranges[0];
    if (!visible(item, "*").some((node) => textOf(node, Infinity) === dateRange)) return [];
    if (visible(item, '[itemprop~="endDate"]').some((node) => !/^(?:present|current)$/i.test(textOf(node, Infinity)))) return [];
    const values = { role: /* @__PURE__ */ new Set(), company: /* @__PURE__ */ new Set() };
    let invalid = false;
    const add = (field, node) => {
      const value = textOf(node, Infinity);
      if (!value || value.length > CURRENT_EXPERIENCE_LIMITS.field || currentExperienceDateRanges(value).length) invalid = true;
      else values[field].add(value);
    };
    for (const node of visible(item, '[itemprop~="jobTitle"]')) {
      if (node.closest('[itemprop~="worksFor"]')) invalid = true;
      else add("role", node);
    }
    for (const employer of visible(item, '[itemprop~="worksFor"]')) {
      const names = visible(employer, '[itemprop~="name"]');
      if (names.length === 1) add("company", names[0]);
      else if (!names.length && !employer.children.length) add("company", employer);
      else invalid = true;
    }
    for (const term of visible(item, "dl > dt")) {
      const label = textOf(term, Infinity).toLowerCase(), field = labelField.get(label);
      const definition = term.nextElementSibling;
      if (field) {
        if (term.closest('[itemprop~="worksFor"]') || !definition?.matches("dd") || !rendered(definition) || definition.nextElementSibling?.matches("dd")) invalid = true;
        else add(field, definition);
      }
      if (["end date", "ended"].includes(label) && definition?.matches("dd") && rendered(definition) && !/^(?:present|current)$/i.test(textOf(definition, Infinity))) invalid = true;
    }
    if (invalid || values.role.size > 1 || values.company.size > 1) return [];
    return ["role", "company"].flatMap((field) => [...values[field]].map((text) => ({ field, text, currentExperience: { dateRange, entryText } })));
  }

  // src/urls.ts
  function canonicalProfileURL(value, base = "https://www.linkedin.com") {
    try {
      const u = new URL(value, base);
      if (u.protocol !== "https:" || !["linkedin.com", "www.linkedin.com"].includes(u.hostname.toLowerCase()) || u.port || u.username || u.password) return null;
      const m = u.pathname.match(/^\/in\/([^/]+)\/?$/);
      if (!m) return null;
      const slug = decodeURIComponent(m[1]).normalize("NFC").toLowerCase();
      if (!/^[\p{L}\p{N}_-]{1,200}$/u.test(slug)) return null;
      return "https://www.linkedin.com/in/" + encodeURIComponent(slug) + "/";
    } catch {
      return null;
    }
  }
  function isSearchURL(value) {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && ["www.linkedin.com", "linkedin.com"].includes(u.hostname) && /^\/search\/results\/people\/?$/.test(u.pathname);
    } catch {
      return false;
    }
  }

  // src/profile.ts
  function blockedState(doc, url, status = 200) {
    let path = "";
    try {
      path = new URL(url).pathname.toLowerCase();
    } catch {
      return "unknown";
    }
    if (status === 401 || /\/(authwall|login|uas\/login|signup)(?:\/|$)/.test(path)) return "auth_required";
    if ([403, 429].includes(status) || /\/(checkpoint|challenge|security-verification)(?:\/|$)/.test(path)) return "blocked";
    if (status < 200 || status >= 300) return "unknown";
    const main = doc.querySelector("main") || doc.body;
    const headings = Array.from(main?.querySelectorAll('h1,h2,[role="alert"]') || []).filter(rendered).map((x) => textOf(x, 300)).join(" ").toLowerCase();
    if (/security verification|verify (?:that )?you(?:'re| are) human|unusual activity|automated (?:activity|requests)|temporarily restricted|search (?:is )?(?:blocked|restricted|unavailable)|commercial use limit|search limit/.test(headings)) return "blocked";
    if (firstRendered(doc, 'iframe[src*="recaptcha"],iframe[src*="captcha"],form[action*="checkpoint"]')) return "blocked";
    if (/^(?:sign in|join linkedin|log in)(?:\s|$)/.test(headings) || firstRendered(main, 'form[action*="login"],form[action*="uas/login"]')) return "auth_required";
    return null;
  }
  var sections = [
    ["about", /^about$/i, ["about"]],
    ["experience", /^experience$/i, ["experience"]],
    ["education", /^education$/i, ["education"]],
    ["skills", /^skills$/i, ["skills"]],
    ["languages", /^languages$/i, ["languages"]],
    ["certifications", /^(?:licenses? (?:&|and) certifications?|certifications?)$/i, ["licenses_and_certifications"]],
    ["activity", /^activity(?:\s|$)/i, ["content_collections", "recent-activity", "activity"]]
  ];
  var substantiveKinds = /* @__PURE__ */ new Set(["about", "experience", "education", "skills", "languages", "certifications", "activity"]);
  function hasSubstantiveProfile(profile) {
    return Boolean(profile?.anchors.some((anchor) => substantiveKinds.has(anchor.kind) && anchor.text.trim().length > 0));
  }
  var MONTHS = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var MONTH = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var DAY = 864e5;
  function recentRoleStart(dateRange, now) {
    if (!/\b(?:Present|Current)\b/i.test(dateRange)) return false;
    const exact = dateRange.match(/\b((?:19|20)\d{2})-(\d{2})-(\d{2})\s*(?:[-–—]|to)\s*(?:Present|Current)\b/i);
    let start;
    if (exact) {
      start = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const date2 = new Date(start);
      if (date2.getUTCMonth() !== Number(exact[2]) - 1 || date2.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const match = dateRange.match(new RegExp("\\b(" + MONTH + ")\\s+((?:19|20)\\d{2})\\s*(?:[-\u2013\u2014]|to)\\s*(?:Present|Current)\\b", "i"));
      if (!match) return false;
      start = Date.UTC(Number(match[2]), MONTHS.indexOf(match[1].slice(0, 3).toLowerCase()), 1);
    }
    const observed = Date.parse(now);
    return Number.isFinite(observed) && start <= observed && start >= observed - 90 * DAY;
  }
  function dateRanges(text) {
    const expression = new RegExp("(?:" + MONTH + "\\s+)?(?:19|20)\\d{2}(?:-\\d{2}-\\d{2})?\\s*(?:[-\u2013\u2014]|to)\\s*(?:(?:" + MONTH + "\\s+)?(?:19|20)\\d{2}(?:-\\d{2}-\\d{2})?|Present|Current)", "gi");
    return [...text.matchAll(expression)].map((match) => match[0].trim());
  }
  function recentActivityDate(item, now) {
    const element = firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],.update-components-actor__sub-description,.feed-shared-actor__sub-description');
    if (!element) return null;
    const visible2 = textOf(element, Infinity), iso = element.getAttribute("datetime") || element.getAttribute("data-posted-at") || "";
    const observed = Date.parse(now);
    if (!Number.isFinite(observed) || !visible2) return null;
    if (iso) {
      const date2 = Date.parse(iso);
      if (Number.isFinite(date2) && date2 <= observed && date2 >= observed - 90 * DAY) return visible2 || iso;
      return null;
    }
    const relative = visible2.match(/(?:^|\s)(\d+)\s*(months?|mo|weeks?|w|days?|d|hours?|h|minutes?|mins?|m|seconds?|secs?|s)(?:\b|$)/i);
    if (relative) {
      const value = Number(relative[1]), unit = relative[2].toLowerCase();
      const factor = unit.startsWith("mo") ? 31 : unit.startsWith("w") ? 7 : unit.startsWith("d") ? 1 : unit.startsWith("h") ? 1 / 24 : unit.startsWith("m") ? 1 / 1440 : 1 / 86400;
      if (value >= 0 && (value + 1) * factor <= 90) return relative[0].trim();
      return null;
    }
    if (/^(?:just now|today|yesterday)(?:\s|[•·]|$)/i.test(visible2)) return visible2;
    if (new RegExp("\\b" + MONTH + "\\s+\\d{1,2},?\\s+(?:19|20)\\d{2}\\b", "i").test(visible2) || /^\d{4}-\d{2}-\d{2}/.test(visible2)) {
      const date2 = Date.parse(visible2);
      if (Number.isFinite(date2) && date2 <= observed && date2 >= observed - 90 * DAY) return visible2;
    }
    return null;
  }
  function sduiSubject(main, profileUrl) {
    const primary = Array.from(main.querySelectorAll('section[aria-label="Primary content"]')).filter(rendered);
    if (primary.length !== 1) return null;
    const scope2 = primary[0];
    const cards = Array.from(scope2.querySelectorAll('div[id^="com.linkedin.sdui.profile.card.ref"][id$="Topcard"],div[componentkey^="com.linkedin.sdui.profile.card.ref"][componentkey$="Topcard"]')).filter(rendered);
    if (cards.length !== 1) return null;
    const card = cards[0], markers = Array.from(card.querySelectorAll('[componentkey^="ProfileVerificationTriggerRef-"]')).filter(rendered);
    if (!markers.length) return null;
    let slug, decoded;
    try {
      slug = new URL(profileUrl).pathname.slice(4, -1);
      decoded = decodeURIComponent(slug);
    } catch {
      return null;
    }
    const expected = /* @__PURE__ */ new Set(["ProfileVerificationTriggerRef-" + slug, "ProfileVerificationTriggerRef-" + decoded]);
    const keys = new Set(markers.map((marker) => marker.getAttribute("componentkey") || ""));
    if (keys.size !== 1 || !expected.has(markers[0].getAttribute("componentkey") || "")) return null;
    const headings = [...new Set(markers.flatMap((marker) => Array.from(marker.querySelectorAll("h2")).filter(rendered)))];
    if (headings.length !== 1) return null;
    const heading = headings[0], top = heading.closest("section");
    if (!top || top === scope2 || !card.contains(top) || !rendered(top)) return null;
    if (markers.some((marker) => !marker.contains(heading) || marker.closest("section") !== top)) return null;
    return { heading, top, scope: scope2 };
  }
  function readProfile(doc, url, now = (/* @__PURE__ */ new Date()).toISOString()) {
    const profileUrl = canonicalProfileURL(url), main = doc.querySelector("main");
    if (!profileUrl || !main || blockedState(doc, url)) return null;
    const classic = firstRendered(main, "h1"), subject = classic ? { heading: classic, top: classic.closest("section") || main, scope: main } : sduiSubject(main, profileUrl);
    if (!subject) return null;
    const { heading, top, scope: scope2 } = subject, name = textOf(heading, Infinity);
    if (!name) return null;
    const truncationReasons = [];
    if (name.length > 200) truncationReasons.push("name_limit");
    const anchors = [], seen = /* @__PURE__ */ new Set();
    const add = (kind, text, fragment, typed) => {
      text = text.replace(/\s+/g, " ").trim();
      const key = kind + "\0" + (typed?.field || "") + "\0" + text + "\0" + (typed?.currentExperience?.entryText || "");
      if (text && text !== name && !seen.has(key)) {
        seen.add(key);
        anchors.push({ kind, text, sourceUrl: profileUrl + "#" + fragment, observedAt: now, ...typed });
      }
    };
    add("headline", textOf(firstRendered(top, '[data-field="headline"],.text-body-medium.break-words,.pv-text-details__left-panel .text-body-medium'), Infinity), "profile");
    add("location", textOf(firstRendered(top, '[data-field="location"],.text-body-small.inline.t-black--light.break-words,.pv-text-details__left-panel .text-body-small'), Infinity), "profile");
    for (const [kind, label, ids] of sections) {
      let section = null;
      for (const id2 of ids) {
        const exact = scope2.querySelector('[id="' + id2 + '"]');
        if (exact) {
          section = exact.closest("section");
          if (section) break;
        }
      }
      if (!section) {
        const h = Array.from(scope2.querySelectorAll("h2,h3")).find((x) => rendered(x) && label.test(textOf(x, 100)));
        section = h?.closest("section") || null;
      }
      if (!section || !rendered(section) || !classic && section === scope2) continue;
      const id = ids[0];
      if (kind === "activity") {
        const selector = 'article,[data-activity-item],[data-urn*="urn:li:activity:"],.feed-shared-update-v2';
        const semantic = Array.from(section.querySelectorAll(selector)).filter(rendered);
        const candidates = semantic.length ? semantic : Array.from(section.querySelectorAll("li")).filter(rendered);
        const items2 = candidates.filter((item) => !candidates.some((other) => other !== item && other.contains(item)));
        for (const item of items2) {
          const text = textOf(item, Infinity);
          if (!text) continue;
          const hasPost = Boolean(firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],a[href*="/feed/update/"],a[href*="/posts/"],.update-components-actor__sub-description,.feed-shared-actor__sub-description')) || item.matches('article,[data-activity-item],[data-urn*="urn:li:activity:"],.feed-shared-update-v2');
          if (!hasPost) continue;
          add("activity", text, id);
          const stamp = firstRendered(item, 'time,[data-field="posted-at"],[data-posted-at],.update-components-actor__sub-description,.feed-shared-actor__sub-description'), stampText = textOf(stamp, Infinity);
          if (stampText) {
            const exact = stamp?.getAttribute("datetime") || stamp?.getAttribute("data-posted-at");
            add("timing", "Rendered activity timestamp: " + stampText + (exact ? " (" + exact + ")" : ""), id);
          }
          const date2 = recentActivityDate(item, now);
          if (date2) add("timing", "Recent rendered activity: " + date2, id);
        }
        continue;
      }
      const items = Array.from(section.querySelectorAll("li")).filter((x) => rendered(x) && !x.parentElement?.closest("li"));
      for (const item of items.length ? items : [section]) {
        const text = textOf(item, Infinity);
        if (!text || label.test(text)) continue;
        const bodyOnly = text.replace(/^(?:about|experience|education|skills|languages|licenses? (?:&|and) certifications?|certifications?)\s*/i, "").replace(/(?:show all(?: \d+)?[^.]*|see more|show more|add (?:experience|education|skills))$/i, "").trim();
        if (!bodyOnly) continue;
        add(kind, text, id);
        if (kind === "experience" || kind === "education") for (const date2 of dateRanges(text)) {
          add("timing", date2, id);
          if (kind === "experience" && recentRoleStart(date2, now)) add("timing", "Recent role start indicated by \u201C" + date2 + "\u201D. The rendered start date or month falls within the last 90 days.", id);
        }
        if (kind === "experience") for (const field of currentExperienceFields(item, now)) add("experience", field.text, id, field);
      }
    }
    const missingSections = ["experience", "education", "location", "skills", "languages", "certifications", "activity"].filter((kind) => !anchors.some((anchor) => anchor.kind === kind));
    const profile = { profileUrl, name, anchors, profileReadAt: null, truncated: truncationReasons.length > 0, truncationReasons, missingSections };
    profile.profileReadAt = !truncationReasons.length && hasSubstantiveProfile(profile) ? now : null;
    if (new TextEncoder().encode(JSON.stringify(profile)).byteLength > 49152) {
      profile.truncationReasons.push("snapshot_size_limit");
      profile.truncated = true;
      profile.profileReadAt = null;
    }
    return profile;
  }
  function readSearchResults(doc, url) {
    if (!isSearchURL(url) || blockedState(doc, url)) return [];
    const main = doc.querySelector("main");
    if (!main) return [];
    const results = [], seen = /* @__PURE__ */ new Set();
    for (const a of main.querySelectorAll("a[href]")) {
      if (!rendered(a)) continue;
      const profileUrl = canonicalProfileURL(a.getAttribute("href") || "", url);
      if (!profileUrl || seen.has(profileUrl)) continue;
      const card = a.closest("li,article,[data-search-result],.reusable-search__result-container") || a.parentElement;
      const rawName = textOf(firstRendered(card || a, '[data-field="name"],.entity-result__title-text,h3') || a, 201), name = rawName.slice(0, 200);
      if (!name || /^(?:view|visit) profile$/i.test(name)) continue;
      seen.add(profileUrl);
      const rawSubtitle = textOf(firstRendered(card || a, '[data-field="headline"],.entity-result__primary-subtitle'), 901);
      results.push({ profileUrl, name, subtitle: rawSubtitle.slice(0, 900), profileReadAt: null, truncated: rawName.length > 200 || rawSubtitle.length > 900 });
    }
    return results;
  }
  function classifySearchPage(doc, url, status = 200) {
    const blocked = blockedState(doc, url, status);
    if (blocked) return { state: blocked, results: [], message: blocked === "auth_required" ? "Sign in to LinkedIn in this tab, then reopen the extension." : blocked === "blocked" ? "LinkedIn is blocking this search. Complete any verification yourself before trying again." : "The search page could not be read yet." };
    const results = readSearchResults(doc, url);
    if (results.length) return { state: "ready", results, message: "Select up to five people. Search snippets do not count as reading a profile." };
    const main = doc.querySelector("main");
    const headings = Array.from(main?.querySelectorAll('h1,h2,h3,[role="status"],.search-reusables__no-results') || []).filter(rendered).map((x) => textOf(x, 400)).join(" ");
    if (/no (?:matching )?results(?: found)?|could(?:n['’]t| not) find (?:any )?results|no people found/i.test(headings)) return { state: "empty", results: [], message: "LinkedIn explicitly reports no results for this search." };
    return { state: "unknown", results: [], message: "No readable search results yet. The page may still be loading or its layout may have changed." };
  }
  function snapshot(doc, url) {
    if (isSearchURL(url)) return { kind: "search", pageUrl: url, ...classifySearchPage(doc, url) };
    if (canonicalProfileURL(url)) {
      const blocked = blockedState(doc, url), profile = blocked ? null : readProfile(doc, url);
      return { kind: "profile", state: blocked || (profile?.profileReadAt ? "ready" : "unknown"), profile, message: blocked ? "This profile is not available to read in the current LinkedIn session." : profile?.profileReadAt ? "Context read from this rendered profile." : "Open the profile and let its sections load. There is not enough context yet." };
    }
    return { kind: "unsupported", state: "unknown", message: "Open a LinkedIn profile or a people search in this tab." };
  }

  // src/content.ts
  var scope = globalThis;
  scope.__mightyResearch?.dispose();
  var listener = (message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || message?.type !== "mighty:read") return;
    respond(snapshot(document, location.href));
  };
  chrome.runtime.onMessage.addListener(listener);
  var timer;
  var changed = () => {
    clearTimeout(timer);
    timer = setTimeout(() => {
      try {
        void chrome.runtime.sendMessage({ type: "mighty:page_changed" }).catch(() => {
        });
      } catch {
        observer.disconnect();
      }
    }, 100);
  };
  var observer = new MutationObserver(changed);
  observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  addEventListener("popstate", changed);
  scope.__mightyResearch = { dispose() {
    chrome.runtime.onMessage.removeListener(listener);
    observer.disconnect();
    clearTimeout(timer);
    removeEventListener("popstate", changed);
  } };
})();
