"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };

  // <define:__PUBLIC_CONFIG__>
  var init_define_PUBLIC_CONFIG = __esm({
    "<define:__PUBLIC_CONFIG__>"() {
    }
  });

  // src/popup.ts
  init_define_PUBLIC_CONFIG();

  // src/goal-assessment.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/assessment.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/company-evidence.ts
  init_define_PUBLIC_CONFIG();
  function companyKey(company) {
    return company.normalize("NFKC").replace(/&amp;/gi, "&").replace(/&#0*38;/g, "&").replace(/&quot;/gi, '"').trim().replace(/\s+/g, " ").toLocaleLowerCase("en-US");
  }
  function companyOverlapFor(index, company) {
    return Object.hasOwn(index, companyKey(company)) ? index[companyKey(company)] : null;
  }

  // ../src/lib/evidence.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/knowledge.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/text.ts
  init_define_PUBLIC_CONFIG();
  function cleanText(value) {
    return value.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g, "");
  }
  function stableStringify(value) {
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(",")}}`;
    return JSON.stringify(value) ?? "null";
  }
  function deepFreeze(value) {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
      Object.freeze(value);
      Object.values(value).forEach(deepFreeze);
    }
    return value;
  }

  // ../src/lib/resume.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/evidence.ts
  var text = (value) => typeof value === "string" ? cleanText(value).trim() : "";
  function evidenceKey(value) {
    const input = stableStringify(value);
    let a = 2166136261, b = 2654435769;
    for (let i = 0; i < input.length; i++) {
      a = Math.imul(a ^ input.charCodeAt(i), 16777619);
      b = Math.imul(b ^ input.charCodeAt(i), 2246822507);
    }
    return `${(a >>> 0).toString(16).padStart(8, "0")}${(b >>> 0).toString(16).padStart(8, "0")}`;
  }
  function candidateKey(input) {
    if (text(input.key || input.id)) return text(input.key || input.id);
    const raw = text(input.profile_url || input.url);
    if (raw) {
      try {
        const url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
        if (url.protocol === "https:" || url.protocol === "http:") {
          const host = url.hostname.toLowerCase().replace(/^www\./, "");
          return `url:${host}${url.pathname.replace(/\/+$/, "")}`;
        }
      } catch {
      }
    }
    if (text(input.email)) return `email:${text(input.email).toLowerCase()}`;
    return `record:${evidenceKey([
      input.name || input.person || `${input.firstName || ""} ${input.lastName || ""}`,
      input.company || "",
      input.position || input.role || "",
      input.sourceLabel || ""
    ])}`;
  }
  function claim(input, discriminator = "") {
    return deepFreeze({ ...structuredClone(input), id: `claim:${evidenceKey([input, discriminator])}` });
  }
  function buildCandidateEvidence(input) {
    const key = candidateKey(input);
    const sourceKind = input.sourceKind ?? (input.firstName !== void 0 ? "archive" : "record");
    const sourceLabel = input.sourceLabel ?? (sourceKind === "archive" ? "Connection archive" : "Saved contact record");
    const sourceRef = text(input.profile_url || input.url) || `candidate:${key}`;
    const claims = [];
    const headlineClaimIds = /* @__PURE__ */ new Set();
    const add = (field, value, details = {}, discriminator = "") => {
      if (!text(value)) return;
      const item = claim({
        subject: "candidate",
        subjectKey: key,
        field,
        text: text(value),
        sourceKind,
        sourceLabel,
        sourceRef,
        ...input.observedAt ? { observedAt: input.observedAt } : {},
        confidence: sourceKind === "manual" ? "user_confirmed" : "observed",
        appliesTo: "contact",
        ...details
      }, discriminator);
      claims.push(item);
      return item;
    };
    const name = text(input.name || input.person || `${input.firstName || ""} ${input.lastName || ""}`);
    add("name", name);
    add("company", input.company);
    add("role", input.position || input.role);
    add("email", input.email);
    add("url", input.profile_url || input.url);
    for (const field of ["location", "industry", "stage", "check_size"]) add(field, input[field]);
    for (const [index, anchor] of (input.anchors ?? []).entries()) {
      const field = anchor.field ?? {
        headline: "context",
        experience: "context",
        about: "context",
        education: "education",
        skills: "skill",
        skill: "skill",
        location: "location",
        industry: "industry"
      }[anchor.kind] ?? "context";
      const added = add(field, anchor.text, {
        sourceKind: "profile",
        sourceLabel: `Rendered profile \xB7 ${anchor.kind}`,
        sourceRef: anchor.sourceUrl || sourceRef,
        ...anchor.observedAt ? { observedAt: anchor.observedAt } : {},
        appliesTo: anchor.appliesTo ?? "contact",
        ...anchor.polarity ? { polarity: anchor.polarity } : {}
      }, index);
      if (anchor.kind === "headline" && added) headlineClaimIds.add(added.id);
    }
    const manual = typeof input.manualContext === "string" ? [input.manualContext] : input.manualContext ?? [];
    manual.forEach((value, index) => add("context", value, { sourceKind: "manual", sourceLabel: "User-provided context", confidence: "user_confirmed" }, index));
    for (const item of input.claims ?? []) {
      if (item.subject !== "candidate" || item.subjectKey && item.subjectKey !== key || !text(item.text)) continue;
      claims.push(deepFreeze(structuredClone({ ...item, subjectKey: key })));
    }
    const unique = distinctEvidenceClaims(claims);
    const substantive = unique.some((item) => item.sourceKind === "profile" && !headlineClaimIds.has(item.id) && !["name", "url", "email", "role"].includes(item.field));
    return deepFreeze({
      key,
      name,
      company: text(input.company),
      claims: unique,
      profileReadAt: input.profileReadAt ?? null,
      completeProfile: Boolean(input.completeProfile && input.profileReadAt && substantive),
      companyOverlap: input.companyOverlap ? structuredClone(input.companyOverlap) : null
    });
  }
  function distinctEvidenceClaims(claims) {
    const result = /* @__PURE__ */ new Map();
    for (const item of claims) {
      const previous = result.get(item.id);
      if (previous && stableStringify(previous) !== stableStringify(item)) throw new TypeError("An evidence identifier refers to different claims.");
      if (!previous) result.set(item.id, item);
    }
    return [...result.values()];
  }
  function sortedEvidence(claims) {
    return [...claims].sort((a, b) => a.id.localeCompare(b.id) || stableStringify(a).localeCompare(stableStringify(b)));
  }

  // ../src/lib/assessment.ts
  function phraseTokens(value) {
    return value.normalize("NFKC").toLocaleLowerCase("en-US").replace(/&amp;/g, "&").replace(/&/g, " and ").match(/[\p{L}\p{N}]+/gu) ?? [];
  }
  var normalized = (value) => phraseTokens(value).join(" ");
  var ALIASES = [
    ["ceo", "chief executive officer"],
    ["cfo", "chief financial officer"],
    ["coo", "chief operating officer"],
    ["cto", "chief technology officer"],
    ["cmo", "chief marketing officer"],
    ["chro", "chief human resources officer"],
    ["vp", "vice president"],
    ["svp", "senior vice president"],
    ["evp", "executive vice president"],
    ["fmcg", "fast moving consumer goods"],
    ["cpg", "consumer packaged goods"],
    ["uk", "united kingdom"],
    ["usa", "united states", "united states of america"],
    ["nyc", "new york city"],
    ["saas", "software as a service"],
    ["pre seed", "preseed"]
  ];
  var alternativeCache = /* @__PURE__ */ new Map();
  function alternatives(term) {
    const cached = alternativeCache.get(term);
    if (cached) return cached;
    const normalizedTerm = normalized(term);
    const alias = ALIASES.find((group) => group.includes(normalizedTerm));
    const result = [.../* @__PURE__ */ new Set([normalizedTerm, ...alias ?? []])].filter(Boolean);
    if (alternativeCache.size >= 256) alternativeCache.clear();
    alternativeCache.set(term, result);
    return result;
  }
  var tokenCache = /* @__PURE__ */ new Map();
  function cachedTokens(value) {
    const cached = tokenCache.get(value);
    if (cached) return cached;
    const tokens = phraseTokens(value);
    if (tokenCache.size >= 512) tokenCache.clear();
    tokenCache.set(value, tokens);
    return tokens;
  }
  function findPhrase(value, term) {
    const tokens = cachedTokens(value), wanted = cachedTokens(term);
    if (!wanted.length) return [];
    const result = [];
    for (let i = 0; i <= tokens.length - wanted.length; i++) {
      if (!wanted.every((token, j) => token === tokens[i + j])) continue;
      if (wanted.join(" ") === "seed" && tokens[i - 1] === "pre" || wanted.join(" ") === "president" && tokens[i - 1] === "vice") continue;
      const before = tokens.slice(Math.max(0, i - 5), i);
      const negative = before.some((token, j) => ["not", "no", "never", "without"].includes(token) && before[j + 1] !== "only");
      result.push({ negative });
    }
    return result;
  }
  var sourceIsFactual = (claim2) => !["knowledge", "writing", "web"].includes(claim2.sourceKind) && !claim2.derivedFrom?.length;
  var executiveTerms = ["ceo", "cfo", "coo", "cto", "cmo", "chro", "president", "founder", "managing director", "general manager"];
  var executiveAliases = new Set(executiveTerms.flatMap(alternatives));
  var isExecutiveTerm = (term) => executiveAliases.has(alternatives(term)[0]);
  function auxiliaryExecutiveRole(value, term) {
    if (!isExecutiveTerm(term)) return false;
    return /(?:assistant|advisor|adviser|chief of staff|office|reporting|reports) (?:to|of|for) (?:the )?(?:ceo|cfo|coo|cto|cmo|chro|chief |president|founder)/.test(cachedTokens(value).join(" "));
  }
  function evaluateCriterion(criterion, claims) {
    const supported = /* @__PURE__ */ new Set(), contradicted = /* @__PURE__ */ new Set(), matched = /* @__PURE__ */ new Set();
    const usable = claims.filter((item) => item.subject === "candidate" && sourceIsFactual(item) && item.appliesTo === criterion.appliesTo && (item.field === criterion.field || criterion.field === "custom" && ["context", "custom", "skill", "education"].includes(item.field)));
    const terms = criterion.terms.filter((term) => normalized(term));
    for (const item of usable) {
      let hadPositive = false;
      for (const term of terms) {
        if (criterion.field === "role" && auxiliaryExecutiveRole(item.text, term)) continue;
        for (const alias of alternatives(term)) {
          for (const clause of item.text.split(/[.!?;\n]/u)) {
            const occurrences = findPhrase(clause, alias);
            if (!occurrences.length) continue;
            matched.add(term);
            for (const occurrence of occurrences) {
              if (item.polarity === "negative" || occurrence.negative) contradicted.add(item.id);
              else {
                supported.add(item.id);
                hadPositive = true;
              }
            }
          }
        }
      }
      if (!hadPositive && item.exclusive && item.polarity !== "negative" && terms.length) contradicted.add(item.id);
    }
    const status = supported.size && contradicted.size ? "conflicting" : supported.size ? "supported" : contradicted.size ? "contradicted" : "unknown";
    const scope = criterion.appliesTo === "opportunity" ? "opportunity" : "contact";
    const reason = status === "supported" ? `${criterion.label}: explicit ${scope} evidence mentions ${[...matched].join(", ")}.` : status === "contradicted" ? `${criterion.label}: explicit ${scope} evidence contradicts this criterion.` : status === "conflicting" ? `${criterion.label}: the cited ${scope} evidence conflicts; review the sources.` : `${criterion.label}: ${scope} ${criterion.field.replace("_", " ")} is not established by the available evidence.`;
    return {
      criterionId: criterion.id,
      field: criterion.field,
      label: criterion.label,
      appliesTo: criterion.appliesTo,
      importance: criterion.importance,
      origin: criterion.origin,
      status,
      claimIds: [.../* @__PURE__ */ new Set([...supported, ...contradicted])],
      supportingClaimIds: [...supported],
      contradictingClaimIds: [...contradicted],
      matchedTerms: [...matched],
      reason
    };
  }
  function validOverlap(candidate, options) {
    const value = options.companyIndex ? companyOverlapFor(options.companyIndex, candidate.company) : candidate.companyOverlap;
    return value && candidate.company && companyKey(value.company) === companyKey(candidate.company) && Number.isSafeInteger(value.count) && value.count >= 2 && value.statement === `You already know ${value.count} people at ${value.company}` ? value : null;
  }
  function candidateEvidence(candidate) {
    return "completeProfile" in candidate && "claims" in candidate && "key" in candidate && Array.isArray(candidate.claims) && typeof candidate.name === "string" && typeof candidate.company === "string" && "profileReadAt" in candidate ? candidate : buildCandidateEvidence(candidate);
  }
  function prepare(goal, selfEvidence) {
    return {
      goalKey: evidenceKey(goal),
      selfKey: evidenceKey(sortedEvidence(selfEvidence)),
      selfCompanies: new Map(selfEvidence.filter((item) => item.subject === "self" && item.field === "company" && item.appliesTo === "contact" && sourceIsFactual(item) && item.polarity !== "negative").map((item) => [companyKey(item.text), item]))
    };
  }
  function assess(goal, candidate, options, prepared, snapshot = true) {
    const candidateClaims = candidate.claims.filter((item) => item.subject === "candidate" && (!item.subjectKey || item.subjectKey === candidate.key));
    const criteria = goal.criteria.map((criterion) => evaluateCriterion(criterion, candidateClaims));
    const roles = candidateClaims.filter((item) => item.field === "role" && item.appliesTo === "contact" && sourceIsFactual(item) && item.polarity !== "negative");
    const companyClaims = candidateClaims.filter((item) => item.field === "company" && item.appliesTo === "contact" && sourceIsFactual(item) && item.polarity !== "negative");
    const sharedContact = companyClaims.find((item) => prepared.selfCompanies.has(companyKey(item.text)));
    const shared = sharedContact ? { contact: sharedContact, own: prepared.selfCompanies.get(companyKey(sharedContact.text)) } : void 0;
    const routes = [];
    if (goal.kind === "career") {
      const executives = roles.filter((item) => executiveTerms.some((term) => !auxiliaryExecutiveRole(item.text, term) && alternatives(term).some((alias) => findPhrase(item.text, alias).some((match) => !match.negative))));
      if (executives.length) routes.push({
        kind: "executive_hiring",
        label: "Executive contact route",
        reason: "A recorded executive role offers a possible hiring contact route; hiring authority and openings remain unconfirmed.",
        claimIds: executives.map((item) => item.id)
      });
      const recruiters = roles.filter((item) => ["recruiter", "recruiting", "executive search", "talent acquisition", "headhunter"].some((term) => findPhrase(item.text, term).some((match) => !match.negative)));
      if (recruiters.length) routes.push({
        kind: "recruiter",
        label: "Recruiter route",
        reason: "A recorded recruiting role offers a possible career contact route; current mandates are unknown.",
        claimIds: recruiters.map((item) => item.id)
      });
      const targetRoles = goal.criteria.filter((item) => item.field === "role").flatMap((item) => item.terms);
      const peers = roles.filter((item) => targetRoles.some((term) => !auxiliaryExecutiveRole(item.text, term) && alternatives(term).some((alias) => findPhrase(item.text, alias).some((match) => !match.negative))));
      if (peers.length) routes.push({ kind: "peer", label: "Peer route", reason: "Their recorded role overlaps the target role; this is peer context, not evidence of a vacancy.", claimIds: peers.map((item) => item.id) });
      if (shared) routes.push({ kind: "introducer", label: "Shared-employer route", reason: `Both records name ${shared.contact.text}; an introduction may be worth discussing, but target access is unknown.`, claimIds: [shared.contact.id, shared.own.id] });
    }
    const routePriority = { peer: 0, recruiter: 1, executive_hiring: 2, introducer: 3 };
    routes.sort((a, b) => routePriority[a.kind] - routePriority[b.kind]);
    const supported = criteria.filter((item) => item.status === "supported"), conflicting = criteria.filter((item) => item.status === "conflicting");
    const contradicted = criteria.filter((item) => item.status === "contradicted");
    const requiredContradiction = contradicted.some((item) => item.importance === "required" && item.origin === "user");
    const status = conflicting.length ? "conflicting" : requiredContradiction ? "contradicted" : supported.length ? "supported" : routes.length ? "possible_route" : "unknown";
    const label = { conflicting: "Conflicting evidence", contradicted: "Evidence contradicts criteria", supported: "Evidence supports some criteria", possible_route: "Possible contact route", unknown: "More evidence needed" }[status];
    const details = [...conflicting, ...supported, ...contradicted].map((item) => ({ text: item.reason, claimIds: item.claimIds }));
    details.push(...routes.map((route) => ({ text: route.reason, claimIds: route.claimIds })));
    if (shared && !routes.some((route) => route.kind === "introducer")) details.push({ text: `Both records name ${shared.contact.text}.`, claimIds: [shared.contact.id, shared.own.id] });
    const overlap = validOverlap(candidate, options);
    if (overlap) details.push({ text: `${overlap.statement}.`, claimIds: companyClaims.filter((item) => companyKey(item.text) === companyKey(overlap.company)).map((item) => item.id) });
    const unknowns = criteria.filter((item) => item.status === "unknown").map((item) => item.reason);
    if (routes.length) unknowns.push("Contact relevance does not establish an available opportunity or willingness to help.");
    if (!candidate.completeProfile) unknowns.push("A complete profile has not been established; these records may be partial or outdated.");
    if (!criteria.length) unknowns.push("Confirm at least one goal criterion to assess evidence against it.");
    const rank = supported.reduce((sum, item) => sum + (item.origin === "suggested" ? 2 : item.importance === "required" ? 10 : 6), 0) + routes.reduce((sum, route) => sum + { peer: 8, executive_hiring: 3, recruiter: 4, introducer: 2 }[route.kind], 0) + (shared ? 1 : 0) - contradicted.length * 8 - conflicting.length * 4;
    const result = {
      goalId: goal.id,
      goalVersion: goal.version,
      candidateKey: candidate.key,
      label,
      status,
      reasons: details.map((item) => item.text),
      reasonDetails: details,
      unknowns,
      criteria,
      contactRoutes: routes,
      evidenceCoverage: {
        total: criteria.length,
        supported: supported.length,
        contradicted: contradicted.length,
        conflicting: conflicting.length,
        unknown: criteria.filter((item) => item.status === "unknown").length,
        observedClaims: candidateClaims.filter(sourceIsFactual).length,
        completeProfile: candidate.completeProfile
      },
      rank,
      isMatch: Boolean(supported.length || routes.length) && (!requiredContradiction || Boolean(options.includeContradicted)),
      sharedEmployer: shared?.contact.text ?? null,
      companyOverlap: overlap ? structuredClone(overlap) : null,
      evidenceKey: snapshot ? evidenceKey([prepared.goalKey, sortedEvidence(candidateClaims), prepared.selfKey, candidate.completeProfile, overlap]) : ""
    };
    return snapshot ? deepFreeze(result) : result;
  }
  function assessCandidate(goal, candidate, selfEvidence = [], options = {}) {
    try {
      return assess(goal, candidateEvidence(candidate), options, prepare(goal, selfEvidence));
    } finally {
      tokenCache.clear();
      alternativeCache.clear();
    }
  }

  // ../src/lib/current-experience.ts
  init_define_PUBLIC_CONFIG();
  var CURRENT_EXPERIENCE_LIMITS = Object.freeze({ field: 200, range: 80, entry: 8e3 });
  var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var date = "(?:(?:19|20)\\d{2}-\\d{2}-\\d{2}|(?:" + month + "\\s+)?(?:19|20)\\d{2})";
  var separator = "\\s*(?:[-\u2013\u2014]|to)\\s*";
  function currentExperienceDateRanges(text3) {
    return [...text3.matchAll(new RegExp("(?<![\\w-])" + date + separator + "(?:" + date + "|Present|Current)(?![\\w-])", "gi"))].map((match) => match[0].trim());
  }
  function validCurrentExperienceDate(range, observedAt) {
    if (typeof range !== "string" || range.length > CURRENT_EXPERIENCE_LIMITS.range || typeof observedAt !== "string") return false;
    const observed = Date.parse(observedAt);
    if (!Number.isFinite(observed)) return false;
    const match = range.match(new RegExp("^(" + date + ")" + separator + "(?:Present|Current)$", "i"));
    if (!match) return false;
    const start = match[1], exact = start.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let instant;
    if (exact) {
      instant = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const check = new Date(instant);
      if (check.getUTCFullYear() !== Number(exact[1]) || check.getUTCMonth() !== Number(exact[2]) - 1 || check.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const named = start.match(new RegExp("^(" + month + ")\\s+((?:19|20)\\d{2})$", "i"));
      instant = named ? Date.UTC(Number(named[2]), months.indexOf(named[1].slice(0, 3).toLowerCase()), 1) : Date.UTC(Number(start), 0, 1);
    }
    return Number.isFinite(instant) && instant <= observed;
  }
  var record = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  function validCurrentExperienceAnchor(anchor, anchors, profileUrl, profileReadAt) {
    const value = record(anchor);
    if (!value || value.kind !== "experience" || !["role", "company"].includes(String(value.field)) || typeof value.text !== "string" || !value.text.trim() || value.text.length > CURRENT_EXPERIENCE_LIMITS.field) return false;
    if (!profileReadAt || !Number.isFinite(Date.parse(profileReadAt)) || value.observedAt !== profileReadAt || value.sourceUrl !== profileUrl + "#experience") return false;
    if (value.appliesTo !== void 0 && value.appliesTo !== "contact" || value.polarity !== void 0 && value.polarity !== "positive") return false;
    const current = record(value.currentExperience);
    if (!current || Object.keys(current).some((key) => !["dateRange", "entryText"].includes(key)) || typeof current.dateRange !== "string" || typeof current.entryText !== "string") return false;
    if (!current.entryText.trim() || current.entryText.length > CURRENT_EXPERIENCE_LIMITS.entry || !validCurrentExperienceDate(current.dateRange, profileReadAt) || !current.entryText.includes(value.text) || !current.entryText.includes(current.dateRange)) return false;
    const ranges = [...new Set(currentExperienceDateRanges(current.entryText))];
    if (ranges.length !== 1 || ranges[0] !== current.dateRange) return false;
    const sameSource = (other) => other && other.sourceUrl === value.sourceUrl && other.observedAt === profileReadAt && other.field === void 0 && other.currentExperience === void 0;
    return anchors.some((other) => {
      const raw = record(other);
      return sameSource(raw) && raw.kind === "experience" && raw.text === current.entryText;
    }) && anchors.some((other) => {
      const timing = record(other);
      return sameSource(timing) && timing.kind === "timing" && timing.text === current.dateRange;
    });
  }

  // src/goal-context.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/goals.ts
  init_define_PUBLIC_CONFIG();
  var kinds = ["career", "fundraising", "advisory", "partnership", "other"];
  var statuses = ["active", "paused", "completed"];
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var controls = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
  function object(value, label) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`);
    return value;
  }
  function text2(value, label, max) {
    if (typeof value !== "string" || !value.trim() || value.length > max || controls.test(value)) throw new TypeError(`${label} must contain readable text under ${max + 1} characters.`);
    return value;
  }
  function choice(value, allowed, label) {
    if (!allowed.includes(value)) throw new TypeError(`${label} is not recognized.`);
    return value;
  }
  function date2(value, label) {
    if (typeof value !== "string" || !/^\d{4}-\d\d-\d\dT/.test(value) || !Number.isFinite(Date.parse(value))) throw new TypeError(`${label} is invalid.`);
    return new Date(value).toISOString();
  }
  function list(value, label, max) {
    if (!Array.isArray(value) || value.length > max) throw new TypeError(`${label} must be an array with at most ${max} entries.`);
    return value;
  }
  function normalizeGoalCriterion(value) {
    const row = object(value, "Goal criterion");
    const id = text2(row.id, "Criterion identifier", 100);
    if (!/^[\w-]+$/.test(id)) throw new TypeError("Criterion identifier must contain letters, digits, underscores, or hyphens.");
    const terms = list(row.terms, "Criterion terms", 20).map((term) => text2(term, "Criterion term", 200).trim());
    return { id, field: choice(row.field, ["role", "industry", "location", "stage", "check_size", "custom"], "Criterion field"), label: text2(row.label, "Criterion label", 200), terms: [...new Set(terms)], importance: choice(row.importance, ["required", "preferred"], "Criterion importance"), appliesTo: choice(row.appliesTo, ["opportunity", "contact"], "Criterion subject"), origin: choice(row.origin, ["user", "suggested"], "Criterion origin") };
  }
  function normalizeGoal(value) {
    const row = object(value, "Goal");
    if (typeof row.id !== "string" || !UUID.test(row.id)) throw new TypeError("Goal identifier must be a UUID.");
    if (!Number.isSafeInteger(row.version) || Number(row.version) < 1 || Number(row.version) > 2147483647) throw new TypeError("Goal version must be a positive integer.");
    const criteria = list(row.criteria, "Goal criteria", 30).map(normalizeGoalCriterion);
    if (new Set(criteria.map((c) => c.id)).size !== criteria.length) throw new TypeError("Criterion identifiers must be distinct.");
    const goal = { id: row.id.toLowerCase(), kind: choice(row.kind, kinds, "Goal kind"), title: text2(row.title, "Goal title", 200), outcome: text2(row.outcome, "Goal outcome", 16e3), criteria, openQuestions: list(row.openQuestions, "Open questions", 30).map((q) => text2(q, "Open question", 1e3)), version: Number(row.version), status: choice(row.status, statuses, "Goal status"), createdAt: date2(row.createdAt, "Goal creation date"), updatedAt: date2(row.updatedAt, "Goal update date") };
    if (Date.parse(goal.updatedAt) < Date.parse(goal.createdAt)) throw new TypeError("Goal update cannot precede its creation.");
    if (new TextEncoder().encode(JSON.stringify(goal)).byteLength > 65536) throw new TypeError("The goal is too large to save.");
    return goal;
  }
  function normalizeGoalWorkspace(value) {
    const row = object(value, "Goal workspace");
    const goals = list(row.goals, "Goals", 100).map(normalizeGoal);
    if (new Set(goals.map((g) => g.id)).size !== goals.length) throw new TypeError("Goal identifiers must be distinct.");
    if (row.activeGoalId !== null && (typeof row.activeGoalId !== "string" || !goals.some((g) => g.id === row.activeGoalId && g.status === "active"))) throw new TypeError("Choose an active goal from this workspace.");
    return { goals, activeGoalId: row.activeGoalId };
  }

  // src/account-errors.ts
  init_define_PUBLIC_CONFIG();
  var messages = {
    not_configured: "This extension build is not connected to Mighty. Download a new copy from the app.",
    verification_unavailable: "Mighty could not reach account verification. Check your connection and reconnect.",
    verification_rejected: "Your app session could not be verified. Sign in to Mighty again, then reconnect.",
    verification_failed: "Account verification is temporarily unavailable. Try connecting again.",
    verification_unreadable: "Account verification returned an unreadable response. Try connecting again.",
    verification_invalid: "Account verification returned an invalid account. Reconnect from Mighty.",
    session_invalid: "The app session has an unsupported format. Sign in to Mighty again, then reconnect.",
    session_mismatch: "The app session does not match the verified account. Reconnect from Mighty.",
    session_project_mismatch: "The app and extension use different account services. Download the current extension from Mighty.",
    session_expired: "Your app session expired. Sign in to Mighty again, then reconnect.",
    session_lifetime: "The app session lasts longer than the extension allows. Update Mighty and reconnect.",
    goals_unavailable: "Account goals could not be refreshed. Check your connection and reconnect from Mighty.",
    goals_session_rejected: "Account goals could not be loaded because the session expired. Sign in to Mighty again, then reconnect.",
    goals_forbidden: "Account goals could not be loaded because access was refused. Update Mighty and reconnect.",
    goals_failed: "Account goals could not be loaded. Try connecting again from Mighty.",
    goals_unreadable: "Account goals returned an unreadable response. Reconnect from Mighty.",
    goals_invalid: "Account goals are incompatible or incomplete. Update Mighty and reconnect; no previous goals are being used.",
    goals_incomplete: "Account goals could not be loaded completely. Reconnect from Mighty; no previous goals are being used.",
    goals_cache_invalid: "Saved account goals could not be verified. Reconnect from Mighty.",
    connection_superseded: "A newer account connection replaced this request. Return to Mighty and try again.",
    connection_failed: "The account connection could not be completed. Reconnect from Mighty."
  };
  var AccountConnectionError = class extends Error {
    constructor(code) {
      super(messages[code]);
      this.code = code;
      this.name = "AccountConnectionError";
    }
    code;
  };

  // src/goal-context.ts
  var goalKeys = ["id", "kind", "title", "outcome", "criteria", "openQuestions", "version", "status", "createdAt", "updatedAt"];
  var criterionKeys = ["id", "field", "label", "terms", "importance", "appliesTo", "origin"];
  function exactKeys(value, allowed) {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !allowed.includes(key))) {
      throw Error("Account goals use an unsupported format. Update Mighty and reconnect.");
    }
  }
  function strictGoal(document2) {
    exactKeys(document2, goalKeys);
    const row = document2;
    if (Array.isArray(row.criteria)) row.criteria.forEach((item) => exactKeys(item, criterionKeys));
    return normalizeGoal(document2);
  }
  function contextKey(userId2, goals) {
    return evidenceKey(["extension-account-goals-v1", userId2, goals]);
  }
  function accountGoalContext(userId2, rows, loadedAt = (/* @__PURE__ */ new Date()).toISOString()) {
    try {
      if (!Array.isArray(rows) || rows.length > 100 || !Number.isFinite(Date.parse(loadedAt))) throw Error();
      const goals = rows.map((value) => {
        if (!value || typeof value !== "object" || Array.isArray(value)) throw Error();
        const row = value;
        const goal = strictGoal(row.document);
        if (row.user_id !== userId2 || row.id !== goal.id || row.version !== goal.version) throw Error();
        return goal;
      });
      const checked = normalizeGoalWorkspace({ goals, activeGoalId: null }).goals;
      return deepFreeze({ schemaVersion: 1, userId: userId2, goals: checked, loadedAt, key: contextKey(userId2, checked) });
    } catch {
      throw new AccountConnectionError("goals_invalid");
    }
  }
  function validateGoalContext(value, userId2) {
    try {
      if (!value || typeof value !== "object") throw Error();
      const context = value;
      if (context.schemaVersion !== 1 || context.userId !== userId2 || !Array.isArray(context.goals)) throw Error();
      const checked = accountGoalContext(userId2, context.goals.map((goal) => ({ id: goal.id, user_id: userId2, version: goal.version, document: goal })), context.loadedAt);
      if (context.key !== checked.key) throw Error();
      return checked;
    } catch {
      throw new AccountConnectionError("goals_cache_invalid");
    }
  }

  // src/scoring.ts
  init_define_PUBLIC_CONFIG();

  // src/profile.ts
  init_define_PUBLIC_CONFIG();

  // src/dom.ts
  init_define_PUBLIC_CONFIG();

  // src/experience-fields.ts
  init_define_PUBLIC_CONFIG();

  // src/urls.ts
  init_define_PUBLIC_CONFIG();

  // src/profile.ts
  var substantiveKinds = /* @__PURE__ */ new Set(["about", "experience", "education", "skills", "languages", "certifications", "activity"]);
  function hasSubstantiveProfile(profile) {
    return Boolean(profile?.anchors.some((anchor) => substantiveKinds.has(anchor.kind) && anchor.text.trim().length > 0));
  }

  // src/scoring.ts
  var stop = new Set("a an and are as at be build building by connect connections find for from grow help i in interested is it looking me meet my network networking of on or people professional professionals relationships seeking that the their them to want with work working would your".split(" "));
  function canRequestBrief(profile) {
    return Boolean(profile?.profileReadAt && !profile.truncated && hasSubstantiveProfile(profile));
  }

  // src/goal-assessment.ts
  function renderedCandidate(profile) {
    return buildCandidateEvidence({
      name: profile.name,
      url: profile.profileUrl,
      sourceKind: "profile",
      sourceLabel: "Rendered LinkedIn profile",
      profileReadAt: profile.profileReadAt,
      completeProfile: canRequestBrief(profile),
      observedAt: profile.profileReadAt ?? void 0,
      anchors: profile.anchors.map((anchor) => ({
        ...anchor,
        // Preserve raw text but refuse unsupported typed metadata before the shared engine sees it.
        field: anchor.field === void 0 ? void 0 : validCurrentExperienceAnchor(anchor, profile.anchors, profile.profileUrl, profile.profileReadAt) ? anchor.field : "context",
        appliesTo: "contact"
      }))
    });
  }
  function assessProfileGoals(userId2, context, snapshot) {
    const trusted = validateGoalContext(context, userId2);
    if (!snapshot || snapshot.kind !== "profile" || snapshot.state !== "ready" || !canRequestBrief(snapshot.profile)) {
      return { state: "unread", message: "Open a profile and read its visible sections. Search snippets and incomplete reads are not assessed." };
    }
    if (!trusted.goals.length) return { state: "no_goals", message: "No goals are saved to this account. In Mighty, use Save goal to account to include a device draft here." };
    const goals = trusted.goals.filter((goal) => goal.status === "active");
    if (!goals.length) return { state: "no_active_goals", message: "This account has no active saved goals. Activate and save a goal in Mighty." };
    const candidate = renderedCandidate(snapshot.profile);
    return { state: "ready", candidate, contextKey: trusted.key, assessments: goals.map((goal) => ({ goal, assessment: assessCandidate(goal, candidate, []) })) };
  }

  // src/app-link.ts
  init_define_PUBLIC_CONFIG();
  function mightyAppLink(appBase, extensionId, connected2) {
    const url = new URL(appBase);
    if (url.username || url.password || url.search || url.hash || url.protocol !== "https:" && !(url.protocol === "http:" && ["localhost", "127.0.0.1"].includes(url.hostname))) {
      throw Error("The Mighty app address is invalid.");
    }
    if (!url.pathname.endsWith("/")) url.pathname += "/";
    if (!connected2) {
      if (!/^[a-p]{32}$/.test(extensionId)) throw Error("The extension identifier is invalid.");
      url.searchParams.set("mighty_extension", extensionId);
      url.hash = "connect-extension";
    }
    return url.href;
  }

  // src/selection.ts
  init_define_PUBLIC_CONFIG();
  var MAX_SELECTED = 5;
  function initialSelection(results) {
    return new Set(results.slice(0, MAX_SELECTED).map((x) => x.profileUrl));
  }
  function toggleSelection(current, url, checked) {
    const selected2 = new Set(current);
    if (!checked) {
      selected2.delete(url);
      return { selected: selected2, message: "" };
    }
    if (selected2.has(url)) return { selected: selected2, message: "" };
    if (selected2.size >= MAX_SELECTED) return { selected: selected2, message: "You can select up to five people. Uncheck someone first." };
    selected2.add(url);
    return { selected: selected2, message: "" };
  }

  // src/popup.ts
  var body = document.querySelector("#content");
  var account = document.querySelector("#account");
  var notice = document.querySelector("#notice");
  var saveButton = document.querySelector("#save");
  var selectionSummary = document.querySelector("#selection-summary");
  var state = null;
  var userId = null;
  var goalContext = null;
  var refreshPending = false;
  var goalRefreshPending = false;
  var lastRefreshError = "";
  var accountEpoch = 0;
  var connected = false;
  var selected = /* @__PURE__ */ new Set();
  var saving = false;
  var readGeneration = 0;
  var operations = /* @__PURE__ */ new Map();
  var sectionLabels = {
    headline: "Headline",
    location: "Location",
    about: "About",
    experience: "Experience",
    education: "Education",
    skills: "Skills",
    languages: "Languages",
    certifications: "Licenses & certifications",
    activity: "Activity",
    timing: "Timing"
  };
  function el(tag, text3, cls) {
    const node = document.createElement(tag);
    if (text3) node.textContent = text3;
    if (cls) node.className = cls;
    return node;
  }
  function readableError(message) {
    if (/snapshot size limit/i.test(message)) return "This profile is too large to save. Its full context has not been saved.";
    if (/profile snapshot is invalid|evidence anchor is invalid/i.test(message)) return "This profile could not be saved. Reopen it and try again.";
    if (/different account|account that owns this pending save/i.test(message)) return "Reconnect the account you used for this save.";
    if (/prototype.*Supabase/i.test(message)) return "This extension build is not connected to Mighty. Download a new copy from the app.";
    if (/save identifier already belongs/i.test(message)) return "This save could not be retried. Reopen the profile and try again.";
    if (/handoff|bridge|protocol|origin is not allowed/i.test(message)) return "Reconnect the extension from Mighty.";
    return message;
  }
  async function send(message) {
    try {
      const reply = await chrome.runtime.sendMessage(message);
      if (!reply?.ok) throw Error(reply?.message || "Mighty did not respond. Reopen the extension.");
      return reply;
    } catch (error) {
      throw Error(readableError(error instanceof Error ? error.message : "Mighty was reloaded. Close and reopen the extension."));
    }
  }
  function report(message) {
    notice.textContent = message;
  }
  function invalidateAccountView() {
    connected = false;
    goalContext = null;
    const label = account.querySelector(".account-state");
    if (label) {
      label.textContent = "Account not connected";
      label.classList.remove("connected");
    }
  }
  function updateSave() {
    saveButton.disabled = saving || !connected || !state || (state.kind === "profile" ? !(state.profile?.profileReadAt || state.profile?.truncated && state.profile.anchors.length) : state.kind === "search" ? !selected.size : true);
    selectionSummary.textContent = state?.kind === "search" && state.results.length ? `${selected.size} selected \xB7 ${state.results.length} visible` : "";
  }
  function pageNotice(snapshot) {
    if (snapshot.kind === "unsupported") return "Open a LinkedIn profile or people search.";
    if (snapshot.state === "auth_required") return "Sign in to LinkedIn in this tab, then reopen Mighty.";
    if (snapshot.state === "blocked") return "LinkedIn is limiting this page. Check for a verification or search limit before trying again.";
    if (snapshot.kind === "search") {
      if (snapshot.state === "ready") return "";
      if (snapshot.state === "empty") return "LinkedIn found no people for this search.";
      return "No readable results yet. The page may still be loading or its layout may have changed.";
    }
    return snapshot.profile?.profileReadAt || snapshot.profile?.truncated ? "" : "Wait for the profile sections to load, then reopen Mighty.";
  }
  function anchorText(text3) {
    return text3.replace(/^Rendered activity timestamp:/, "Activity date:").replace(/^Recent rendered activity:/, "Recent activity:");
  }
  function renderGoalAssessments() {
    const section = el("section", void 0, "account-goals");
    section.append(el("h2", "Account goals"));
    if (!connected || !userId || !goalContext) {
      section.append(el("p", "Reconnect from Mighty to load your saved goals. No previous account context is used.", "hint"));
      body.append(section);
      return;
    }
    try {
      const result = assessProfileGoals(userId, goalContext, state);
      if (result.state !== "ready") {
        section.append(el("p", result.message, "hint"));
        body.append(section);
        return;
      }
      section.append(el("p", "Profile evidence only. Self evidence and shared-employer routes aren\u2019t included.", "hint"));
      for (const [index, { goal, assessment }] of result.assessments.entries()) {
        const card = el("details", void 0, "goal-fit");
        card.open = index === 0;
        card.dataset.goalId = goal.id;
        card.dataset.goalVersion = String(goal.version);
        card.append(el("summary", goal.title));
        card.append(el("p", `Saved version ${goal.version}`, "hint goal-version"));
        for (const reason of assessment.reasons) card.append(el("p", reason, "reason"));
        if (!assessment.reasons.length) card.append(el("p", "The visible evidence does not yet establish this goal\u2019s criteria.", "reason"));
        const label = el("span", assessment.label, "fit-label");
        label.dataset.fit = assessment.status === "unknown" ? "insufficient" : assessment.status === "contradicted" || assessment.status === "conflicting" ? "none" : "overlap";
        card.append(label);
        if (assessment.unknowns.length) {
          card.append(el("h3", "Still unknown"));
          const unknowns = el("ul", void 0, "goal-unknowns");
          for (const unknown of assessment.unknowns) unknowns.append(el("li", unknown));
          card.append(unknowns);
        }
        const evidenceIds = new Set(assessment.reasonDetails.flatMap((reason) => reason.claimIds));
        const evidence = result.candidate.claims.filter((claim2) => evidenceIds.has(claim2.id));
        if (evidence.length) {
          const sources = el("details", void 0, "assessment-sources");
          sources.append(el("summary", "Supporting source text"));
          for (const claim2 of evidence) {
            const fact = el("div");
            fact.append(el("p", claim2.text));
            const source = el("a", claim2.sourceLabel);
            source.href = claim2.sourceRef;
            source.target = "_blank";
            source.rel = "noopener noreferrer";
            fact.append(source, el("p", `Observed ${claim2.observedAt}`, "hint"));
            sources.append(fact);
          }
          card.append(sources);
        }
        section.append(card);
      }
    } catch {
      section.replaceChildren(el("p", "Saved goals could not be verified. Reconnect from Mighty to refresh them.", "warning"));
    }
    body.append(section);
  }
  function renderProfile(profile) {
    body.append(el("h1", profile.name));
    const headline = profile.anchors.find((anchor) => anchor.kind === "headline");
    if (headline) body.append(el("p", headline.text, "profile-headline"));
    renderGoalAssessments();
    if (profile.truncated) body.append(el("p", "This read exceeds the save limit. Its full context cannot be saved.", "warning"));
    const timing = profile.anchors.filter((anchor) => anchor.kind === "timing");
    const timingCard = el("section", void 0, "evidence-section");
    timingCard.append(el("h2", "Timing"));
    if (timing.length) for (const anchor of timing) timingCard.append(el("p", anchorText(anchor.text)));
    else timingCard.append(el("p", "No visible activity dates or role timing.", "hint"));
    body.append(timingCard);
    const groups = /* @__PURE__ */ new Map();
    for (const anchor of profile.anchors) {
      if (anchor.kind === "timing" || anchor === headline) continue;
      const texts = groups.get(anchor.kind) || [];
      texts.push(anchor.text);
      groups.set(anchor.kind, texts);
    }
    for (const [kind, texts] of groups) {
      const section = el("section", void 0, "evidence-section");
      section.append(el("h2", sectionLabels[kind]));
      for (const text3 of texts) section.append(el("p", text3));
      body.append(section);
    }
    if (profile.missingSections?.length) {
      const missing = el("details", void 0, "missing-sections");
      missing.append(el("summary", "Not visible in this read"), el("p", profile.missingSections.map((kind) => sectionLabels[kind]).join(", ") + "."));
      body.append(missing);
    }
  }
  function renderSearch(snapshot) {
    if (!snapshot.results.length) return;
    const intro = el("div", void 0, "search-intro");
    intro.append(el("h1", "People on this page"), el("p", "Choose up to five people.", "hint"));
    body.append(intro);
    const list2 = el("div", void 0, "search-results");
    for (const result of snapshot.results) {
      const row = el("label", void 0, "result");
      const check = el("input");
      check.type = "checkbox";
      check.checked = selected.has(result.profileUrl);
      check.setAttribute("aria-label", "Select " + result.name);
      check.addEventListener("change", () => {
        const next = toggleSelection(selected, result.profileUrl, check.checked);
        selected = next.selected;
        check.checked = selected.has(result.profileUrl);
        report(next.message);
        updateSave();
      });
      const copy = el("div");
      const link = el("a", result.name);
      link.href = result.profileUrl;
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      copy.append(link);
      if (result.subtitle) copy.append(el("p", result.subtitle));
      if (result.truncated) copy.append(el("p", "Search text is incomplete. Open the profile to read it.", "warning"));
      row.append(check, copy);
      list2.append(row);
    }
    body.append(list2);
    const brief = el("details", void 0, "brief-help");
    brief.append(el("summary", "Why no brief yet?"), el("p", "Search snippets are not profile reads. Open each profile with Mighty before requesting a brief."));
    body.append(brief);
  }
  function render() {
    body.replaceChildren();
    body.setAttribute("aria-busy", String(!state));
    if (!state) {
      body.append(el("p", "Reading this page\u2026", "hint"));
      updateSave();
      return;
    }
    const message = pageNotice(state);
    if (message) body.append(el("p", message, "hint page-notice"));
    if (state.kind === "profile" && state.profile) renderProfile(state.profile);
    if (state.kind === "search") renderSearch(state);
    updateSave();
  }
  async function refresh(refreshGoals = false) {
    const generation = ++readGeneration;
    const previous = state;
    state = null;
    render();
    try {
      const [accountResult, pageResult] = await Promise.allSettled([send({ type: "mighty:status", refreshGoals }), send({ type: "mighty:read_active" })]);
      if (generation !== readGeneration) return;
      if (accountResult.status === "rejected") throw accountResult.reason;
      const status = accountResult.value;
      if (userId !== status.userId) {
        accountEpoch++;
        operations.clear();
        selected.clear();
      }
      userId = status.userId;
      goalContext = status.connected ? status.goalContext ?? null : null;
      connected = status.connected;
      const readProblem = pageResult.status === "rejected" ? "This page could not be read. Refresh LinkedIn, then reopen Mighty." : "";
      if (status.message || readProblem) {
        lastRefreshError = status.message || readProblem;
        report(lastRefreshError);
      } else {
        if (notice.textContent === lastRefreshError) report("");
        lastRefreshError = "";
      }
      account.replaceChildren(el("span", connected ? "Account connected" : "Account not connected", `account-state ${connected ? "connected" : ""}`));
      const link = el("a", connected ? "Open Mighty" : "Connect to Mighty");
      link.href = mightyAppLink(status.appOrigin, chrome.runtime.id, connected);
      link.target = "_blank";
      link.rel = "noopener noreferrer";
      account.append(link);
      if (pageResult.status === "rejected") {
        state = { kind: "unsupported", state: "unknown", message: readProblem };
        selected.clear();
      } else state = pageResult.value.snapshot;
      if (state?.kind === "search") {
        const changed = previous?.kind !== "search" || previous.pageUrl !== state.pageUrl;
        if (changed) selected = initialSelection(state.results);
        else {
          const visible = new Set(state.results.map((result) => result.profileUrl));
          selected = new Set([...selected].filter((url) => visible.has(url)));
        }
      }
      render();
    } catch (error) {
      if (generation !== readGeneration) return;
      invalidateAccountView();
      state = null;
      selected.clear();
      render();
      body.setAttribute("aria-busy", "false");
      lastRefreshError = error.message;
      report(lastRefreshError);
      updateSave();
    }
  }
  saveButton.addEventListener("click", async () => {
    if (!state || !connected || !userId) return;
    saving = true;
    updateSave();
    report("Saving\u2026");
    const profiles = state.kind === "profile" && state.profile ? [state.profile] : state.kind === "search" ? state.results.filter((result) => selected.has(result.profileUrl)).map((result) => ({
      profileUrl: result.profileUrl,
      name: result.name,
      anchors: [],
      profileReadAt: null,
      truncated: result.truncated,
      truncationReasons: result.truncated ? ["search_text_limit"] : []
    })) : [];
    const source = state.kind === "profile" ? "rendered_profile" : "search_result";
    const owner = userId, saveEpoch = accountEpoch;
    const results = await Promise.allSettled(profiles.map(async (profile) => {
      const key = owner + "|" + profile.profileUrl + "|" + source;
      let request = operations.get(key);
      if (!request) {
        request = { operationId: crypto.randomUUID(), userId: owner, profile, source };
        operations.set(key, request);
      }
      await send({ type: "mighty:save", save: request });
      operations.delete(key);
      return profile.profileUrl;
    }));
    const saved = results.filter((result) => result.status === "fulfilled").length;
    for (const result of results) if (result.status === "fulfilled") selected.delete(result.value);
    const failure = results.find((result) => result.status === "rejected");
    if (saveEpoch !== accountEpoch) report("");
    else report(failure ? (saved ? `${saved} saved. ` : "") + String(failure.reason?.message || "A save is still pending.") : saved === 1 ? "Saved. Open Mighty to view." : `${saved} people saved. Open Mighty to view.`);
    saving = false;
    render();
    if (refreshPending) {
      refreshPending = false;
      const refreshGoals = goalRefreshPending;
      goalRefreshPending = false;
      void refresh(refreshGoals);
    }
  });
  document.querySelector("#skip").addEventListener("click", () => window.close());
  var reconnect;
  function connect() {
    try {
      const port = chrome.runtime.connect({ name: "mighty:popup" });
      port.onMessage.addListener((message) => {
        if (message?.type === "mighty:account_changed") {
          accountEpoch++;
          readGeneration++;
          invalidateAccountView();
          render();
        }
        if (saving) refreshPending = true;
        else void refresh();
      });
      port.onDisconnect.addListener(() => {
        accountEpoch++;
        invalidateAccountView();
        readGeneration++;
        render();
        clearTimeout(reconnect);
        reconnect = setTimeout(() => {
          connect();
          void refresh();
        }, 100);
      });
    } catch {
      report("Mighty was reloaded. Reopen the extension.");
    }
  }
  addEventListener("focus", () => {
    if (saving) {
      refreshPending = true;
      goalRefreshPending = true;
    } else void refresh(true);
  });
  connect();
  void refresh(true);
})();
