"use strict";
(() => {
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };

  // <define:__PUBLIC_CONFIG__>
  var define_PUBLIC_CONFIG_default;
  var init_define_PUBLIC_CONFIG = __esm({
    "<define:__PUBLIC_CONFIG__>"() {
      define_PUBLIC_CONFIG_default = { appOrigins: ["https://riteshmitsloan.github.io/mighty/", "http://127.0.0.1:5173/", "http://localhost:5173/"], supabaseUrl: "https://eglrbdlnuhdfvgrttvxs.supabase.co", publishableKey: "sb_publishable_UgT-YXz7Zn87fkRtnEY8uQ_2uTEi5sb" };
    }
  });

  // src/worker.ts
  init_define_PUBLIC_CONFIG();

  // src/config.ts
  init_define_PUBLIC_CONFIG();
  var config = define_PUBLIC_CONFIG_default;
  function configured() {
    return Boolean(config.supabaseUrl && config.publishableKey);
  }

  // src/account-errors.ts
  init_define_PUBLIC_CONFIG();
  var messages = {
    not_configured: "This extension build is not connected to Mighty. Download a new copy from the app.",
    verification_unavailable: "Mighty could not reach account verification. Check your connection and reconnect.",
    verification_rejected: "Your app session could not be verified. Sign in to Mighty again, then reconnect.",
    verification_failed: "Account verification is temporarily unavailable. Try connecting again.",
    verification_unreadable: "Account verification returned an unreadable response. Try connecting again.",
    verification_invalid: "Account verification returned an invalid account. Reconnect from Mighty.",
    session_invalid: "The app session has an unsupported format. Sign in to Mighty again, then reconnect.",
    session_mismatch: "The app session does not match the verified account. Reconnect from Mighty.",
    session_project_mismatch: "The app and extension use different account services. Download the current extension from Mighty.",
    session_expired: "Your app session expired. Sign in to Mighty again, then reconnect.",
    session_lifetime: "The app session lasts longer than the extension allows. Update Mighty and reconnect.",
    goals_unavailable: "Account goals could not be refreshed. Check your connection and reconnect from Mighty.",
    goals_session_rejected: "Account goals could not be loaded because the session expired. Sign in to Mighty again, then reconnect.",
    goals_forbidden: "Account goals could not be loaded because access was refused. Update Mighty and reconnect.",
    goals_failed: "Account goals could not be loaded. Try connecting again from Mighty.",
    goals_unreadable: "Account goals returned an unreadable response. Reconnect from Mighty.",
    goals_invalid: "Account goals are incompatible or incomplete. Update Mighty and reconnect; no previous goals are being used.",
    goals_incomplete: "Account goals could not be loaded completely. Reconnect from Mighty; no previous goals are being used.",
    goals_cache_invalid: "Saved account goals could not be verified. Reconnect from Mighty.",
    connection_superseded: "A newer account connection replaced this request. Return to Mighty and try again.",
    connection_failed: "The account connection could not be completed. Reconnect from Mighty."
  };
  var AccountConnectionError = class extends Error {
    constructor(code) {
      super(messages[code]);
      this.code = code;
      this.name = "AccountConnectionError";
    }
    code;
  };
  function accountFailure(error) {
    const code = error instanceof AccountConnectionError ? error.code : "connection_failed";
    return { code, message: messages[code] };
  }

  // src/account-session.ts
  init_define_PUBLIC_CONFIG();

  // src/goal-context.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/goals.ts
  init_define_PUBLIC_CONFIG();
  var kinds = ["career", "fundraising", "advisory", "partnership", "other"];
  var statuses = ["active", "paused", "completed"];
  var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var controls = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
  function object(value, label) {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} must be an object.`);
    return value;
  }
  function text(value, label, max) {
    if (typeof value !== "string" || !value.trim() || value.length > max || controls.test(value)) throw new TypeError(`${label} must contain readable text under ${max + 1} characters.`);
    return value;
  }
  function choice(value, allowed, label) {
    if (!allowed.includes(value)) throw new TypeError(`${label} is not recognized.`);
    return value;
  }
  function date(value, label) {
    if (typeof value !== "string" || !/^\d{4}-\d\d-\d\dT/.test(value) || !Number.isFinite(Date.parse(value))) throw new TypeError(`${label} is invalid.`);
    return new Date(value).toISOString();
  }
  function list(value, label, max) {
    if (!Array.isArray(value) || value.length > max) throw new TypeError(`${label} must be an array with at most ${max} entries.`);
    return value;
  }
  function normalizeGoalCriterion(value) {
    const row = object(value, "Goal criterion");
    const id = text(row.id, "Criterion identifier", 100);
    if (!/^[\w-]+$/.test(id)) throw new TypeError("Criterion identifier must contain letters, digits, underscores, or hyphens.");
    const terms = list(row.terms, "Criterion terms", 20).map((term) => text(term, "Criterion term", 200).trim());
    return { id, field: choice(row.field, ["role", "industry", "location", "stage", "check_size", "custom"], "Criterion field"), label: text(row.label, "Criterion label", 200), terms: [...new Set(terms)], importance: choice(row.importance, ["required", "preferred"], "Criterion importance"), appliesTo: choice(row.appliesTo, ["opportunity", "contact"], "Criterion subject"), origin: choice(row.origin, ["user", "suggested"], "Criterion origin") };
  }
  function normalizeGoal(value) {
    const row = object(value, "Goal");
    if (typeof row.id !== "string" || !UUID.test(row.id)) throw new TypeError("Goal identifier must be a UUID.");
    if (!Number.isSafeInteger(row.version) || Number(row.version) < 1 || Number(row.version) > 2147483647) throw new TypeError("Goal version must be a positive integer.");
    const criteria = list(row.criteria, "Goal criteria", 30).map(normalizeGoalCriterion);
    if (new Set(criteria.map((c) => c.id)).size !== criteria.length) throw new TypeError("Criterion identifiers must be distinct.");
    const goal = { id: row.id.toLowerCase(), kind: choice(row.kind, kinds, "Goal kind"), title: text(row.title, "Goal title", 200), outcome: text(row.outcome, "Goal outcome", 16e3), criteria, openQuestions: list(row.openQuestions, "Open questions", 30).map((q) => text(q, "Open question", 1e3)), version: Number(row.version), status: choice(row.status, statuses, "Goal status"), createdAt: date(row.createdAt, "Goal creation date"), updatedAt: date(row.updatedAt, "Goal update date") };
    if (Date.parse(goal.updatedAt) < Date.parse(goal.createdAt)) throw new TypeError("Goal update cannot precede its creation.");
    if (new TextEncoder().encode(JSON.stringify(goal)).byteLength > 65536) throw new TypeError("The goal is too large to save.");
    return goal;
  }
  function normalizeGoalWorkspace(value) {
    const row = object(value, "Goal workspace");
    const goals = list(row.goals, "Goals", 100).map(normalizeGoal);
    if (new Set(goals.map((g) => g.id)).size !== goals.length) throw new TypeError("Goal identifiers must be distinct.");
    if (row.activeGoalId !== null && (typeof row.activeGoalId !== "string" || !goals.some((g) => g.id === row.activeGoalId && g.status === "active"))) throw new TypeError("Choose an active goal from this workspace.");
    return { goals, activeGoalId: row.activeGoalId };
  }

  // ../src/lib/evidence.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/knowledge.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/text.ts
  init_define_PUBLIC_CONFIG();
  function stableStringify(value) {
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    if (value && typeof value === "object") return `{${Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${JSON.stringify(k)}:${stableStringify(v)}`).join(",")}}`;
    return JSON.stringify(value) ?? "null";
  }
  function deepFreeze(value) {
    if (value && typeof value === "object" && !Object.isFrozen(value)) {
      Object.freeze(value);
      Object.values(value).forEach(deepFreeze);
    }
    return value;
  }

  // ../src/lib/resume.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/evidence.ts
  function evidenceKey(value) {
    const input = stableStringify(value);
    let a = 2166136261, b = 2654435769;
    for (let i = 0; i < input.length; i++) {
      a = Math.imul(a ^ input.charCodeAt(i), 16777619);
      b = Math.imul(b ^ input.charCodeAt(i), 2246822507);
    }
    return `${(a >>> 0).toString(16).padStart(8, "0")}${(b >>> 0).toString(16).padStart(8, "0")}`;
  }

  // src/goal-context.ts
  var goalKeys = ["id", "kind", "title", "outcome", "criteria", "openQuestions", "version", "status", "createdAt", "updatedAt"];
  var criterionKeys = ["id", "field", "label", "terms", "importance", "appliesTo", "origin"];
  function exactKeys(value, allowed) {
    if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some((key) => !allowed.includes(key))) {
      throw Error("Account goals use an unsupported format. Update Mighty and reconnect.");
    }
  }
  function strictGoal(document) {
    exactKeys(document, goalKeys);
    const row = document;
    if (Array.isArray(row.criteria)) row.criteria.forEach((item) => exactKeys(item, criterionKeys));
    return normalizeGoal(document);
  }
  function contextKey(userId, goals) {
    return evidenceKey(["extension-account-goals-v1", userId, goals]);
  }
  function accountGoalContext(userId, rows, loadedAt = (/* @__PURE__ */ new Date()).toISOString()) {
    try {
      if (!Array.isArray(rows) || rows.length > 100 || !Number.isFinite(Date.parse(loadedAt))) throw Error();
      const goals = rows.map((value) => {
        if (!value || typeof value !== "object" || Array.isArray(value)) throw Error();
        const row = value;
        const goal = strictGoal(row.document);
        if (row.user_id !== userId || row.id !== goal.id || row.version !== goal.version) throw Error();
        return goal;
      });
      const checked = normalizeGoalWorkspace({ goals, activeGoalId: null }).goals;
      return deepFreeze({ schemaVersion: 1, userId, goals: checked, loadedAt, key: contextKey(userId, checked) });
    } catch {
      throw new AccountConnectionError("goals_invalid");
    }
  }
  function validateGoalContext(value, userId) {
    try {
      if (!value || typeof value !== "object") throw Error();
      const context = value;
      if (context.schemaVersion !== 1 || context.userId !== userId || !Array.isArray(context.goals)) throw Error();
      const checked = accountGoalContext(userId, context.goals.map((goal) => ({ id: goal.id, user_id: userId, version: goal.version, document: goal })), context.loadedAt);
      if (context.key !== checked.key) throw Error();
      return checked;
    } catch {
      throw new AccountConnectionError("goals_cache_invalid");
    }
  }
  async function loadAccountGoals(session2, config2, request = fetch) {
    const endpoint = new URL(config2.supabaseUrl + "/rest/v1/goals");
    endpoint.searchParams.set("user_id", "eq." + session2.userId);
    endpoint.searchParams.set("select", "id,user_id,version,document");
    endpoint.searchParams.set("order", "id.asc");
    endpoint.searchParams.set("limit", "101");
    let response;
    try {
      response = await request(endpoint, { headers: { apikey: config2.publishableKey, Authorization: "Bearer " + session2.accessToken, Prefer: "count=exact" }, signal: AbortSignal.timeout(1e4) });
    } catch {
      throw new AccountConnectionError("goals_unavailable");
    }
    if (!response.ok) throw new AccountConnectionError(response.status === 401 ? "goals_session_rejected" : response.status === 403 ? "goals_forbidden" : "goals_failed");
    let rows;
    try {
      rows = await response.json();
    } catch {
      throw new AccountConnectionError("goals_unreadable");
    }
    const context = accountGoalContext(session2.userId, rows);
    const range = response.headers.get("Content-Range");
    const full = range?.match(/^0-(\d+)\/(\d+)$/);
    const complete = context.goals.length === 0 ? range === "*/0" : Boolean(full && Number(full[1]) + 1 === context.goals.length && Number(full[2]) === context.goals.length);
    if (!complete) throw new AccountConnectionError("goals_incomplete");
    return context;
  }

  // src/messaging.ts
  init_define_PUBLIC_CONFIG();

  // src/profile.ts
  init_define_PUBLIC_CONFIG();

  // src/dom.ts
  init_define_PUBLIC_CONFIG();

  // src/experience-fields.ts
  init_define_PUBLIC_CONFIG();

  // ../src/lib/current-experience.ts
  init_define_PUBLIC_CONFIG();
  var CURRENT_EXPERIENCE_LIMITS = Object.freeze({ field: 200, range: 80, entry: 8e3 });
  var months = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"];
  var month = "(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:tember)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)";
  var date2 = "(?:(?:19|20)\\d{2}-\\d{2}-\\d{2}|(?:" + month + "\\s+)?(?:19|20)\\d{2})";
  var separator = "\\s*(?:[-\u2013\u2014]|to)\\s*";
  function currentExperienceDateRanges(text2) {
    return [...text2.matchAll(new RegExp("(?<![\\w-])" + date2 + separator + "(?:" + date2 + "|Present|Current)(?![\\w-])", "gi"))].map((match) => match[0].trim());
  }
  function validCurrentExperienceDate(range, observedAt) {
    if (typeof range !== "string" || range.length > CURRENT_EXPERIENCE_LIMITS.range || typeof observedAt !== "string") return false;
    const observed = Date.parse(observedAt);
    if (!Number.isFinite(observed)) return false;
    const match = range.match(new RegExp("^(" + date2 + ")" + separator + "(?:Present|Current)$", "i"));
    if (!match) return false;
    const start = match[1], exact = start.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let instant;
    if (exact) {
      instant = Date.UTC(Number(exact[1]), Number(exact[2]) - 1, Number(exact[3]));
      const check = new Date(instant);
      if (check.getUTCFullYear() !== Number(exact[1]) || check.getUTCMonth() !== Number(exact[2]) - 1 || check.getUTCDate() !== Number(exact[3])) return false;
    } else {
      const named = start.match(new RegExp("^(" + month + ")\\s+((?:19|20)\\d{2})$", "i"));
      instant = named ? Date.UTC(Number(named[2]), months.indexOf(named[1].slice(0, 3).toLowerCase()), 1) : Date.UTC(Number(start), 0, 1);
    }
    return Number.isFinite(instant) && instant <= observed;
  }
  var record = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
  function validCurrentExperienceAnchor(anchor, anchors, profileUrl, profileReadAt) {
    const value = record(anchor);
    if (!value || value.kind !== "experience" || !["role", "company"].includes(String(value.field)) || typeof value.text !== "string" || !value.text.trim() || value.text.length > CURRENT_EXPERIENCE_LIMITS.field) return false;
    if (!profileReadAt || !Number.isFinite(Date.parse(profileReadAt)) || value.observedAt !== profileReadAt || value.sourceUrl !== profileUrl + "#experience") return false;
    if (value.appliesTo !== void 0 && value.appliesTo !== "contact" || value.polarity !== void 0 && value.polarity !== "positive") return false;
    const current = record(value.currentExperience);
    if (!current || Object.keys(current).some((key) => !["dateRange", "entryText"].includes(key)) || typeof current.dateRange !== "string" || typeof current.entryText !== "string") return false;
    if (!current.entryText.trim() || current.entryText.length > CURRENT_EXPERIENCE_LIMITS.entry || !validCurrentExperienceDate(current.dateRange, profileReadAt) || !current.entryText.includes(value.text) || !current.entryText.includes(current.dateRange)) return false;
    const ranges = [...new Set(currentExperienceDateRanges(current.entryText))];
    if (ranges.length !== 1 || ranges[0] !== current.dateRange) return false;
    const sameSource = (other) => other && other.sourceUrl === value.sourceUrl && other.observedAt === profileReadAt && other.field === void 0 && other.currentExperience === void 0;
    return anchors.some((other) => {
      const raw = record(other);
      return sameSource(raw) && raw.kind === "experience" && raw.text === current.entryText;
    }) && anchors.some((other) => {
      const timing = record(other);
      return sameSource(timing) && timing.kind === "timing" && timing.text === current.dateRange;
    });
  }

  // src/urls.ts
  init_define_PUBLIC_CONFIG();
  function canonicalProfileURL(value, base = "https://www.linkedin.com") {
    try {
      const u = new URL(value, base);
      if (u.protocol !== "https:" || !["linkedin.com", "www.linkedin.com"].includes(u.hostname.toLowerCase()) || u.port || u.username || u.password) return null;
      const m = u.pathname.match(/^\/in\/([^/]+)\/?$/);
      if (!m) return null;
      const slug = decodeURIComponent(m[1]).normalize("NFC").toLowerCase();
      if (!/^[\p{L}\p{N}_-]{1,200}$/u.test(slug)) return null;
      return "https://www.linkedin.com/in/" + encodeURIComponent(slug) + "/";
    } catch {
      return null;
    }
  }
  function exactOrigin(value, expected) {
    try {
      const u = new URL(value);
      return u.origin === new URL(expected).origin && (u.protocol === "https:" || u.protocol === "http:" && ["127.0.0.1", "localhost"].includes(u.hostname)) && !u.username && !u.password;
    } catch {
      return false;
    }
  }
  function exactAppURL(value, expected) {
    try {
      const u = new URL(value), app = new URL(expected);
      if (!exactOrigin(value, expected) || app.username || app.password || app.search || app.hash) return false;
      const base = app.pathname.endsWith("/") ? app.pathname : app.pathname + "/";
      return !/%(?:2f|5c)/i.test(u.pathname) && u.pathname.startsWith(base);
    } catch {
      return false;
    }
  }
  function isSearchURL(value) {
    try {
      const u = new URL(value);
      return u.protocol === "https:" && ["www.linkedin.com", "linkedin.com"].includes(u.hostname) && /^\/search\/results\/people\/?$/.test(u.pathname);
    } catch {
      return false;
    }
  }

  // src/profile.ts
  var substantiveKinds = /* @__PURE__ */ new Set(["about", "experience", "education", "skills", "languages", "certifications", "activity"]);
  function hasSubstantiveProfile(profile) {
    return Boolean(profile?.anchors.some((anchor) => substantiveKinds.has(anchor.kind) && anchor.text.trim().length > 0));
  }

  // src/messaging.ts
  var uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  function isExternalSender(sender, allowedOrigins) {
    if (sender.id || !sender.url) return false;
    try {
      const url = new URL(sender.url);
      return (!sender.origin || sender.origin === url.origin) && allowedOrigins.some((app) => exactAppURL(sender.url, app));
    } catch {
      return false;
    }
  }
  function parseExternalMessage(input) {
    if (!input || typeof input !== "object" || Array.isArray(input)) throw Error("Invalid bridge message.");
    const v = input;
    if (v.protocol !== 1) throw Error("Unsupported bridge protocol.");
    if (v.type === "mighty:connect") {
      if (Object.keys(v).some((x) => !["protocol", "type", "accessToken"].includes(x)) || typeof v.accessToken !== "string" || v.accessToken.length > 8192) throw Error("Invalid account handoff.");
      return { type: "connect", accessToken: v.accessToken };
    }
    if (["mighty:disconnect", "mighty:status"].includes(String(v.type)) && Object.keys(v).every((x) => ["protocol", "type"].includes(x))) return { type: v.type === "mighty:disconnect" ? "disconnect" : "status" };
    throw Error("Unsupported bridge message.");
  }
  function sessionFromVerifiedToken(accessToken, verifiedUserId, projectUrl, now = Date.now()) {
    let claims;
    try {
      const parts = accessToken.split(".");
      if (parts.length !== 3) throw Error();
      const encoded = parts[1].replace(/-/g, "+").replace(/_/g, "/");
      claims = JSON.parse(atob(encoded.padEnd(Math.ceil(encoded.length / 4) * 4, "=")));
      if (!claims || typeof claims !== "object" || Array.isArray(claims) || !Number.isSafeInteger(claims.exp)) throw Error();
    } catch {
      throw new AccountConnectionError("session_invalid");
    }
    if (!uuid.test(verifiedUserId) || claims.sub !== verifiedUserId) throw new AccountConnectionError("session_mismatch");
    if (claims.iss !== projectUrl.replace(/\/$/, "") + "/auth/v1") throw new AccountConnectionError("session_project_mismatch");
    const expiresAt = Number(claims.exp) * 1e3;
    if (expiresAt <= now + 5e3) throw new AccountConnectionError("session_expired");
    if (expiresAt > now + 39e5) throw new AccountConnectionError("session_lifetime");
    return { userId: verifiedUserId, accessToken, expiresAt, strategy: "" };
  }
  function validSession(session2, now = Date.now()) {
    return Boolean(session2 && session2.expiresAt > now + 5e3);
  }
  function validateSave(value, session2) {
    if (!value || typeof value !== "object") throw Error("Invalid save request.");
    const x = value;
    if (!uuid.test(x.operationId) || x.userId !== session2.userId || !["rendered_profile", "search_result"].includes(x.source)) throw Error("The save belongs to a different account or is invalid.");
    const p = x.profile;
    if (!p || canonicalProfileURL(p.profileUrl) !== p.profileUrl || typeof p.name !== "string" || !p.name.trim() || p.name.length > 200 || !Array.isArray(p.anchors) || typeof p.truncated !== "boolean" || !Array.isArray(p.truncationReasons)) throw Error("The profile snapshot is invalid.");
    if (x.source === "search_result" && (p.profileReadAt !== null || p.anchors.length)) throw Error("Search snippets cannot be marked as a profile read.");
    if (x.source === "rendered_profile" && (!hasSubstantiveProfile(p) || !p.truncated && (!p.profileReadAt || !Number.isFinite(Date.parse(p.profileReadAt))))) throw Error("Read the actual profile before saving this snapshot.");
    const kinds2 = ["headline", "location", "about", "experience", "education", "skills", "languages", "certifications", "activity", "timing"];
    for (const a of p.anchors) {
      if (!a || !kinds2.includes(a.kind) || typeof a.text !== "string" || !a.text.trim() || typeof a.sourceUrl !== "string" || !a.sourceUrl.startsWith(p.profileUrl + "#") || !Number.isFinite(Date.parse(a.observedAt))) throw Error("An evidence anchor is invalid.");
      if ((a.field !== void 0 || a.currentExperience !== void 0) && !validCurrentExperienceAnchor(a, p.anchors, p.profileUrl, p.profileReadAt ?? a.observedAt)) throw Error("A current experience field needs valid visible source and date evidence.");
    }
    if (p.truncationReasons.includes("snapshot_size_limit") || new TextEncoder().encode(JSON.stringify(p)).length > 49152) throw Error("This profile exceeds the snapshot size limit. Its full context has not been saved.");
    return { operationId: x.operationId, userId: x.userId, profile: p, source: x.source };
  }
  function inboxPayload(save) {
    const readAt = save.source === "rendered_profile" && !save.profile.truncated ? save.profile.profileReadAt : null;
    return { operation_id: save.operationId, user_id: save.userId, profile_url: save.profile.profileUrl, person: save.profile.name, snapshot: { ...save.profile, profileReadAt: readAt, source: save.source }, profile_read_at: readAt };
  }
  function pendingKey(save) {
    return "pending:" + save.userId + ":" + save.operationId;
  }
  function matchingPending(rows, session2) {
    return rows.filter((row) => row.userId === session2.userId);
  }

  // src/account-session.ts
  function createAccountSession(storage, changed = () => {
  }, now = Date.now) {
    let generation = 0, message = "";
    let writes = Promise.resolve();
    const write = (ticket, value) => {
      const job = writes.catch(() => {
      }).then(async () => {
        if (ticket === generation) await storage.write(value);
      });
      writes = job;
      return job;
    };
    const checked = (value) => {
      if (!validSession(value, now())) throw new AccountConnectionError("session_expired");
      return { ...value, goalContext: validateGoalContext(value.goalContext, value.userId), strategy: "" };
    };
    async function current() {
      const ticket = generation, pendingWrites = writes;
      await pendingWrites;
      if (ticket !== generation || pendingWrites !== writes) return current();
      const value = await storage.read();
      if (ticket !== generation || pendingWrites !== writes) return current();
      if (!value) return null;
      try {
        return checked(value);
      } catch (error) {
        if (ticket === generation) message = accountFailure(error).message;
        await write(ticket, null);
        changed();
        return null;
      }
    }
    async function disconnect() {
      const ticket = ++generation;
      message = "";
      await write(ticket, null);
      changed();
    }
    async function connect(load) {
      const ticket = ++generation;
      message = "";
      await write(ticket, null);
      changed();
      try {
        const result = checked(await load());
        if (ticket !== generation) throw new AccountConnectionError("connection_superseded");
        await write(ticket, result);
        if (ticket !== generation) throw new AccountConnectionError("connection_superseded");
        changed();
        return result;
      } catch (error) {
        if (ticket !== generation) throw new AccountConnectionError("connection_superseded");
        if (ticket === generation) {
          message = accountFailure(error).message;
          await write(ticket, null);
          changed();
        }
        throw error;
      }
    }
    async function refresh(load) {
      const ticket = generation, previous = await current();
      if (ticket !== generation) return current();
      if (!previous) return null;
      return connect(() => load(previous));
    }
    return { current, connect, disconnect, refresh, message: () => message };
  }

  // src/worker.ts
  var setup = Promise.all([chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }), chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" })]);
  var ports = /* @__PURE__ */ new Set();
  var inFlight = /* @__PURE__ */ new Map();
  var accounts = createAccountSession({ async read() {
    await setup;
    return (await chrome.storage.session.get("account")).account || null;
  }, async write(value) {
    await setup;
    if (value) await chrome.storage.session.set({ account: value });
    else await chrome.storage.session.remove("account");
  } }, broadcast);
  var session = accounts.current;
  var headers = (s) => ({ "apikey": config.publishableKey, Authorization: "Bearer " + s.accessToken, "Content-Type": "application/json" });
  function status(s, includeGoals = false) {
    const current = validSession(s) ? s : null;
    return { connected: Boolean(current), userId: current?.userId || null, goalCount: current?.goalContext?.goals.length ?? 0, ...includeGoals ? { goalContext: current?.goalContext ?? null } : {}, message: accounts.message(), configured: configured(), appOrigin: config.appOrigins[0] };
  }
  function broadcast() {
    for (const port of ports) {
      try {
        port.postMessage({ type: "mighty:account_changed" });
      } catch {
        ports.delete(port);
      }
    }
  }
  async function verifiedHandoff(accessToken) {
    if (!configured()) throw new AccountConnectionError("not_configured");
    let response;
    try {
      response = await fetch(config.supabaseUrl + "/auth/v1/user", { headers: { apikey: config.publishableKey, Authorization: "Bearer " + accessToken }, signal: AbortSignal.timeout(1e4) });
    } catch {
      throw new AccountConnectionError("verification_unavailable");
    }
    if (!response.ok) throw new AccountConnectionError([401, 403].includes(response.status) ? "verification_rejected" : "verification_failed");
    let user;
    try {
      user = await response.json();
    } catch {
      throw new AccountConnectionError("verification_unreadable");
    }
    if (!user || typeof user !== "object" || Array.isArray(user) || !("id" in user) || typeof user.id !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(user.id)) throw new AccountConnectionError("verification_invalid");
    const s = sessionFromVerifiedToken(accessToken, user.id, config.supabaseUrl);
    s.goalContext = await loadAccountGoals(s, config);
    return s;
  }
  async function deliver(save, s) {
    const current = await session();
    if (!validSession(current) || current.userId !== s.userId || save.userId !== s.userId) throw Error("Reconnect the account that owns this pending save.");
    s = current;
    validateSave(save, s);
    const key = pendingKey(save);
    const existing = inFlight.get(key);
    if (existing) return existing;
    const job = (async () => {
      const response = await fetch(config.supabaseUrl + "/rest/v1/outreach_inbox?on_conflict=user_id,operation_id", { method: "POST", headers: { ...headers(s), Prefer: "resolution=ignore-duplicates,return=representation" }, body: JSON.stringify(inboxPayload(save)), signal: AbortSignal.timeout(15e3) });
      if (!response.ok) throw Error(response.status === 401 ? "Your session expired. Reconnect in the app." : response.status === 403 ? "This account cannot save right now." : "The save is still pending. Try again when the app connection is available.");
      await chrome.storage.local.remove(key);
    })();
    inFlight.set(key, job);
    try {
      await job;
    } finally {
      inFlight.delete(key);
    }
  }
  async function flush(s) {
    const all = await chrome.storage.local.get(null);
    const pending = matchingPending(Object.entries(all).filter(([k]) => k.startsWith("pending:")).map(([, v]) => v), s);
    for (let offset = 0; offset < pending.length; offset += 4) await Promise.allSettled(pending.slice(offset, offset + 4).map((row) => deliver(row, s)));
  }
  async function readActive() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id || !tab.url || !canonicalProfileURL(tab.url) && !isSearchURL(tab.url)) return { kind: "unsupported", state: "unknown", message: "Open a LinkedIn profile or people search in the active tab." };
    try {
      return await chrome.tabs.sendMessage(tab.id, { type: "mighty:read" });
    } catch {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
      return await chrome.tabs.sendMessage(tab.id, { type: "mighty:read" });
    }
  }
  chrome.runtime.onMessageExternal.addListener((message, sender, respond) => {
    if (!isExternalSender(sender, config.appOrigins)) {
      respond({ ok: false, message: "This origin is not allowed." });
      return;
    }
    void (async () => {
      await setup;
      const parsed = parseExternalMessage(message);
      if (parsed.type === "status") return { ok: true, ...status(await session()) };
      if (parsed.type === "disconnect") {
        await accounts.disconnect();
        return { ok: true };
      }
      const s = await accounts.connect(() => verifiedHandoff(parsed.accessToken));
      void flush(s);
      return { ok: true, ...status(s) };
    })().then(respond).catch((error) => respond({ ok: false, ...accountFailure(error) }));
    return true;
  });
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== "mighty:popup" || port.sender?.id !== chrome.runtime.id) return;
    ports.add(port);
    port.onDisconnect.addListener(() => ports.delete(port));
  });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id) return;
    if (message?.type === "mighty:page_changed" && sender.tab) {
      for (const port of ports) {
        try {
          port.postMessage({ type: "mighty:page_changed", tabId: sender.tab.id });
        } catch {
          ports.delete(port);
        }
      }
      return;
    }
    if (sender.url !== chrome.runtime.getURL("popup.html")) return;
    void (async () => {
      await setup;
      if (message?.type === "mighty:status") {
        const s = message.refreshGoals === true ? await accounts.refresh(async (previous) => ({ ...previous, goalContext: await loadAccountGoals(previous, config) })) : await session();
        return { ok: true, ...status(s, true) };
      }
      if (message?.type === "mighty:read_active") return { ok: true, snapshot: await readActive() };
      if (message?.type === "mighty:save") {
        const s = await session();
        if (!validSession(s)) throw Error("Connect your account in the app before saving.");
        const save = validateSave(message.save, s), key = pendingKey(save);
        const old = (await chrome.storage.local.get(key))[key];
        if (old && JSON.stringify(inboxPayload(old)) !== JSON.stringify(inboxPayload(save))) throw Error("This save identifier already belongs to a different snapshot.");
        const queued = old || { ...save, queuedAt: (/* @__PURE__ */ new Date()).toISOString() };
        await chrome.storage.local.set({ [key]: queued });
        await deliver(queued, s);
        return { ok: true, operationId: save.operationId };
      }
      throw Error("Unsupported extension request.");
    })().then(respond).catch((e) => respond(message?.type === "mighty:status" ? { ok: false, ...accountFailure(e) } : { ok: false, message: e instanceof Error ? e.message : "The extension request could not be completed." }));
    return true;
  });
  chrome.runtime.onConnectExternal.addListener((port) => {
    if (port.name !== "mighty:bridge" || !isExternalSender(port.sender || {}, config.appOrigins)) {
      port.disconnect();
      return;
    }
    port.postMessage({ type: "mighty:ready", protocol: 1 });
  });
})();
