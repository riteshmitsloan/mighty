# Bundled typeface

Unmodified Schibsted Grotesk Latin variable normal WOFF2 from the existing @fontsource-variable/schibsted-grotesk 5.3.0 package. The original SIL Open Font License is included as OFL.txt. The source font supports the 400–900 weight axis; Mighty uses 800. Keep the license with redistributed font files. No font file has been renamed internally or modified.
